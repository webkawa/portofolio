<?php

niveau_securite(2) ;

// Prise en compte de l'action

if( isset( $_POST['a_nom'] ) )
{
	if( empty( $_POST['a_nom'] ) || empty( $_POST['a_prenom'] ) )			e_erreur(4) ;
	
	if( !$contenu['erreur'] )
	{
		$on[0] = array( 'IDGroupeFolklorique' , $_GET['gestion'] , FALSE ) ;
		$on[1] = array( 'Nom' , $_POST['a_nom'] , TRUE ) ;
		$on[2] = array( 'Prenom' , $_POST['a_prenom'] , TRUE ) ;
		
		insert_sql( "Artiste" , $on ) ;
		journal( "Insertion artiste : IDArtiste[".select_max_sql("Artiste","IDArtiste")."]");
	}
}
if( isset( $_POST['gf_nom'] ) )
{
	if( empty( $_POST['gf_nom'] ) || empty( $_POST['gf_pays'] ) )			e_erreur(4) ;
	
	if( !$contenu['erreur'] )
	{
		$on[0] = array( 'Nom' , $_POST['gf_nom'] , TRUE ) ;
		$on[1] = array( 'Pays' , $_POST['gf_pays'] , TRUE ) ;
		
		insert_sql( "GroupeFolklorique" , $on ) ;
		journal( "Insertion groupe : IDGroupeFolklorique[".select_max_sql("GroupeFolklorique","IDGroupeFolklorique")."]") ;
	}
}
if( isset( $_GET['supprimer_a'] ) )
{
	delete_sql( "Artiste" , "IDArtiste = ".$_GET['supprimer_a'] ) ;
	journal( "Suppression artiste : IDArtiste[".$_GET['supprimer_a']."]" );
}
if( isset( $_GET['supprimer'] ) )
{
	$del_infos = select_sql( "GroupeFolklorique" , "IDGroupeFolklorique = ".$_GET['supprimer'] ) ;
	
	if( $_GET['ok'] != 1 )
	{
		$bdp = '<a name="CD"></a>'.
				"<h2>Suppression</h2>" .
					"<p>Confirmez-vous la suppression du groupe folklorique <strong>".$del_infos['Nom']."</strong> ?</p>" .
					"<blockquote>" .
						lk("Supprimer","gestion_gf",FALSE,"ok=1&supprimer=".$_GET['supprimer'],'valider.png','Cliquez ici pour supprimer d&eacute;finitivement le groupe et ses artistes.')."</p>".
						lk("Annuler","gestion_gf",FALSE,'','annuler.png')."</p>".
					"</blockquote>" ;	
	} 
	else
	{
		delete_sql( "Artiste" , "IDGroupeFolklorique = ".$_GET['supprimer'] , 8000 );
		delete_sql( "GroupeFolklorique" , "IDGroupeFolklorique = ".$_GET['supprimer'] );
		journal( "Suppression groupe : IDGroupeFolklorique[".$_GET['supprimer']."]" );
	}
}


// Génération du tableau

$grp = select_sql( "GroupeFolklorique" , "1" , "*" , "ORDER BY Nom" ) ;

$infos['titre'][0]	=	"Nom" ;						$infos['taille'][0]	=	NULL ;
$infos['titre'][1]	=	"Pays" ;					$infos['taille'][1]	=	150 ;
$infos['titre'][2]	=	NULL ;						$infos['taille'][2]	=	150 ;

for( $i = 0 ; $i < $grp['nbr'] ; $i++ )
{
	$contenu[$i][0]	=	$grp[$i]['Nom'] ;
	$contenu[$i][1] =	$grp[$i]['Pays'] ;
	$contenu[$i][2]	=	'<font size="-1">'.lk("G&eacute;rer","gestion_gf",FALSE,"gestion=".$grp[$i][0]."&select_c=".$i."#CD").'<br>' .
							lk("Supprimer","gestion_gf",FALSE,"supprimer=".$grp[$i][0]."&select_c=".$i."#CD" ).'</font>' ;
}

$titre	=	"Groupes folkloriques" ;
$texte .=	"<h2>Liste brute</h2>" .
				"<p>La liste ci-dessous r&eacute;sume la liste des groupes folkloriques convi&eacute;s au Mondial pour l'ann&eacute;e ".$global['annee'].". " .
				"Pour afficher la liste des artistes inscrits dans chacuns de ces groupes, cliquez sur \"G&eacute;rer\"." ;
$texte .=	liste( $contenu , $infos , 3 , 20 , 1 , 10 ) ;
$texte .=	$bdp ;

// Informations de gestion

if( isset( $_GET['gestion'] ) )
{
	$artistes = select_sql( "Artiste" , "IDGroupeFolklorique = ".$_GET['gestion'] , "*" , "ORDER BY Nom,Prenom") ;
	
	$texte.= '<a name="CD"></a>' .
			 "<h2>Gestion du groupe folklorique</h2>" ;
		
	if( $artistes['nbr'] != 0 )
	{	
		$texte.= 
				"<p>Le groupe folklorique actuellement s&eacute;lectionn&eacute; compte <strong>".$artistes['nbr']."</strong> membres.</p>" .
				"<blockquote>".
				'<table cellspacing="1" cellpadding="5" width="80%" align="center" bgcolor="#999999">' .
					'<tr valign="center" height="35">' .
						'<td align="center"><font size="+1" color="#CCCCCC"><strong>Nom</strong></font></td>' .
						'<td align="center"><font size="+1" color="#CCCCCC"><strong>Pr&eacute;nom</strong></font></td>' .
						'<td align="center"><font size="+1" color="#CCCCCC"><strong>Lien</strong></font></td>' .
					'</tr>' ;
		
		for( $i = 0 ; $i < $artistes['nbr'] ; $i++ )
		{
		$texte .= 	'<tr valign="center" height="25">' .
						'<td align="center" bgcolor="#CCCCCC">' . $artistes[$i]['Nom'] . '</td>' .
						'<td align="center" bgcolor="#CCCCCC">' . $artistes[$i]['Prenom'] . '</td>' .
						'<td align="center" bgcolor="#CCCCCC"><font size="-1">' . lk('Supprimer',"gestion_gf",FALSE,"gestion=".$_GET['gestion']."&select_c=".$_GET['select_c']."&supprimer_a=".$artistes[$i]['IDArtiste']."#CD" ).'</font></td>' .
					'</tr>' ;
		}
		
		$texte.= "</table></blockquote>" ;
	}
	else
	{
		$texte .= "<p>Le groupe folklorique ne comprend actuellement aucun membre.</p>" ;
	}
	
	$texte.= "<p>Le formulaire ci-dessous vous permet d'ajouter des artistes au groupe actuellement s&eacute;lectionn&eacute;.</p>" ;
	$texte.= '<blockquote><form method="post" action="?in=gestion_gf&select_c='.$_GET['select_c'].'&gestion='.$_GET['gestion'].'#CD">' .
				'<table cellspacing="5">' .
					'<tr>' .
						'<td width="250"><p><strong>Nom :</strong></p>' .
						'<p><input type="text" name="a_nom"></p></td>' .
						'<td width="250"><p><strong>Pr&eacute;nom :</strong></p>' .
						'<p><input type="text" name="a_prenom"></p></td>' .
						'<td valign="center">' .
							html_button( 'Inscrire' , 'ajout.png' , 'Cliquez ici pour ajouter un artiste au comit&eacute;.' ) .
						'</td>' .
					'</tr>' .
				'</table></form></blockquote>' .
				"<h2>Impression</h2>" .
					lk( 'Liste' , 'gestion_gf' , FALSE , 'pdf=liste_gf&gestion='.$_GET['gestion'] , 'imprimer.png' , 'Cliquez ici pour imprimer la liste compl&egrave;te des b&eacute;n&eacute;voles inscrits &agrave; ce comit&eacute;.') .
					lk( 'Accr&eacute;ditations' , 'gestion_gf' , FALSE , 'pdf=ca_gf&gestion='.$_GET['gestion'] , 'imprimer.png' , 'Cliquez ici pour imprimer les cartes d\'accr&eacute;ditation de ce groupe.' ) ;
}
elseif( !isset( $bdp ) )
{
	$texte.= '<a name="CD"></a>' .
				"<h2>Cr&eacute;ation d'un groupe folklorique</h2>" .
				"<p>Le formulaire ci-dessous vous permet de cr&eacute;er un nouveau groupe folklorique.</p>" .
				'<blockquote><form method="post" action="?in=gestion_gf">' .
				'<table cellspacing="5">' .
					'<tr>' .
						'<td width="250"><p><strong>Nom :</strong></p>' .
						'<p><input type="text" name="gf_nom"></p></td>' .
						'<td width="250"><p><strong>Pays :</strong></p>' .
						'<p><input type="text" name="gf_pays"></p></td>' .
						'<td valign="center">' .
							html_button( 'Cr&eacute;er' , 'ajout.png' , 'Cliquez ici pour cr&eacute;er le nouvel ensemble folklorique.' ) .
						'</td>' .
					'</tr>' .
				'</table></form></blockquote>' ;
}

?>
