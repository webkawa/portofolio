<?php

niveau_securite( 1 , STRICT ) ;

$titre = "Ajout du b&eacute;n&eacute;vole au comit&eacute;" ;

if( !$bi = benevole_infos( $_GET['bid'] ) )
{
	e_erreur(8) ;
}
elseif( $_GET['bid'] == $session_infos['IDBenevole'] )
{
	e_erreur(30) ;
}
elseif( !$bi['Recommandable'] )
{
	e_erreur(45) ;
}
else
{
	journal( "Inclusion du benevole : IDBenevole[".$_GET['bid']."]-IDComite[".$session_infos['IDComite']."]" ) ;
	
	$result = inclure_benevole( $_GET['bid'] ) ;
	
	if( $result == P )			$tmp = 'principale' ;
	if( $result == S )			$tmp = 'secondaire' ;
	
	$texte = "<h2>Inscription effectu&eacute;e</h2>" .
				"<p>Le b&eacute;n&eacute;vole <strong>".$bi['Prenom']." ".$bi['Nom']."</strong> a &eacute;t&eacute; " .
				"correctement ajout&eacute; &agrave; votre comit&eacute; sur liste ".$tmp.".</p>" .
				"<blockquote>" .
					"<p>".lk("Mon comit&eacute;","mon_comite",FALSE,'','comite.png','Consulter la liste des b&eacute;n&eacute;voles inscrits &agrave; votre comit&eacute;.')."</p>" .
					"<p>".lk("Liste des b&eacute;n&eacute;voles",'liste_benevoles',FALSE,'','liste.png','Liste compl&eacute;te des b&eacute;n&eacute;voles.').'</p>' .
					"<p>".lk("Recherche d'un b&eacute;n&eacute;vole",'rechercher_benevoles',FALSE,'','chercher.png','Liste filtr&eacute;e des b&eacute;n&eacute;voles.').'</p>' .
					"<p>".lk("Profil du b&eacute;n&eacute;vole",'profil_benevoles',FALSE,'bid='.$_GET['bid'],'benevole.png','Acc&eacute;der au profil complet du b&eacute;n&eacute;vole.') . '</p>' .
				"</blockquote>" ;
}

?>
