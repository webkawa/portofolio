<?php

/*	----------------------------------------------------------------
 * 	login.php
 * 	----------------------------------------------------------------
 * 	[Description]
 * 		Fichier de déconnection du système.
 *	----------------------------------------------------------------	*/

	journal( "Deconnection du systeme" );
	unlogin() ;
	
	$titre = "D&eacute;connection" ;
	$texte = "<h2>Succ&egrave;s !</h2>" ;
	$texte.= "<p>Vous avez &eacute;t&eacute; correctement d&eacute;connect&eacute; du syst&egrave;me.</p>" ;
	$texte.= lk( "Connexion sous un autre compte" , "login" , FALSE , '' , 'connexion.png' , "Changement d'identifiants." ) .
			 lk( "Retour &agrave; l'accueil" , 'home' , FALSE , '' , 'home.png' ) ;

?>
