<?php

/*	----------------------------------------------------------------
 * 	home.php
 * 	----------------------------------------------------------------
 * 	[Description]
 * 		Page d'accueil du site.
 *	----------------------------------------------------------------	*/

$titre = "Accueil" ;

if( $_SESSION['NiveauA'] == 0 )
{
	$texte.= 	"<p>Bienvenue sur ".$global['nom'].", le nouveau syst&egrave;me d'administration du Mondial " .
				"des Cultures de Drummondville.</p>" .
				"<h2>Pourquoi ce syst&egrave;me ?</h2>" .
				"<p>Ce site a vocation d'assister l'&eacute;quipe du Mondial lors de l'organisation du festival " .
				"en impliquant directement les b&eacute;n&eacute;voles dans les travaux pr&eacute;paratoires.</p>" .
				"<h3>Vous n'&ecirc;tes ni responsable de comit&eacute;, ni membre du staff ...</h3>" .
				"<p>Le syst&egrave;me vous donne la possibilit&eacute; de visualiser les b&eacute;n&eacute;voles " .
				"inscrits pour l'ann&eacute;e &agrave; venir, ainsi que leur t&acirc;ches qui leur sont assign&eacute;es.</p>" .
				"<p>Si vous &ecirc;tes vous m&ecirc;me b&eacute;n&eacute;vole, vous pouvez consulter votre fiche en ligne.</p>" .
				lk( "Liste simple" , 'liste_benevoles' , FALSE , '' , 'liste.png' , 'Cliquez ici pour visualiser la liste compl&egrave;te des b&eacute;n&eacute;voles.' ) .
				lk( "Recherche" , 'rechercher_benevoles' , FALSE , '' , 'chercher.png' , 'Cliquez ici pour effectuer une recherche dans la liste des b&eacute;n&eacute;voles.' ) .
				lk( "Messagerie" , 'mail' , FALSE , '' , 'mail.png' , "Cliquez ici pour contacter l'&eacute;quipe du Mondial ou un de ses b&eacute;n&eacute;voles." ) .
				"<h3>Vous &ecirc;tes responsable de comit&eacute; ou membre du staff ...</h3>" . 
				"<p>Vous devez d'abord vous identifier aupr&egrave;s du syst&egrave;me.</p>" .
				lk( "Connexion" , 'login' , FALSE , '' , 'connexion.png' , 'Cliquez ici pour vous connecter &agrave; Allegro.') ;
}
if( $_SESSION['NiveauA'] == 1 )
{
	$nbr_inscrits_p		=	denombrer_sql( "Benevole" , "IDComite = ".$session_infos['IDComite'] ) ;
	$nbr_inscrits_s		=	denombrer_sql( "Benevole" , "IDComiteSecondaire = ".$session_infos['IDComite'] ) ;
	$nbr_coupons_r		=	denombrer_sql( "CouponRepas" , "IDWeb = ".$session_infos['IDWeb'] ) ;
	$nbr_coupons_r_v	=	denombrer_sql( "CouponRepas" , "IDWeb = ".$session_infos['IDWeb']." && DateUsage = '0000-00-00' && Nom = '' && Prenom = ''" ) ;
	$nbr_coupons_r_d	=	denombrer_sql( "CouponRepas" , "IDWeb = ".$session_infos['IDWeb']." && Nom = '' && Prenom = ''" ) ;
	
	$texte.=	"<h2>Mon statut</h2>" .
					"<p>Vous &ecirc;tes actuellement connect&eacute;(e) en tant que <strong>".$session_infos['Prenom']." ".$session_infos['Nom']."</strong>, " .
					"responsable du comit&eacute; <strong>".$session_infos['NomComite'].".</strong></p>" .
					"<p>L'&eacute;tat de votre comit&eacute; est le suivant :</p>" .
					"<blockquote>" .
						"<p><strong>".( $nbr_inscrits_p + $nbr_inscrits_s )."</strong> b&eacute;n&eacute;voles inscrits, dont ...</p>" .
						"<blockquote>" .
							"<p><strong>".$nbr_inscrits_p."</strong> en liste principale</p>" .
							"<p><strong>".$nbr_inscrits_s."</strong> en liste secondaire</p>" .
						"</blockquote>" .
						"<p><strong>".$nbr_coupons_r."</strong> coupons-repas &agrave; g&eacute;rer, dont ...</p>" .
						"<blockquote>" .
							"<p><strong>".$nbr_coupons_r_v."</strong> vierges</p>" .
							"<p><strong>".( $nbr_coupons_r_d - $nbr_coupons_r_v )."</strong> dat&eacute;s</p>" .
							"<p><strong>".( $nbr_coupons_r - $nbr_coupons_r_d )."</strong> attribu&eacute;s</p>" .
						"</blockquote>" .
					"</blockquote>" .
				"<h2>Navigation</h2>" .
					"<p>Que voulez-vous faire ?</p>" .
					"<blockquote>" .
						lk("Mon comit&eacute;",'mon_comite',FALSE,'','comite.png',"Cliquez ici pour consulter l'&eacute;tat de votre comit&eacute;.").
						lk("Mes coupons-repas",'gestion_cr',FALSE,'','coupons.png',"Cliquez ici pour visualiser et r&eacute;partir vos coupons-repas").
						lk("Recherche",'rechercher_benevoles',FALSE,'','chercher.png',"Cliquez ici pour obtenir une liste filtr&eacute;e des b&eacute;n&eacute;voles.") .
						lk("Nouveau b&eacute;n&eacute;vole",'inserer_benevoles',FALSE,'','ajout.png',"Cliquez ici pour ajouter un nouveau b&eacute;n&eacute;vole &agrave; la base de donn&eacute;es.").
						lk("Mes options",'profil',FALSE,'','options.png',"Cliquez ici pour acc&eacute;der aux options de votre compte.") .
					"</blockquote>" .
				"<h2>Aide</h2>" .
					"<p>En cas de probl&egrave;me, question ou blocage, la documentation utilisateur est disponible &agrave; " .
					'<a href="'.$folder['help'].'utilisateur.pdf" target="_blank">cette adresse</a>.</p>' ;
						
}
if( $_SESSION['NiveauA'] == 2 )
{
	$texte.= "lol2" ;
}
if( $_SESSION['NiveauA'] == 3 )
{
	$texte.= "lol3" ;
}
if( $_SESSION['NiveauA'] == 4 )
{
	$texte.= "<h2>Avertissement</h2>" .
			"<p>Vous &ecirc;tes actuellement logg&eacute;(e) en temps qu'administrateur principal du syst&egrave;me (root).</p>" .
			"<p>Il est conseill&eacute; de faire autant que possible usage d'un compte administrateur classique pour toutes les actions " .
			"ne relevant pas du niveau d'administrateur principal.</p>" ;
}

/* $texte .= "<h2>Options</h2>" .
			lk( 'Notes' , 'notes' , FALSE , '' , 'infos.png' , 'Cliquez ici pour consulter les notes de version.' ) ; */

?>



 