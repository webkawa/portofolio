<?php

/*	----------------------------------------------------------------
 * 	profil.php
 * 	----------------------------------------------------------------
 * 	[Description]
 * 		Page de gestion du profil.
 *	----------------------------------------------------------------	*/
 
 	niveau_securite(1) ;
 
 	// > Affichage du formulaire primaire
 	
 	$udpate = FALSE ;
 	
 	$form_sup	=	'<form method="post" action="?in=profil#BB"><blockquote>
						<p><strong>Choix de l\'action :</strong></p>' .
						'<p><select name="id_mod">' .
							'<option value="see">Affichage du profil</option>' . 
							'<option value="login">Modification du pseudonyme</option>' .
							'<option value="password">Modification du mot de passe</option>' .
							'<option value="mail">Modification de l\'adresse mail</option>' .
						'</select></p>
						<p>' .
						html_button( 'Acc&eacute;der' , 'options.png' , 'Cliquez ici pour ex&eacute;cuter l\'action s&eacute;lectionn&eacute;e.') .
						'</p></blockquote>
					</form>' ; 
 	
	$titre		=	"Gestion du profil" ;
	$texte		=	"<h2>Choix de l'information</h2>" .
						"<p>Ce formulaire vous permet d'afficher ou de modifier vos identifiants de connection au " .
						"syst&egrave;me : pseudonyme, mot de passe et adresse de messagerie. Les " .
						"informations nominatives (nom et pr&eacute;nom) ne peuvent &ecirc;tre modifi&eacute;es " .
						"que par le responsable informatique du Mondial des Cultures.</p>" .
						$form_sup ;
						
	// > Affichage du formulaire secondaire
	
	if( $_POST['id_mod'] == 'see' || $_GET['out'] == 'see' )
	{
		$texte	.=	'<a name="BB"></a>' .
					"<h2>Profil courant</h2>" .
					"<p>L'&eacute;tat de votre compte utilisateur est le suivant :</p>" .
						"<blockquote>" .
							"<p><strong>Nom : </strong>".$session_infos['Nom']."</p>" .
							"<p><strong>Pr&eacute;nom : </strong>".$session_infos['Prenom']."</p>" .
							"<p><strong>Adresse courriel : </strong>".$session_infos['Mail']."</p>" .
							"<p><strong>Pseudonyme : </strong>".$session_infos['Login']."</p>" .
							"<p><strong>Fonction : </strong>".$session_infos['Fonction']."</p>" .
							"<p><strong>Fiche b&eacute;n&eacute;vole : </strong>" .$session_infos['Benevole']['Profil']."</p>" .
						"</blockquote>" .
					"<p>En cas de probl&egrave;me avec vos donn&eacute;es personnelles (nom, pr&eacute;nom), " .
					"merci de contacter l'administration du syst&egrave;me pour obtenir une correction.</p>" .
					"<h2>Options</h2>" .
					lk('Accueil','home',FALSE,'','home.png') ;
					
		if( $session_infos['Benevole']['Nom'] )	$texte .= lk('Profil b&eacute;n&eacute;vole','profil_benevoles',FALSE,'uid='.$session_infos['Benevole']['IDBenevole'],'profil.png','Cliquez ici pour visualiser le profil b&eacute;n&eacute;vole li&eacute; &agrave; votre compte.') ;
		
		$texte	.=	lk('Signaler une erreur','mail',FALSE,'','mail.png','Cliquez ici pour signaler une erreur dans les identifiants fixes (nom, pr&eacute;nom) de votre compte.') ;
	}
	if( $_POST['id_mod'] == 'login' )
	{
		$nom_litteral	=	'pseudonyme' ;
		$nom_variable	=	'mod_pseudo' ;
		$typeform		=	'text' ;
		$def			=	$session_infos['Login'] ; 
	}
	if( $_POST['id_mod'] == 'password' )
	{
		$nom_litteral	=	'mot de passe' ;
		$nom_variable	=	'mod_password' ;
		$typeform		=	'password' ;
	}
	if( $_POST['id_mod'] == 'mail' )
	{
		$nom_litteral	=	'mail' ;
		$nom_variable	=	'mod_mail' ;
		$typeform		=	'text' ;
		$def			=	$session_infos['Mail'] ;
	}
	
	if( isset( $nom_litteral ) && isset( $nom_variable ) && isset( $typeform ) )
	{
		$form_inf	=	'<form method="post" action="?in=profil&out='.$_POST['id_mod'].'#CC"><blockquote>
							<p><strong>Nouveau '.$nom_litteral.' :</strong></p><p><input value="'.$def.'" type="'.$typeform.'" name="'.$nom_variable.'" size="25"></p>
							<p><strong>Confirmation du nouveau '.$nom_litteral.' :</strong></p><p><input value="'.$def.'" type="'.$typeform.'" name="'.$nom_variable.'_c" size="25"></p>
							<p>' .
							html_button( 'Envoyer' , 'valider.png' , 'Cliquez ici pour enregistrer vos modifications.') .
							'</p></blockquote>
						</form>' ;
						
		$texte		.=	"<h2>Modification du ".$nom_litteral."</h2>" .
							"<p>Faites usage du formulaire ci-dessous pour modifier votre ".$nom_litteral.".</p>" .
							$form_inf ;
		$help		=	"<p>Soyez attentif aux informations que vous rentrez dans ce formulaire. Elles " .
							"vous seront par la suite utiles pour vous connecter au syst&egrave;me et/ou " .
							"pour restaurer votre mot de passe en cas de perte.</p>" ;
	}
	
	// > Exécution de la requête
	
	if( isset( $_GET['out'] ) )
	{
		$requete = FALSE ;
		
		if( $_GET['out'] == 'login' )
		{
			$ver = denombrer_sql( "Web" , "Login = '".$_POST['mod_pseudo']."'" ) ;
			
			if( empty( $_POST['mod_pseudo'] ) || empty( $_POST['mod_pseudo_c'] ) )
			{
				e_erreur(4) ;
			}
			if( $_POST['mod_pseudo'] != $_POST['mod_pseudo_c'] )
			{
				e_erreur(5) ;
			}
			if( $ver != 0 )
			{
				e_erreur(44) ;
			}
			
			$on[0] = array( "Login" , $_POST['mod_pseudo'] , TRUE ) ;
			journal('MAJ-Pseudonyme : '.$session_infos['Login'].' > '.$_POST['mod_pseudo'] ) ;
			$update = TRUE ;
		}
		
		if( $_GET['out'] == 'password' )
		{
			if( empty( $_POST['mod_password'] ) || empty( $_POST['mod_password_c'] ) )
			{
				e_erreur(4) ;
			}
			if( $_POST['mod_password'] != $_POST['mod_password_c'] )
			{
				e_erreur(5) ;
			}
			if( strlen( $_POST['mod_password'] ) < $misc['taille_mdp_min'] )
			{
				e_erreur(6) ;
			}

			$on[0] = array( "MDPEncode" , sha1($_POST['mod_password']) , TRUE ) ;
			journal('MAJ-Mot de passe : '.$session_infos['MDPEncode'].' > '.sha1( $_POST['mod_password'] ) ) ;
			$update = TRUE ;
		}
		
		if( $_GET['out'] == 'mail' )
		{
			if( empty( $_POST['mod_mail'] ) || empty( $_POST['mod_mail_c'] ) )
			{
				e_erreur(4) ;
			}
			if( $_POST['mod_mail'] != $_POST['mod_mail_c'] )
			{
				e_erreur(5) ;
			}
			
			$on[0] = array( "Mail" , $_POST['mod_mail'] , TRUE ) ;
			journal('MAJ-Adresse mail : '.$session_infos['Mail'].' > '.$_POST['mod_mail'] ) ;
			$update = TRUE ;
		}
		
		if( !is_e() && $update )
		{
			update_sql( "Web" , $on , "IDWeb = ".$session_infos['IDWeb'] ) ;
			
			$texte	.=	'<a name="CC">' .
						"<h2>Modification enregistr&eacute;e</h2>" .
							"<p>La modification de votre profil a &eacute;t&eacute; correctement prise " .
							"en compte.</p>" .
							lk('Profil','profil',FALSE,'out=see','profil.png',"Cliquez ici pour voir votre profil modifi&eacute;.").
							lk("Retour &agrave; l'accueil",'home',FALSE,'','home.png') ;
		}
	}
	

?>
