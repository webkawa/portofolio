<?php

niveau_securite(2) ;

$titre = 'Liste noire' ;

if( $_GET['mode'] == 'on' && !is_e() )
{
	if( !isset( $_GET['uid'] ) || !$b_infos = benevole_infos( $_GET['uid'] ) )				e_erreur(8) ;
	if( $b_infos['Web']['NiveauAutorisation'] == 1 )										e_erreur(46) ;
	
	if( $_GET['ok'] != 1 )
	{
		$bdp = '<h2>Confirmation requise</h2>' .
				'<p>Vous avez demand&eacute; le placement du b&eacute;n&eacute;vole '.lk($b_infos['Prenom'].' '.$b_infos['Nom'],'profil_benevoles',FALSE,'uid='.$_GET['uid']).
				' sur liste noire. Cette action supprimera ce dernier de son comit&eacute; courant et rendra impossible toute inclusion ult&eacute;rieure.<p>' .
				'<p>Confirmez vous votre requ&ecirc;te ?</p>' .
				'<blockquote>' .
					'<p>' . lk( "Confirmer la mise sur liste noire" , "blacklist" , FALSE , "mode=on&ok=1&uid=".$_GET['uid']."#CC" , 'valider.png' ) . '</p>' .
					'<p>' . lk( "Annuler" , "home" , FALSE , '' , 'annuler.png' ) . '</p>' .
				'</blockquote>' ;
	}
	else
	{
		$on[0] = array( "Recommandable" , 0 , FALSE ) ;
		$on[1] = array( "IDComite" , 0 , FALSE ) ;
		$on[2] = array( "IDComiteSecondaire" , 0 , FALSE ) ;
		$on[3] = array( "IDCouleurAccreditation" , 1 , FALSE ) ;
				
		update_sql( 'Benevole' , $on , 'IDBenevole = '.$_GET['uid'] ) ;
		
		$bdp = '<h2>Succ&egrave;s</h2>' .
					'<p>Le b&eacute;n&eacute;vole a &eacute;t&eacute; plac&eacute; sur liste noire.</p>' ;
	}
}
if( $_GET['mode'] == 'off' )
{
	if( !isset( $_GET['uid'] ) || !$b_infos = benevole_infos( $_GET['uid'] ) )				e_erreur(8) ;
	if( $b_infos['Web']['NiveauAutorisation'] == 1 )										e_erreur(46) ;

	if( $_GET['ok'] != 1 )
	{
		$bdp = '<h2>Confirmation requise</h2>' .
				'<p>Vous avez demand&eacute; le retrait du b&eacute;n&eacute;vole '.lk($b_infos['Prenom'].' '.$b_infos['Nom'],'profil_benevoles',FALSE,'uid='.$_GET['uid']).
				' de la liste noire.<p>' .
				'<p>Confirmez vous votre requ&ecirc;te ?</p>' .
				'<blockquote>' .
					'<p>' . lk( "Confirmer le retrait de la liste noire" , "blacklist" , FALSE , "mode=off&ok=1&uid=".$_GET['uid']."#CC" , 'valider.png' ) . '</p>' .
					'<p>' . lk( "Annuler" , "home" , FALSE , '' , 'annuler.png' ) . '</p>' .
				'</blockquote>' ;
	}
	else
	{
		$on[0] = array( "Recommandable" , 1 , FALSE ) ;
		
		update_sql( 'Benevole' , $on , 'IDBenevole = '.$_GET['uid'] ) ;
		
		$bdp = '<h2>Succ&egrave;s</h2>' .
					'<p>Le b&eacute;n&eacute;vole a &eacute;t&eacute; retir&eacute; de la liste noire.</p>' ;
	}
}


	$liste = select_sql( "Benevole" , "!Recommandable" ) ;
	
	$infos['titre'][0] = 'Nom' ;					$infos['taille'][0] = NULL ;
	$infos['titre'][1] = 'Pr&eacute;nom' ;			$infos['taille'][1] = NULL ;
	$infos['titre'][2] = NULL ;						$infos['taille'][2] = 150 ;
	
	for( $i = 0 ; $i < $liste['nbr'] ; $i++ )
	{
		if( $liste[$i]['IDBenevole'] == $_GET['uid'] )						$_GET['select_c'] = $i ;
		
		$content[$i][0] = $liste[$i]['Nom'] ;
		$content[$i][1] = $liste[$i]['Prenom'] ;
		$content[$i][2] = lk( 'Profil' , 'profil_benevoles' , FALSE , "uid=".$liste[$i]['IDBenevole'] ) ;
	}
	
	$texte = '<h2>Liste brute</h2>' .
				'<p>La liste ci-dessous r&eacute;sume l\'ensemble des b&eacute;n&eacute;voles ayant &eacute;t&eacute; d&eacute;clar&eacute;s comme non-recommandables.</p>' .
				liste( $content , $infos , 3 , 30 ) ;
				
	$texte .= '<a name="CC"></a>' ;
	$texte .= $bdp ;

?>
