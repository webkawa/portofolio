<?php

niveau_securite(2) ;

if( !isset( $_GET['idc'] ) )
{
	$_GET['idc'] = 0 ;
	$_SESSION['RequetePDF'] = NULL ;
}

if( $_GET['ok'] == 1 && ( ( $_POST['nom'] != '' && $_POST['prenom'] != '' ) || $_POST['liste'] != 'NONE' || $_POST['inscriptible'] == TRUE ) )
{	
	$pdf['nom'] 	= $_POST['nom'] ;
	$pdf['prenom']	= $_POST['prenom'] ;
	$pdf['zone']	= $_POST['zone'] ;
	$pdf['free']	= $_POST['inscriptible'] ;
	$pdf['id']		= time().rand(1000,9999) ;
	
	if( $_POST['liste'] != 'NONE' )
	{
		$tmp = benevole_infos( $_POST['liste'] ) ;
		
		$pdf['nom'] 	= $tmp['Nom'] ;
		$pdf['prenom']	= $tmp['Prenom'] ;
	}
	
	$_SESSION['RequetePDF'][$_GET['idc']] 	= $pdf ;
	$_SESSION['RequetePDF'][$_GET['idc']+1]	= FALSE ;
	$_GET['idc']++ ;
	
	journal("Generation laisser-passer : Nom[".$_SESSION['RequetePDF'][$_GET['idc']]['nom']."]-Prenom[".$_SESSION['RequetePDF'][$_GET['idc']]['prenom']."]-Zone[".$_SESSION['RequetePDF'][$_GET['idc']]['zone']."]" ) ;
}
if( $_GET['ok'] == 1 && $_GET['idc'] > 0 )
{
	$bdp .= '<h2>PDF g&eacute;n&eacute;r&eacute;</h2>' .
				"<p>Pour afficher le PDF contenant votre s&eacute;rie de laisser-passer mis en forme, faites usage du lien ci-dessous :</p>" .
				lk_pdf( 'laisser_passer' , TRUE , "ok=2" ).
				"<p>Les informations du laisser-passer sont les suivantes :</p>" .
				"<blockquote>" .
					"<p><strong>Num&eacute;ro :</strong> ".$_SESSION['RequetePDF'][($_GET['idc']-1)]['id']."</p>" .
					"<p><strong>Pr&eacute;nom :</strong> ".vide( $_SESSION['RequetePDF'][($_GET['idc']-1)]['prenom'] )."</p>" .
					"<p><strong>Nom :</strong> ".vide( $_SESSION['RequetePDF'][($_GET['idc']-1)]['nom'] )."</p>" .
					"<p><strong>Zone :</strong> ".vide( $_SESSION['RequetePDF'][($_GET['idc']-1)]['zone'] )."</p>" .
					"<p><strong>Manuscrit :</strong> ".html_yesno( $_SESSION['RequetePDF'][($_GET['idc']-1)]['free'] )."</p>" .
				"</blockquote>" ;
}
if( $_GET['ok'] == 2 )
{
	journal("Impression laisser-passer" ) ;
}

$titre = "Impression de laisser-passer" ;
$texte = "<h2>Informations</h2>" .
			"<p>Le formulaire ci-dessous vous permet d'enregistrer une s&eacute;rie de laisser-passer &agrave; imprimer.</p>" .
			"<p>Pour enregistrer un nouveau laisser-passer, faites usage du formulaire ci-dessous et ce de m&ecirc;me tant que vous souhaiterez " .
			"ajouter des &eacute;l&eacute;ments &agrave; votre s&eacute;rie. Une fois celle-ci achev&eacute;e, cliquez sur " .
			"l'icone en milieu de page pour acc&eacute;der au PDF d'impression.</p>" .
			"<p>Vous travaillez actuellement sur le laisser-passer num&eacute;ro <strong>" . ($_GET['idc']+1) . "</strong> de votre s&eacute;rie.</p>" .
				'<blockquote><form method="post" action="?in=impression_lp&ok=1&idc='.$_GET['idc'].'"><table cellspacing="5">' .
					'<tr>' .
						'<td width="250"><p><strong>Nom du titulaire :</strong></p>' .
						'<p><input name="nom" type="text"></p></td>' .
						'<td width="250"><p><strong>Pr&eacute;nom du titulaire :</strong></p>' .
						'<p><input name="prenom" type="text"></p></td>' .
						'<td width="350"><p><strong>Choix direct </strong>(annule "Nom" et "Pr&eacute;nom") <strong>:</strong></p>' .
						'<p><select name="liste">' .
							'<option value="NONE">Personnalis&eacute;</option>' ;
					
$liste = select_sql( "Benevole" , "1" , "*" , "ORDER BY Nom,Prenom") ;					
for( $i = 0 ; $i < $liste['nbr'] ; $i++ )
{
	$texte .= '<option value="'.$liste[$i]['IDBenevole'].'">'.$liste[$i]['Prenom']." ".$liste[$i]['Nom']."</option>" ;
}
					
		$texte .= '</select></tr>' .
					'<tr valign="middle">' .
						'<td width="250"><p><strong>Zone d\'application :</strong></p>' .
						'<p><input name="zone" type="text"></p></td>' .
						'<td width="250"><p><input type="checkbox" name="inscriptible"><strong>Coupon manuscrit</strong></p>' .
						'<p>(annule les autres choix)</p></td>' .
						'<td></td>' .
					'</tr>' .
					'<tr>' .
						'<td align="center" width="350" colspan="3">'.html_button('Ajouter','ajout.png','Cliquez ici pour ajouter l\'&eacute;l&eacute;ment &agrave; la liste.') .'</td>' .
					'</tr>' .
				'</table></form></blockquote>'.$bdp ;

if( $_SESSION['RequetePDF'] )
{
	$texte .= "<h2>Liste courante</h2>" .
				"<p>Votre s&eacute;rie contient actuellement les &eacute;l&eacute;ments suivants.</p>" .
				'<blockquote><table cellspacing="1" cellpadding="5" width="80%" align="center" bgcolor="#999999">' .
					'<tr valign="center" height="35">' .
						'<td align="center"><font size="+1" color="#CCCCCC"><strong>ID</strong></font></td>' .
						'<td align="center"><font size="+1" color="#CCCCCC"><strong>B&eacute;n&eacute;ficiaire</strong></font></td>' .
						'<td align="center"><font size="+1" color="#CCCCCC"><strong>Zone</strong></font></td>' .
					'</tr>' ;
				
	for( $i = 0 ; $_SESSION['RequetePDF'][$i] ; $i++ )
	{
		if( $_SESSION['RequetePDF'][$i]['free'] == TRUE )
		{
			$texte .= '<tr valign="center" height="35">' .
						'<td align="center" bgcolor="#CCCCCC">'.$_SESSION['RequetePDF'][$i]['id'].'</td>' .
						'<td colspan="2" align="center" bgcolor="#CCCCCC">Vignette manuscrite</td>' .
					'</tr>' ;
		}
		else
		{
		$texte .= '<tr valign="center" height="35">' .
						'<td align="center" bgcolor="#CCCCCC">'.$_SESSION['RequetePDF'][$i]['id'].'</td>' .
						'<td align="center" bgcolor="#CCCCCC">'.vide(strtoupper( $_SESSION['RequetePDF'][$i]['nom'] ).' '.$_SESSION['RequetePDF'][$i]['prenom'] , MINIMAL).'</td>' .
						'<td align="center" bgcolor="#CCCCCC">'.ucfirst(vide($_SESSION['RequetePDF'][$i]['zone'],MINIMAL)).'</td>' .
					'</tr>' ;		}
	}
	
	$texte .= "</table></blockquote>" ;
}

$texte .= '<h2>Options</h2>' .
				'<p>' . lk('Recommencer','impression_lp',FALSE,'','up.png','Cliquez ici pour effacer la liste en cours.') . '</p>' .
				'<p>' . lk('Retour &agrave; l\'accueil','home',FALSE,'','home.png') . '</p>' ;

?>