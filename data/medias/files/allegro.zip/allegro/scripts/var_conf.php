<?php

niveau_securite(3) ;

$titre = "Configuration" ;
$texte = "<p>La liste ci-dessous r&eacute;sume l'&eacute;tat de la configuration du syst&egrave;me.</p>" ;

$infos['titre'][0] = "Cat&eacute;gorie" ;
$infos['titre'][1] = "Type" ;
$infos['titre'][2] = "Nom" ;
$infos['titre'][3] = "Description" ;
$infos['titre'][4] = "Valeur" ;

$infos['taille'][0]	=	75 ;
$infos['taille'][1]	=	75 ;
$infos['taille'][2]	=	150 ;
$infos['taille'][3]	=	NULL ;
$infos['taille'][4]	=	300 ;


$cb = array(
		
	// Global
	array( "GLOBAL" , 	"STRING" , 		"NOM" , 			"Nom du syst&egrave;me" , 									$global['nom'] ) ,
	array( "GLOBAL" , 	"STRING" , 		"DESC" , 			"Description du syst&egrave;me" , 							$global['desc'] ) ,
	array( "GLOBAL" , 	"STRING" , 		"MAIL" , 			"Adresse mail de l'administrateur syst&egrave;me" , 		$global['mail'] ) ,
	array( "GLOBAL" , 	"STRING" , 		"VERSION" , 		"Version du syst&egrave;me" , 								$global['version'] ) ,
	array( "GLOBAL" , 	"DATE" , 		"UPDATE" ,			"Derni&egrave;re mise &agrave; jour" , 						$global['update'] ) ,
	array( "GLOBAL" , 	"STRING" ,		"URL" ,				"URL du syst&egrave;me" ,									$global['url'] ) ,
	array( "GLOBAL" ,	"INT" ,			"ANNEE" ,			"Ann&eacute;e du prochain Mondial" ,						$global['annee'] ) ,
		
	// Dossiers
	array( "FOLDER" ,	"STRING" ,		"SYSTEME" ,			"Fichiers syst&egrave;me" ,									$folder['systeme'] ) ,
	array( "FOLDER" ,	"STRING" ,		"PHOTOS" ,			"Photographies upload&eacute;es" ,							$folder['photos'] ) ,
	array( "FOLDER" ,	"STRING" ,		"SCRIPTS" ,			"Scripts syst&egrave;me" ,									$folder['scripts'] ) ,
	array( "FOLDER" ,	"STRING" ,		"PDF" ,				"Scripts PDF" ,												$folder['pdf'] ) ,
	array( "FOLDER" ,	"STRING" ,		"PDF_LIB" ,			"Librairies de g&eacute;n&eacute;ration PDF" ,				$folder['pdf_lib'] ) ,
	array( "FOLDER" ,	"STRING" , 		"PALETTE" ,			"Palette interactive" ,										$folder['palette'] ) ,
	array( "FOLDER" ,	"STRING" , 		"HELP" ,			"Documentation" ,											$folder['help'] ) ,
		
	// SQL
	array( "SQL" ,		"STRING" ,		"SERVEUR" ,			"Adresse du serveur SQL" ,									$sql['serveur'] ) ,
	array( "SQL" ,		"STRING" ,		"LOGIN" ,			"Login pour connexion au serveur" ,							$sql['login'] ) ,
	array( "SQL" ,		"STRING" ,		"PASSWORD" ,		"Mot de passe pour connexion au serveur" ,					$sql['password'] ) ,
	array( "SQL" ,		"STRING" ,		"BDD" ,				"Nom de la base de donn&eacute;es" ,						$sql['bdd'] ) ,
	
	// FTP
	
	array( "FTP" ,		"STRING" ,		"SERVEUR" ,			"Adresse du serveur FTP" ,									$ftp['serveur'] ) ,
	array( "FTP" ,		"STRING" ,		"LOGIN" ,			"Login pour connexion au serveur" ,							$ftp['login'] ) ,
	array( "FTP" ,		"STRING" ,		"PASSWORD" ,		"Mot de passe pour connexion au serveur" ,					$ftp['password'] ) ,
	array( "FTP" ,		"STRING" ,		"ROOT" ,			"Adresse racine locale" ,									$ftp['root'] ) ,
	
	// Divers
	array( "MISC" ,		"INT" ,			"CLISTE" ,			"Nombre de r&eacute;sultats affich&eacute;s par liste" ,	$misc['cliste'] ) ,
	array( "MISC" ,		"STRING" ,		"RESP_INFO" ,		"Nom du responsable informatique" ,							$misc['resp_info'] ) ,
	array( "MISC" ,		"STRING" ,		"RESP_INFO_NUM" ,	"Num&eacute;ro du responsable informatique" ,				$misc['resp_info_num'] ) ,
	array( "MISC" ,		"INT" ,			"TAILLE_MDP_MIN" ,	"Taille minimale d'un mot de passe" ,						$misc['taille_mdp_min'] ) ,
	array( "MISC" ,		"INT" ,			"TAILLE_MDP_DEF" ,	"Taille des mots de passe par d&eacute;faut" ,				$misc['taille_mdp_def'] ) ,
	array( "MISC" , 	"STRING" ,		"PHOTO_DEFAUT" ,	"Adresse de la photographie par d&eacute;faut" ,			$misc['photo_defaut'] ) ,
	array( "MISC" ,		"STRING" ,		"MESSAGE_NUL" ,		"Message envoy&eacute; pour une valeur vide" ,				$misc['message_nul'] ) ,
	array( "MISC" ,		"INT" ,			"IMG_MAXW" ,		"Largeur maximale des portraits" ,							$misc['img_maxw'] ) ,
	array( "MISC" ,		"INT" ,			"IMG_MAXH" ,		"Hauteur maximale des portraits" ,							$misc['img_maxh'] ) ,
	array( "MISC" ,		"INT" ,			"IMG_MAXS" ,		"Taille maximale d'un portrait en Ko" ,						$misc['img_maxs'] ) ,
	
		) ;
		
for( $i = 0 ; isset( $cb[$i] ) ; $i++ )
{
	$contenu[$i][0] = '<font size="-1">[ '.$cb[$i][0].' ]</font>' ;
	$contenu[$i][1] = '<font size="-1">[ '.$cb[$i][1].' ]</font>' ;
	$contenu[$i][2] = '<font size="-1">[ '.$cb[$i][2].' ]</font>' ;
	$contenu[$i][3] = '<font size="-1">'.$cb[$i][3].'</font>' ;
	$contenu[$i][4] = $cb[$i][4] ;
}


$texte .= liste( $contenu , $infos , 5 , 30 ) ;

?>
