<?php

niveau_securite(1) ;

// Traitement de l'action

if( $_GET['ok'] == 1 )
{
	$p_infos = benevole_infos( $_GET['bid'] ) ;
	$cr_maj = FALSE ;
	
	if( $_GET['action'] == 'primaires' )
	{
		if( $_POST['sexe'] == 'h' )						$sexe = 0 ;
		else											$sexe = 1 ;
		
		if( empty( $_POST['nom'] ) || empty( $_POST['prenom'] ) ) 				e_erreur(15) ;
		
		if( !$contenu['erreur'] )
		{
			$on[0] = array( 'Nom' , $_POST['nom'] , TRUE ) ;
			$on[1] = array( 'Prenom' , $_POST['prenom'] , TRUE ) ;
			$on[2] = array( 'Sexe' , $sexe , FALSE ) ;
			
			$cr_maj[0] = array( 'Nom' , $_POST['nom'] , TRUE ) ;
			$cr_maj[1] = array( 'Prenom' , $_POST['prenom'] , TRUE ) ;
		}
	}
	if( $_GET['action'] == 'perso' )
	{
		if( $_POST['ville'] == 'NULL' )						$_POST['ville'] = $_POST['ville_autre'] ;
	
		if( !checkdate( $_POST['mm'] , $_POST['jj'] , $_POST['aaaa'] ) )				e_erreur(18) ;
		if( !depassee( $_POST['jj'] , $_POST['mm'] , $_POST['aaaa'] ) )					e_erreur(18) ;
		if( empty( $_POST['adresse'] ) )												e_erreur(20) ;
		if( empty( $_POST['ville'] ) )													e_erreur(34) ;
		if( empty( $_POST['telephone_p'] ) || strlen( $_POST['telephone_p'] ) != 10 )	e_erreur(21) ;
		if( $_POST['telephone_s'] != '' && strlen( $_POST['telephone_s'] ) != 10 )		e_erreur(21) ;
		if( strlen( $_POST['cp'] ) != 6 )												e_erreur(35) ;
		if( empty( $_POST['province'] ) )												e_erreur(36) ;
		if( $_POST['mail'] != '' && !valider_mail( $_POST['mail'] ) )					e_erreur(16) ;
		
		if( !$contenu['erreur'] )
		{
			$on[0] = array( 'DateNaissance' , $_POST['aaaa'].'-'.$_POST['mm'].'-'.$_POST['jj'] , TRUE ) ;
			$on[1] = array( 'Adresse' , $_POST['adresse'] , TRUE ) ;
			$on[2] = array( 'Ville' , $_POST['ville'] , TRUE ) ;
			$on[3] = array( 'TelephoneFixe' , $_POST['telephone_p'] , TRUE ) ;
			$on[4] = array( 'TelephoneCellulaire' , $_POST['telephone_s'] , TRUE ) ;
			$on[5] = array( 'CodePostal' , $_POST['cp'] , TRUE ) ;
			$on[6] = array( 'Province' , $_POST['province'] , TRUE ) ;
			$on[7] = array( 'Mail' , $_POST['mail'] , TRUE ) ;
		}
	}
	if( $_GET['action'] == 'photo' )
	{	
		$tmp = FALSE ;
		
		if( $_POST['statut'] )								$_POST['statut'] = 1 ;
		else												$_POST['statut'] = 0 ;		
		
		$tmp = upload( $_GET['bid'] ) ;
		
		if( $tmp == ERREUR_TYPE )														e_erreur(40);
		if( $tmp == ERREUR_POIDS )														e_erreur(39);
		if( $tmp == ERREUR_LARGEUR || $tmp == ERREUR_HAUTEUR)							e_erreur(40);
		
		if( !is_e() )
		{
			$on[0] = array( 'Statut' , $_POST['statut'] , FALSE ) ;
			
			if( $tmp )
			{
				$on[1] = array( 'Photo' , $tmp , TRUE ) ;
			}	
		}
	}
	if( $_GET['action'] == 'activite' )
	{
		if( $_POST['fonction'] == 'NULL' )
		{
			$_POST['fonction'] = $_POST['fonction_autre'] ;	
		}
		if( $_POST['comite'] == 0 && $_POST['comite_s'] != 0 )
		{
			$_POST['comite'] = $_POST['comite_s'] ;
			$_POST['comite_s'] = 0 ;
		}
		
		if( empty( $_POST['fonction'] ) )														e_erreur(37) ;
		if( !$p_infos['Recommandable'] && ( $_POST['comite'] != 0 || $_POST['comite_s'] != 0 ))	e_erreur(45) ;
		
		$on[0] = array( 'Fonction' , $_POST['fonction'] , TRUE ) ;
		$on[1] = array( 'IDComite' , $_POST['comite'] , FALSE ) ;
		$on[2] = array( 'IDComiteSecondaire' , $_POST['comite_s'] , FALSE ) ;
	}
	if( $_GET['action'] == 'admin' )
	{
		if( empty( $_POST['horaire'] ) )				$_POST['horaire'] = 0 ;
		
		if( !is_numeric( $_POST['horaire'] ) )													e_erreur(43) ;
		if( !$p_infos['Recommandable'] && $_POST['na'] != 1 )									e_erreur(47) ;
		
		$on[0] = array( "Zone" , $_POST['zone'] , FALSE ) ;
		$on[1] = array( "Heures" , $_POST['horaire'] , FALSE ) ;
		$on[2] = array( "IDCouleurAccreditation" , $_POST['na'] , FALSE ) ;
	}
	
	if( !is_e() )
	{
		update_sql( "Benevole" , $on , "IDBenevole = ".$_GET['bid'] ) ;
		journal( "Modification du benevole : IDBenevole[".$_GET['bid']."]-Type[".$_GET['action']."]" ) ;
		
		if( $cr_maj )
		{
			update_sql( "CouponRepas" , $cr_maj , "Nom = '".$_POST['nom']."' && Prenom = '".$_POST['prenom']."'" , "LIMIT 2000" ) ;
		}
		
		$texte .= "<h2>Modification prise en compte</h2>" .
					"<p>La derni&egrave;re modification a &eacute;t&eacute; correctement prise en compte.</p>".
					lk("Profil",'profil_benevoles',FALSE,'bid='.$_GET['bid'],'profil.png','Retour au profil du b&eacute;n&eacute;vole.') .
					lk("Retour &agrave; l'accueil",'home',FALSE,'','home.png') ;
	}
}

// Sélection des informations de base

if( !isset( $_GET['bid'] ) )									$_GET['bid'] = -1 ;

$b_infos = select_sql( "Benevole" , "IDBenevole = ".$_GET['bid'] ) ;

if( $b_infos['nbr'] != 1 )
{
	f_erreur( 32 , 'modifier_benevole.php' , 1 , 'Benevole inexistant : IDBenevole['.$_GET['bid'].']' ) ;
}

// Message d'accueil

$titre 	=	"Modification du profil" ;
$texte	.=	"<h2>Choix du formulaire</h2>" .
			"<p>Vous avez demand&eacute; &agrave; modifier le profil de ".lk( $b_infos['Prenom']." ".$b_infos['Nom'] , "profil_benevoles" , FALSE , "uid=".$b_infos['IDBenevole'] ).".</p>" .
			"<p>Les informations dont vous pouvez r&eacute;aliser l'&eacute;dition sont les suivantes :</p>" ;
			
if( $session_infos['NiveauAutorisation'] > 0 )
{
	$texte .= lk( "Informations primaires" , "modifier_benevole" , FALSE , "bid=".$_GET['bid']."&action=primaires&ok=0#CC",'clef.png','Cliquez ici pour modifier le nom, le pr&eacute;nom ou le sexe de ce b&eacute;n&eacute;vole.' ) ;
	$texte .= lk( "Photographie" , "modifier_benevole" , FALSE , "bid=".$_GET['bid']."&action=photo&ok=0#CC",'photo.png','Cliquez ici pour uploader une nouvelle photographie pour le b&eacute;n&eacute;vole.' ) ;
}
if( voir_confidentiel( $_GET['bid'] ) )
{
	$texte .= lk( "Informations personnelles" , "modifier_benevole" , FALSE , "bid=".$_GET['bid']."&action=perso&ok=0#CC",'modifier_infos.png','Cliquez ici pour modifier les informations g&eacute;n&eacute;rales du b&eacute;n&eacute;vole.' ) ;
}
if( $session_infos['NiveauAutorisation'] > 1 )
{
	$texte .= lk( "Activit&eacute; & Comit&eacute;" , "modifier_benevole" , FALSE , "bid=".$_GET['bid']."&action=activite&ok=0#CC",'activite.png','Cliquez ici pour modifier la fonction ou le comit&eacute; courant du b&eacute;n&eacute;vole.' ) ;
	$texte .= lk( "Informations administratives" , "modifier_benevole" , FALSE , "bid=".$_GET['bid']."&action=admin&ok=0#CC" ,'admin_infos.png','Cliquez ici pour modifier le volume horaire, la zone d\'activit&eacute; ou le niveau d\'accr&eacute;ditation du b&eacute;n&eacute;vole.') ;
}

// Formulaire

if( isset( $_GET['action'] ) && $_GET['ok'] != 1 )
{
	$texte .= '<a name="CC"></a>' ;
	
	if( $_GET['action'] == 'primaires' )
	{
		niveau_securite(1) ;
		
		// Liste à choix
		
		if( $b_infos['Sexe'] )							$check[1] = 'selected' ;
		else											$check[0] = 'selected' ;
		
		// Formulaire
		
		$texte .= "<h2>Informations primaires</h2>" .
					"<p>Le formulaire ci-dessous vous permet de modifier les informations primaires du b&eacute;n&eacute;vole.</p>" .
					'<blockquote><form method="post" action="?in=modifier_benevole&bid='.$_GET['bid'].'&action='.$_GET['action'].'&ok=1">' .
					'<table cellspacing="10">' .
						'<tr>' .
							'<td>' .
								'<p><strong>Qualit&eacute; :</strong></p>' .
								'<p><select name="sexe">' .
									'<option value="h" '.$check[0].'>Monsieur</option>' .
									'<option value="f" '.$check[1].'>Madame</option>' .
								'</select></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>Nom :</strong></p>' .
								'<p><input type="text" name="nom" value="'.$b_infos['Nom'].'"></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>Pr&eacute;nom :</strong></p>' .
								'<p><input type="text" name="prenom" value="'.$b_infos['Prenom'].'"></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								html_button( 'Modifier' , 'valider.png' , 'Cliquez ici pour enregistrer vos modifications.') .
							'</td>' .
						'</tr>' .
					'</table>' .
					"</form></blockquote>" ;
	}
	if( $_GET['action'] == 'perso' )
	{
		if( !voir_confidentiel( $_GET['bid'] ) )						e_erreur(2) ;
		
		// Listes à choix
		
		$check['DN'][substr($b_infos['DateNaissance'],5,2)] = 'selected' ;
		
		// Formulaire
		
		$texte .= "<h2>Informations personnelles</h2>" .
					"<p>Le formulaire ci-dessous vous permet de modifier les informations personnelles du b&eacute;n&eacute;vole s&eacute;lectionn&eacute;.</p>" .
					"<p><strong>Note :</strong> les champs marqu&eacute;s d'une &eacute;toile sont obligatoires.</p>" .
					'<blockquote><form method="post" action="?in=modifier_benevole&bid='.$_GET['bid'].'&action='.$_GET['action'].'&ok=1">' .
					'<table cellspacing="10">' .
						'<tr>' .
							'<td>' .
								'<p><strong>* Date de naissance :</strong></p>' .
								'<p>' .
									'<input type="text" maxlength="2" size="5" name="jj" value="'.substr( $b_infos['DateNaissance'] , 8 , 2 ).'">' .
									'<select name="mm">' .
										'<option value="01" '.$check['DN'][01].'>Janvier</option>' .
										'<option value="02" '.$check['DN'][02].'>F&eacute;vrier</option>' .
										'<option value="03" '.$check['DN'][03].'>Mars</option>' .
										'<option value="04" '.$check['DN'][04].'>Avril</option>' .
										'<option value="05" '.$check['DN'][05].'>Mai</option>' .
										'<option value="06" '.$check['DN'][06].'>Juin</option>' .
										'<option value="07" '.$check['DN'][07].'>Juillet</option>' .
										'<option value="08" '.$check['DN'][08].'>Aout</option>' .
										'<option value="09" '.$check['DN'][09].'>Septembre</option>' .
										'<option value="10" '.$check['DN'][10].'>Octobre</option>' .
										'<option value="11" '.$check['DN'][11].'>Novembre</option>' .
										'<option value="12" '.$check['DN'][12].'>D&eacute;cembre</option>' .
									'</select>' .
									'<input type="text" maxlength="4" size="10" name="aaaa" value="'.substr( $b_infos['DateNaissance'] , 0 , 4 ).'">' .
								'</p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>* Adresse :</strong></p>' .
								'<p><input type="text" name="adresse" value="'.$b_infos['Adresse'].'"></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>* Ville :</strong></p>' .
								'<p><select name="ville">' ;
							
		$tmp = select_sql( "Benevole" , "1" , "DISTINCT Ville", "ORDER BY Ville" ) ;
		
		for( $i = 0 ; $i < $tmp['nbr'] ; $i++ )
		{
			if( $tmp[$i]['Ville'] == $b_infos['Ville'] )			$tmp2 = 'selected' ;
			else													$tmp2 = '' ;
			
			$texte.= '<option name="'.$tmp[$i]['Ville'].'" '.$tmp2.'>'.$tmp[$i]['Ville'].'</option>' ;
		}
				
					$texte.=	'<option name="NULL">Autre :</option>' .
								'<input type="text" maxlength="32" size="20" name="ville_autre"></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>* Code Postal & Province :</strong></p>' .
								'<p><input type="text" maxlength="6" size="5" name="cp" value="'.$b_infos['CodePostal'].'"><input type="text" value="'.$b_infos['Province'].'" maxlength="32" size="20" name="province"></p>' .
								'<p><font size="-1">Code postal &agrave; 6 caract&egrave;res uniquement (ni espace, ni tiret)</font></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>* T&eacute;l&eacute;phone fixe :</strong></p>' .
								'<p><input type="text" name="telephone_p" maxlength="10" size="15" value="'.$b_infos['TelephoneFixe'].'"></p>' .
								'<p><font size="-1">Num&eacute;ro &agrave; dix chiffres uniquement (ni espace, ni tirets)</font></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>T&eacute;l&eacute;phone cellulaire :</strong></p>' .
								'<p><input type="text" name="telephone_s" maxlength="10" size="15" value="'.$b_infos['TelephoneCellulaire'].'"></p>' .
								'<p><font size="-1">Num&eacute;ro &agrave; dix chiffres uniquement (ni espace, ni tirets)</font></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>Adresse de messagerie :</strong></p>' .
								'<p><input type="text" name="mail" maxlength="64" size="20" value="'.$b_infos['Mail'].'"></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								html_button( 'Modifier' , 'valider.png' , 'Cliquez ici pour enregistrer vos modifications.') .
							'</td>' .
						'</tr>' .
					'</table>' .
					'</form></blockquote>'  ;
	}
	if( $_GET['action'] == 'photo' )
	{
		niveau_securite(1) ;
		
		if( $b_infos['Statut'] )								$tmp = 'checked' ;
		
		$texte .= "<h2>Photographie</h2>" .
					"<p>Le formulaire ci-dessous vous permet de mettre &agrave; jour la photographie du b&eacute;n&eacute;vole.</p>" .
					'<blockquote><form enctype="multipart/form-data" method="post" action="?in=modifier_benevole&bid='.$_GET['bid'].'&action='.$_GET['action'].'&ok=1"><table cellspacing="10">' .
						'<tr>' .
							'<td>' .
								'<p><strong>Photographie :</strong></p>' .
								'<p><input type="file" name="photo"></p>' .
								'<font size="-1"><p>Rappel des maximas : '.$misc['img_maxw'].'x'.$misc['img_maxh'].'PX - '.$misc['img_maxs'].'Ko</p>' .
								'<p>Pour plus d\'informations, se r&eacute;f&eacute;rer &agrave; la documentation utilisateur.</p></font>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>Diffusion de l\'image :</strong></p>' .
								'<p><input type="checkbox" name="statut" '.$tmp.'>Photographie publique (visible de tous)</p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								html_button( 'Modifier' , 'valider.png' , 'Cliquez ici pour enregistrer vos modifications.') .
							'</td>' .
						'<tr>' .
					'</table></form></blockquote>' ;
	}
	if( $_GET['action'] == 'activite' )
	{
		niveau_securite(2) ;
		
		$texte .= 	"<h2>Activit&eacute;</h2>" .
					"<p>Le formulaire ci-dessous vous permet de modifier les informations relatives &agrave; l'activit&eacute; " .
					"du b&eacute;n&eacute;vole.</p>" .
					'<blockquote><form method="post" action="?in=modifier_benevole&bid='.$_GET['bid'].'&action='.$_GET['action'].'&ok=1"><table cellspacing="10">' .
						'<tr>' .
							'<td>' .
								'<p><strong>Comit&eacute; principal :</strong></p>' .
								'<p><select name="comite">' ;
									
			$tmp = select_sql( "Comite" , "1" , "*" , "ORDER BY Nom" );
			
			for( $i = 0 ; $i < $tmp['nbr'] ; $i++ )
			{
				if( $b_infos['IDComite'] == $tmp[$i]['IDComite'] )			$tmp2 = 'selected' ;
				else														$tmp2 = '' ;
				
				$texte .= '<option value="'.$tmp[$i]['IDComite'].'" '.$tmp2.'>'.$tmp[$i]['Nom'].'</option>' ;
			}
		
		$texte .=				'</select></p>' .
							'</td>' .
						'<tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>Comit&eacute; secondaire :</strong></p>' .
								'<p><select name="comite_s">' ;
									
			$tmp = select_sql( "Comite" , "1" , "*" , "ORDER BY Nom" );
			
			for( $i = 0 ; $i < $tmp['nbr'] ; $i++ )
			{
				if( $b_infos['IDComiteSecondaire'] == $tmp[$i]['IDComite'] )		$tmp2 = 'selected' ;
				else																$tmp2 = '' ;
				
				$texte .= '<option value="'.$tmp[$i]['IDComite'].'" '.$tmp2.'>'.$tmp[$i]['Nom'].'</option>' ;
			}
		
		$texte .=				'</select></p>' .
							'</td>' .
						'<tr>' .
						'</tr>' .
							'<td>' .
								'<p><strong>Fonction :</strong></p>' .
								'<p>' .
									'<select name="fonction">' ;
									
		$tmp = select_sql( "Benevole" , "1" , "DISTINCT Fonction" , "ORDER BY Fonction" ) ;
		
		for( $i = 0 ; $i < $tmp['nbr'] ; $i++ )
		{
			if( $b_infos['Fonction'] == $tmp[$i]['Fonction'] )				$tmp2 = 'selected' ;
			else															$tmp2 = '' ;
			
			$texte .= '<option value="'.$tmp[$i][0].'" '.$tmp2.'>'.$tmp[$i][0].'</option>' ;
		}
		
		$texte .=						'<option value="NULL">Autre :</option>' .
									'</select>' .
									'<input type="text" name="fonction_autre">' .
								'</p>' .
							'</td>' .
						'<tr>' .
						'</tr>' .
							'<td>' .
								html_button( 'Modifier' , 'valider.png' , 'Cliquez ici pour enregistrer vos modifications.') .
							'</td>' .
						'</tr>' .
					'</table></form></blockquote>' ;
	}
	if( $_GET['action'] == 'admin' )
	{
		niveau_securite(2) ;
		
		$texte .= "<h2>Informations administratives</h2>" .
					"<p>Le formulaire ci-dessous vous permet de modifier les informations administratives relatives au b&eacute;n&eacute;vole.</p>" .
					'<blockquote><form method="post" action="?in=modifier_benevole&bid='.$_GET['bid'].'&action='.$_GET['action'].'&ok=1"><table cellspacing="10">' .
						'<tr>' .
							'<td>' .
								'<p><strong>Volume horaire estim&eacute; :</strong></p>' .
								'<p><input type="text" maxlength="2" name="horaire" value="'.$b_infos['Heures'].'" size="5">h</p>' .
								'<p><font size="-1">Laisser vacant ou nul si inconnu</font></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' ;
						
	$tmp1 = '' ;
	$tmp2 = '' ;
	if( $b_infos['Zone'] )					$tmp1 = 'checked' ;
	else									$tmp2 = 'checked' ;
						
				$texte .=	'<td>' .
								'<p><strong>Zone d\'activit&eacute; :</strong></p>' .
								'<p><input type="radio" name="zone" value="0" '.$tmp2.'>Site <input type="radio" name="zone" value="1" '.$tmp1.'>H&eacute;bergement</p>' .
							'</td>' .
						'</tr>' ;
	
	if( $session_infos['NiveauAutorisation'] > 1 )
	{
		$tmp = select_sql( "CouleurAccreditation" , "IDCouleurAccreditation != 1" , "*" , "ORDER BY Nom" );
		
		$texte .=		'<tr>' .
							'<td>' .
								'<p><strong>Niveau d\'accr&eacute;ditation :</strong></p>' .
								'<p><select name="na">' ;
									
		for( $i = 0 ; $i < $tmp['nbr'] ; $i++ )
		{
			$tmp2 = '' ;
			if( $b_infos['IDCouleurAccreditation'] == $tmp[$i]['IDCouleurAccreditation'] )		$tmp2 = 'selected' ;
			
			$texte.= '<option value="'.$tmp[$i]['IDCouleurAccreditation'].'" '.$tmp2.'>'.$tmp[$i]['Nom'].'</option>' ;
		}
		
		$texte.=					'</select></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								html_button( 'Modifier' , 'valider.png' , 'Cliquez ici pour enregistrer vos modifications.') .
							'</td>' .
						'</tr>' ;
	}
					
	$texte .=	'</table></form></blockquote>' ;
	}
}

?>
