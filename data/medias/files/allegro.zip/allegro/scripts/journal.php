<?php

// Définition du tableau

$liste_logs 	= select_sql( "Journal" , "IDWeb = ".$_SESSION['UID'] , '*' , 'ORDER BY Date DESC' );

$infos['titre'][0]	=	"ID" ;							$infos['taille'][0]	=	50 ;
$infos['titre'][1]	=	"Date" ;						$infos['taille'][1]	=	120 ;
$infos['titre'][2]	=	"Script" ;						$infos['taille'][2]	=	120 ;
$infos['titre'][3]	=	"Retour" ;						$infos['taille'][3]	=	200 ;
$infos['titre'][4]	=	"Commentaires" ;				$infos['taille'][4]	=	NULL ;

for( $i = 0 ; $i < $liste_logs['nbr'] ; $i++ )
{
	if( empty( $liste_logs[$i]['Commentaires'] ) )					$liste_logs[$i]['Commentaires'] = 'N/A' ;
	if( empty( $liste_logs[$i]['Retour']) )							$liste_logs[$i]['Retour']		= 'En cours d\'ex&eacute;cution' ;
	
	$contenu[$i][0]	=	'<font size="-1">'.$liste_logs[$i]['IDIndex'].'</font>' ;
	$contenu[$i][1]	=	'<font size="-1">'.$liste_logs[$i]['Date'].'</font>' ;
	$contenu[$i][2]	=	'<font size="-1">'.$liste_logs[$i]['Script'].'</font>' ;
	$contenu[$i][3]	=	'<font size="-1">'.$liste_logs[$i]['Retour'].'</font>' ;
	$contenu[$i][4]	=	'<font size="-1">'.$liste_logs[$i]['Commentaires'].'</font>' ;
}

// Renvoi

$titre		=	'Journal personnel' ;
$texte		=	'<p>Vous trouverez ci-dessous la liste des enregistrements r&eacute;alis&eacute;s par le syst&egrave;me &agrave; votre nom.</p>' .
					'<p>Ces informations permettent au administrateurs du site d\'assurer le bon respect des conditions d\'utilisation par chacun des membres inscrits.' .
					'Celles-ci sont confidentielles et ne sont diffus&eacute;es qu\'en cas de n&eacute;cessit&eacute;.</p>' .
					'<h2>Liste des logs</h2>' .
					liste( $contenu , $infos , 5 , 20 , 1 , 50 ) ;
$help		=	'<p>Cette page est essentiellement adress&eacute;e aux administrateurs du syst&egrave;me. Il n\'y figure aucune fonctionnalit&eacute; ayant directement trait au mondial.</p>' ;

?>
