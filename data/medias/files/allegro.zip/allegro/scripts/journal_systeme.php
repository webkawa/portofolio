<?php

niveau_securite(3) ;

$liste_f = select_sql("Web","1","*","ORDER BY NiveauAutorisation") ;

$titre .= "Journal syst&egrave;me" ;
$texte .= "<h2>Choix du compte</h2>" .
			"<p>Cette page vous permet de visualiser les logs du syst&egrave;me par s&eacute;rie de un ou deux comptes.</p>" .
			"<p>Faites usage du formulaire ci-dessous pour s&eacute;lectionner vos filtres :</p>" .
			'<blockquote>' .
				'<form method="post" action="?in=journal_systeme">' .
					'<table cellspacing="5">' .
						'<tr>' .
							'<td width="250"><p><strong>Filtre primaire :</strong></p>' .
							'<p><select name="fp">' .
								'<option value="all">Tout le monde</option>'.
								'<option value="u">Tous les utilisateurs</option>' .
								'<option value="m">Tous les mod&eacute;rateurs</option>' .
								'<option value="a">Tous les administrateurs</option>' ;
								
	for( $i = 0 ; $i < $liste_f['nbr'] ; $i++ )
	{
		$texte .= '<option value="'.$liste_f[$i]['IDWeb'].'">['.$liste_f[$i]['NiveauAutorisation'].'] '.$liste_f[$i]['Nom'].' '.$liste_f[$i]['Prenom'].'</option>' ;
	} 
	
				$texte.= 	'</select></p></td>' .
							'</td><td width="250"><p><strong>Filtre secondaire :</strong></p>' .
							'<p><select name="fs">' .
								'<option value="u">Tous les utilisateurs</option>' .
								'<option value="m">Tous les mod&eacute;rateurs</option>' .
								'<option value="a">Tous les administrateurs</option>' ;
								
	for( $i = 0 ; $i < $liste_f['nbr'] ; $i++ )
	{
		$texte .= '<option value="'.$liste_f[$i]['IDWeb'].'">['.$liste_f[$i]['NiveauAutorisation'].'] '.$liste_f[$i]['Nom'].' '.$liste_f[$i]['Prenom'].'</option>' ;
	}
	
				$texte.=	'</select></p>' .
						'</td><td valign="middle"><input type="submit" value="Voir">' .
							'</td>' .
						'</tr>' .
					'</table></form></blockquote>' ;
					
if( isset( $_POST['fp'] ) )
{
	// Définition du filtre primaire
	
	if( $_POST['fp'] == 'all' )							$fp_sql = '1' ;
	elseif( $_POST['fp'] == 'u' )						$fp_sql = 'W.NiveauAutorisation = 1' ;
	elseif( $_POST['fp'] == 'm' )						$fp_sql = 'W.NiveauAutorisation = 2' ;
	elseif( $_POST['fp'] == 'a' )						$fp_sql = 'W.NiveauAutorisation = 3' ;
	else												$fp_sql = 'W.IDWeb = '.$_POST['fp'] ;
	
	// Définition du filtre secondaire
	
	if( $_POST['fs'] == 'u' )							$fs_sql = 'W.NiveauAutorisation = 1' ;
	elseif( $_POST['fs'] == 'm' )						$fs_sql = 'W.NiveauAutorisation = 2' ;
	elseif( $_POST['fs'] == 'a' )						$fs_sql = 'W.NiveauAutorisation = 3' ;
	else												$fs_sql = 'W.IDWeb = '.$_POST['fs'] ;
	
	// Recherche
	
	$logs = select_sql( "Journal J, Web W" , "J.IDWeb = W.IDWeb && ( ".$fp_sql." || ".$fs_sql." )" , "W.Nom , W.Prenom , W.NiveauAutorisation , J.*" , "ORDER BY J.Date DESC" ) ;
		
	if( !$logs['nbr'] ) 											e_erreur(7) ;
		
	// Définition du tableau
	
	$infos['titre'][0]	=	"Signataire" ;			$infos['taille'][0]	=	150 ;
	$infos['titre'][1]	=	"Date" ;				$infos['taille'][1]	=	150 ;
	$infos['titre'][2]	=	"Script" ;				$infos['taille'][2]	=	100 ;
	$infos['titre'][3]	=	"Retour" ;				$infos['taille'][3]	=	NULL ;
	$infos['titre'][4]	=	"Commentaires" ;		$infos['taille'][4]	=	200 ;
	
	for( $i = 0 ; $i < $logs['nbr'] ; $i++ )
	{
		$contenu[$i][0]	=	'<font size="-1">'.$logs[$i][0].' '.$logs[$i][1].'<br>'.type_compte( $logs[$i][2] ).'</font>' ;
		$contenu[$i][1]	=	'<font size="-1">'.$logs[$i][5].'</font>' ;
		$contenu[$i][2]	=	'<font size="-1">'.$logs[$i][6].'</font>' ;
		$contenu[$i][3]	=	'<font size="-1">'.$logs[$i][7].'</font>' ;
		
		if( empty( $logs[$i][8] ) )					$contenu[$i][4] = '<font size="-1">N/A</font>' ;
		else										$contenu[$i][4]	= '<font size="-1">'.$logs[$i][8].'</font>' ;
	}
}
if( isset( $_POST['fp'] ) || appel_liste() )
{
	$texte .= "<h2>Liste filtr&eacute;e</h2>" .
			liste( $contenu , $infos , 5 , 20 , 1 , 50 ) ; ;
}

?>
