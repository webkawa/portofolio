<?php

niveau_securite(2) ;

$titre = 'Identification' ;
$texte = "<h2>Formulaire de recherche</h2>" .
			"<p>Le formulaire ci-dessous vous permet de rechercher un coupon-repas &agrave; partir de son num&eacute;ro.</p>" .
			'<blockquote>' .
				'<form method="post" action="?in=id_cr">' .
					'<table>' .
						'<tr>' .
							'<td>' .
								'<p><strong>Num&eacute;ro du coupon-repas :</strong></p>' .
								'<p><input type="text" name="id" value="'.$_POST['id'].'"></p>' .
							'</td>' .
							'<td>' .
								html_button( 'Rechercher' , 'chercher.png' , 'Afficher les informations li&eacute;es au coupon-repas.' ) .
							'</td>' .
						'</tr>' .
					'</table>' .
				'</form>' .
			'</blockquote>' ;
			
if( isset( $_POST['id'] ) )
{
	$coupon 		= select_sql( "CouponRepas" , "IDCouponRepas = ".$_POST['id'] ) ;
	
	$texte .=	"<h2>R&eacute;sultat</h2>" ;
	
	if( $coupon['nbr'] == 1 )
	{
		$responsable	= select_sql( "Web" , "IDWeb = ".$coupon['IDWeb'] ) ;
		
		$texte .= '<p>Le coupon-repas num&eacute;rot&eacute; <strong>'.$_POST['id'].'</strong> est le suivant :</p>' .
				'<blockquote>' .
					'<p><strong>Date :</strong> '.html_date( $coupon['DateUsage'] ).'</p>' .
					'<p><strong>B&eacute;n&eacute;ficiaire :</strong> '.$coupon['Prenom'].' '.vide( $coupon['Nom'] ).'</p>' .
					'<p><strong>Responsable :</strong> ' . $responsable['Prenom'].' '.vide( $responsable['Nom'] ).'</p>' .
				'</blockquote>' ;
	}
	else
	{
		$texte .= '<em>Votre recherche n\'a retourn&eacute; aucune r&eacute;ponse.</em>' ;
	}
}

$texte .= "<h2>Options</h2>" .
			lk( 'Gestion des coupons-repas' , 'gestion_coupons_repas' , FALSE , '' , 'coupons.png' , 'Retour &agrave; l\'&eacute;cran de gestion.' ) .
			lk( 'Retour &agrave; l\'accueil' , 'home' , FALSE , '' , 'home.png' ) ;

?>
