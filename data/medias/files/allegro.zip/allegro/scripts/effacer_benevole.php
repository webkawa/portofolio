<?php

niveau_securite(1) ;

$b_infos = benevole_infos( $_GET['bid'] ) ;

$titre = 'Suppression du b&eacute;n&eacute;vole' ;

if( $_GET['ok'] != 1 )
{
	$texte = "<h2>Avertissement</h2>" .
				"<p>Vous &ecirc;tes sur le point de supprimer la fiche b&eacute;n&eacute;vole de ".lk( $b_infos['Prenom']." ".$b_infos['Nom'] , "profil_benevoles" , FALSE , "uid=".$b_infos['IDBenevole'] ).".</p>" .
				"<p>La suppression d'une fiche b&eacute;n&eacute;vole ne peut se r&eacute;aliser que dans trois situations :</p>" .
				"<blockquote>" .
					"<p><strong>&middot;</strong> Demande de retrait &eacute;manant du b&eacute;n&eacute;vole lui-m&ecirc;me</p>" .
					"<p><strong>&middot;</strong> D&eacute;c&egrave;s, accident grave ou d&eacute;part</p>" .
					"<p><strong>&middot;</strong> Doublon (fiche apparaissant deux fois)</p>" .
				"</blockquote>" .
				"<p>Souhaitez-vous vraiment supprimer ce b&eacute;n&eacute;vole ?</p>" .
				"<blockquote>" .
					lk( 'Supprimer' , 'effacer_benevole' , FALSE , 'bid='.$_GET['bid'].'&ok=1' , 'valider.png' , 'Supprimer d&eacute;finitivement le b&eacute;n&eacute;vole.' ).
					lk( 'Annuler' , 'profil_benevoles' , FALSE , 'bid='.$_GET['bid'] , 'annuler.png' , 'Retour &agrave; la fiche b&eacute;n&eacute;vole.' ) .
				"</blockquote>" ;
}
else
{
	$on[0] = array( "IDBenevole" , 0 , FALSE ) ;
	
	update_sql( "Web" , $on , "IDBenevole = ".$_GET['bid'] ) ;
	delete_sql( "CouponRepas" , "Nom = '".$b_infos['Nom']."' && Prenom = '".$b_infos['Prenom']."'" , 500 ) ;
	delete_sql( "Benevole" , "IDBenevole = ".$_GET['bid'] ) ;
	journal( "Effacement benevole : IDBenevole[".$_GET['bid']."]-Nom[".$b_infos['Nom']."]-Prenom[".$b_infos['Prenom']."]" ) ;
	
	$texte = "<h2>Suppression r&eacute;ussie</h2>" .
				"<p>Le b&eacute;n&eacute;vole a &eacute;t&eacute; correctement effac&eacute;.</p>" .
				lk( "Retour &agrave; l'accueil" , 'home' , FALSE , '' , 'home.png') ;
}

?>
