<?php

niveau_securite(0);

if(isset($_POST["recherche_comite"]))//v�rifie $post existe
	{
	if(empty($_POST["majeur"]))
		{
		$majeur=1;
		}
	else
		{
		$annee=date("Y")-18;
		$mois=date("m");
		$jour=date("j");
		$majeur="B.DateNaissance <'".$annee."-".$mois."-".$jour."'";
		}
	if(empty($_POST["nom"]))//verifie et traite la variable nom
		{
		$like=1;
		}
	else
		{
		$like='B.Nom like "%'.$_POST['nom'].'%"';
		}
	
	if( empty( $_POST["recherche_titre"])  )//verifie et traite la variable sexe
		{
		$sexe=1;
		}
	else	
		{
		if( $_POST["recherche_titre"] == 'femme' ) 				$sexe = "Sexe" ;
		else													$sexe = "!Sexe" ;
		}
		
	if(empty($_POST["recherche_comite"]))//verifie et traite la variable comite
		{
		$comite=1;
		}
	else
		{
		$comite='B.IDComite = "'.$_POST["recherche_comite"].'"';
		}	
	if(empty($_POST["recherche_fonction"]))//verifie et traite la variable fonction
		{
		$fonction=1;
		}
	else
		{
		$fonction='B.Fonction = "'.$_POST["recherche_fonction"].'"';
		}
	if(empty($_POST["recherche_ville"]))//verifie et traite la variable ville
		{
		$ville=1;
		}
	else
		{
		$ville='B.ville = "'.$_POST["recherche_ville"].'"';
		}
	
	$result2=select_sql('Benevole B,Comite C','B.IDComite = C.IDComite && '.$comite.' && '.$like.' && '.$fonction.' && '.$sexe.' && '.$majeur.' && '.$ville , 'B.Nom,B.Prenom,B.Fonction,B.IDComite,C.Code,C.Nom,B.IDBenevole,C.IDComite,B.Sexe,B.ville,B.Adresse,B.DateNaissance,B.IDCouleurAccreditation,B.Province,B.TelephoneFixe,B.TelephoneCellulaire,B.CodePostal,B.Mail','order by B.Nom',TRUE);
	
	// Mise en mémoire pour PDF
	$_SESSION['RequetePDF'] = $result2 ;

	if( $result2['nbr'] == 0 )						e_erreur(7) ;

	$infos['titre'][0]	=	'Nom' ;								$infos['taille'][0]	=	100 ;
	$infos['titre'][1]	=	'Pr&eacute;nom' ;					$infos['taille'][1] =	100 ;
	$infos['titre'][2]	=	'Infos' ;							$infos['taille'][2] =	100 ;
	$infos['titre'][3]	=	'Fonction' ;						$infos['taille'][3]	=	NULL ;
	$infos['titre'][4]	=	'Comit&eacute;' ;					$infos['taille'][4]	=	200 ;
	$infos['titre'][5]	=	lk_pdf("rechercher_benevoles_pdf");	$infos['taille'][5]	=	80 ;
	
	for( $i = 0 ; $i < $result2['nbr'] ; $i++ )
	{
		$tmp = benevole_infos($result2[$i][6]) ;
		
		$contenu[$i][0]	=	$result2[$i][0] ;
		$contenu[$i][1]	=	$result2[$i][1] ;
		$contenu[$i][2] =	$tmp['GInfos'] ;
		$contenu[$i][3]	=	'<font size="-1">'.$result2[$i][2].'</font>' ;
		$contenu[$i][4]	=	'<font size="-1">'.$result2[$i][5].'</font>' ;
		$contenu[$i][5]	=	'<font size="-1">'.lk("Profil","profil_benevoles",FALSE, "uid=".$result2[$i][6] ).'</font>' ;
	}
}

// Gestion du tableau de résultats

if( appel_liste() || isset( $_POST["recherche_comite"] ) )
{
$texte .= "<h2>Liste filtr&eacute;e</h2>" .
		"<p>Votre recherche a retourn&eacute; les r&eacute;sultats suivants.</p>".liste( $contenu , $infos , 6 , 40 , 1 , 20 ) ;
}

$titre	=	'Recherche d\'un b&eacute;n&eacute;vole';
$texte	.= 	"<h2>Recherche</h2>" .
				"<p>Remplissez les champs ci-dessous pour afficher une liste filtr&eacute;e des b&eacute;n&eacute;voles.</p>" ;


//requete comit�
$result=select_sql('Comite','1','*','order by Code');
//requete fonction
$result1=select_sql('Benevole','1','distinct Fonction');
//requete ville
$result4=select_sql('Benevole','1','distinct Ville');

//debut form
$texte.='<blockquote><form method="post" action="?in=rechercher_benevoles"><table cellpading="10" width="100%"><tr>';

//select titre
$texte.='<td><p><strong>Qualit&eacute; :</strong></p><p><select name="recherche_titre">
<option value="">Tous</option>
<option value="homme">Monsieur</option>
<option value="femme">Madame</option>
</select></p></td>';

//champ nom
$texte.='<td><p><strong>Nom :</strong></p><p><input type="text" name=nom></p></td></tr>';

//select comite
$texte.='<tr><td colspan="2"><p><strong>Comit&eacute; :</strong></p><p><select name="recherche_comite">
<option value="">Tous les comit&eacute;s</option>';
for($i=0;$i<$result["nbr"];$i++)
{
$texte.='<option value="'.$result[$i]["IDComite"].'">'.$result[$i]["Code"].'-'.$result[$i]["Nom"].'</option>';
}
$texte.='</select></p></td></tr>';

//select fonction
$texte.='<tr><td colspan="2"><p><strong>Fonction :</strong></p><p><select name="recherche_fonction">
<option value="">Toutes les fonctions</option>';
for($i=0;$i<$result1["nbr"];$i++)
{
$texte.='<option value="'.$result1[$i]["Fonction"].'">'.$result1[$i]["Fonction"].'</option>';
}
$texte.='</select></p></td></tr>';

if( $session_infos["NiveauAutorisation"] > 1 )
{
//select ville
$texte.='<tr><td><p><strong>Ville :</strong></p><p><select name="recherche_ville">
<option value="">Toutes les villes</option>';
for($i=0;$i<$result1["nbr"];$i++)
{
$texte.='<option value="'.$result4[$i]["Ville"].'">'.$result4[$i]["Ville"].'</option>';
}
$texte.='</select></p></td>';

//checkbox majeur
	$texte.='<td><p><input type="checkbox" name="majeur" value="18">Plus de 18 ans uniquement</p></td></tr>';
}

//bouton envoyer
$texte.='<tr><td colspan="2" align="center"><p>' .
			html_button( 'Rechercher' , 'valider.png' , 'Cliquez ici pour lancer la recherche.') .
		'</p></td></tr></table>';
$texte.='</form></blockquote>';
	
?>