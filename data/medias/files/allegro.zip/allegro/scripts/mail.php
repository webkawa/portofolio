<?php

niveau_securite(0) ;

// Formulaire

$titre = 'Mailing' ;
$texte = "<h2>R&eacute;daction du message</h2>" .
			"<p>Le formulaire ci-dessous vous permet d'envoyer un message &agrave; un b&eacute;n&eacute;vole " .
			"ou un membre de l'&eacute;quipe du Mondial.</p>" .
			"<p><strong>Note :</strong> pensez &agrave; bien inscrire votre adresse de messagerie afin de pouvoir obtenir une r&eacute;ponse !</p>" .
			'<blockquote><form method="post" action="?in=mail&ok=1"><table cellspacing="10">' .
				'<tr>' .
					'<td>' .
						'<p><strong>Destinataire :</strong></p>' .
						'<p><select name="destinataire" size="8">' .
							'<option value="v_mondial">[G&eacute;n&eacute;ral]Equipe du Mondial</option>' ;
							
$tmp = select_sql( "Web" , "NiveauAutorisation > 1" ) ;

for( $i = 0 ; $i < $tmp['nbr'] ; $i++ )
{
	$texte .=				'<option value="u_'.$tmp[$i]['IDWeb'].'">[Staff]'.strtoupper( $tmp[$i]['Nom'] ).' '.$tmp[$i]['Prenom'].'</option>' ;
}

$tmp = select_sql( "Benevole" , "Mail != ''" ) ;

for( $i = 0 ; $i < $tmp['nbr'] ; $i++ )
{
														$check = '' ;
	if( $tmp[$i]['IDBenevole'] == $_GET['uid'] )		$check = 'selected' ;
	
	$texte .=				'<option '.$check.' value="b_'.$tmp[$i]['IDBenevole'].'">[B&eacute;n&eacute;vole]'.strtoupper( $tmp[$i]['Nom'] ).' '.$tmp[$i]['Prenom'].'</option>' ;
}

$texte .=				'</select></p>' .
					'</td>' .
				'</tr>' .
				'<tr>' .
					'<td>' .
						'<p><strong>Sujet :</strong></p>' .
						'<p><input size="30" type="text" name="sujet"></p>' .
					'</td>' .
				'</tr>' .
				'<tr>' .
					'<td>' .
						'<p><strong>Votre adresse mail :</strong></p>' .
						'<p><input size="30" type="text" name="mail"></p>' .
					'</td>' .
				'</tr>' .
				'<tr>' .
					'<td>' .
						'<p><strong>Message :</strong></p>' .
						'<p><textarea cols="60" rows="8" name="message" ></textarea></p>' .
					'</td>' .
				'</tr>' .
				'<tr>' .
					'<td align="center">' .
						html_button( 'Envoyer' , 'mail_send.png' , 'Cliquez ici pour envoyer votre message.' ) .
					'</td>' .
				'</tr>' .
			'</table></form></blockquote>' ;
			
if( $_GET['ok'] == 1 )
{
	if( $_POST['destinataire'] == 'v_mondial' )					$send2 = $global['mail'] ;
	if( substr( $_POST['destinataire'] , 0 , 2 ) == 'u_' )
	{
		$tmp 	= select_sql( "Web" , "IDWeb = ".substr( $_POST['destinataire'] , 2 , 8 ) ) ;
		$send2	= $tmp['Mail'] ;
	}
	if( substr( $_POST['destinataire'] , 0 , 2 ) == 'b_' )
	{
		$tmp	= select_sql( "Benevole" , "IDBenevole = ".substr( $_POST['destinataire'] , 2 , 8 ) ) ;
		$send2	= $tmp['Mail'] ;
	}

	if( empty( $_POST['sujet'] ) || empty( $_POST['message'] ) )					e_erreur(42) ;
	if( !valider_mail( $_POST['mail'] ) )											e_erreur(16) ;
	
	if( !$contenu['erreur'] )
	{
		// Définition du message
		
		$message2send = "Bonjour\n\n" ;
		
		if( $session_infos['NiveauAutorisation'] > 0 )
		{
			$message2send .= "Vous avez reçu un message de ".$session_infos['Prenom']." ".strtoupper( $session_infos['Nom'] )." envoyé " .
							 "par l'intermédiaire d'Allegro, le site de gestion du Mondial des Cultures de Drummondville.\n\n" ;
		}
		else
		{
			$message2send .= "Un visiteur non-identifié vous a envoyé un message par l'intermédiaire d'Allegro, " .
							 "le site de gestion du Mondial des Cultures de Drummondville.\n\n" ;
		}
		
		$message2send .= "Le contenu du message est le suivant :\n\n" .
							"Sujet : ".$_POST['sujet']."\n" .
							"Adresse de retour : ".$_POST['mail']."\n\n" .
							"Message :\n\n".$_POST['message']."\n\n" .
						 "En cas de message déplacé ou injurieux, merci de prévenir les responsables du site :\n" .
						 $global['url'] ;
			
		// Envoi
						 
		envoi_mail( $send2 , 'Vous avez reçu un mail' , $message2send , TRUE ) ;
		journal( "Envoi d'un mail : Adresse[".$send2."]" ) ;
		
		// Retour
		
		$texte = "<h2>Message envoy&eacute;</h2>" .
					"<p>Votre message a &eacute;t&eacute; correctement envoy&eacute;.</p>" .
					"<p>Merci de votre participation !</p>".
					lk('Autre message','mail',FALSE,'','mail.png','Cliquez ici pour exp&eacute;dier un autre message.') .
					lk('Retour &agrave; l\'accueil','home',FALSE,'','home.png') ;
	}
}

?>
