<?php

niveau_securite( 1 , STRICT ) ;

// Exclusion

if( isset( $_GET['xid'] ) )
{
	$bdp = '<a name="CC"></a>' ;
	
	$infos_xb = benevole_infos( $_GET['xid'] ) ;
	
	if( $_GET['ok'] != 1 )
	{
		$bdp .= "<h2>Exclusion du b&eacute;n&eacute;vole</h2>" .
					"<p>Confirmer l'exclusion de ".$infos_xb['Prenom']." ".$infos_xb['Nom']." hors du comit&eacute; ?</p>" .
					"<blockquote>" .
						"<p>".lk("Valider","mon_comite",FALSE,"xid=".$_GET['xid']."&ok=1#CC",'valider.png',"Cliquez ici pour confirmer l'exclusion.")."</p>" .
						"<p>".lk("Profil","profil_benevoles",TRUE,"uid=".$_GET['xid'],'profil.png','Cliquez ici pour visualiser le profil du b&eacute;n&eacute;vole.') ."</p>" .
						"<p>".lk("Annuler","mon_comite",FALSE,'','annuler.png',"Retour &agrave; l'&eacute;cran de gestion de votre comit&eacute;.")."</p>" .
					"</blockquote>" ;
	}
	else
	{
		$mode = FALSE ;
		
		if( $infos_xb['IDComite'] == $session_infos['IDComite'] )			$mode = PRINCIPAL ;
		if( $infos_xb['IDComiteSecondaire'] == $session_infos['IDComite'] )	$mode = SECONDAIRE ;
		
		if( !$mode )			f_erreur( 29 , 'mon_comite.php' , 4 , "Erreur pour benevole ID[".$_GET['xid']."]" );
		
		if( $_GET['xid'] == $session_infos['IDBenevole'] && $session_infos['NiveauAutorisation'] == 1 )
		{
			e_erreur(29) ;
		}
		
		if( !$contenu['erreur'] )
		{
			journal( "Exclusion du benevole : IDBenevole[".$_GET['xid']."]-IDComite[".$session_infos['IDComite']."]") ;
			
			exclure_benevole( $_GET['xid'] , $mode ) ;
			
			$bdp .= "<h2>Exclusion r&eacute;ussie</h2>" .
						"<p>Le b&eacute;n&eacute;vole a correctement &eacute;t&eacute; exclu de votre comit&eacute;.</p>" ;
		}
	}
}

// Recherche

$liste=select_sql('Benevole B,Comite C','B.IDComite = C.IDComite && ( B.IDComite = '.$session_infos['IDComite'].' || B.IDComiteSecondaire = '.$session_infos['IDComite'].')' , 'B.Nom , B.Prenom , B.Fonction , B.IDComite , C.Code , C.Nom , B.IDBenevole , C.IDComite , B.Sexe , B.ville , B.Adresse , B.DateNaissance , B.IDCouleurAccreditation , B.Province , B.TelephoneFixe , B.TelephoneCellulaire , B.CodePostal , B.Mail , B.IDComiteSecondaire','ORDER BY B.Nom',TRUE);

// Définition du tableau

$infos['titre'][0]	=	'Nom' ;								$infos['taille'][0]	=	100 ;
$infos['titre'][1]	=	'Pr&eacute;nom' ;					$infos['taille'][1] =	100 ;
$infos['titre'][2]	=	'Fonction' ;						$infos['taille'][2]	=	NULL ;
$infos['titre'][3]	=	'Liste' ;							$infos['taille'][3]	=	200 ;
$infos['titre'][4]	=	lk_pdf("mon_comite_pdf") ;			$infos['taille'][4]	=	80 ;

for( $i = 0 ; $i<$liste['nbr'] ; $i++ )
{
	$tmp = NULL ;
	
	if( $liste[$i][3]  == $session_infos['IDComite'] )				$tmp = "Principale" ;
	if( $liste[$i][18] == $session_infos['IDComite'] )				$tmp = "Secondaire" ;
	
	$contenu[$i][0]	=	$liste[$i][0] ;
	$contenu[$i][1]	=	$liste[$i][1] ;
	$contenu[$i][2]	=	$liste[$i][2] ;
	$contenu[$i][3]	=	$tmp ;
	$contenu[$i][4]	=	'<font size="-1">'.lk("Options","mon_comite",FALSE,"select_c=".$i."#MP" ).'</font>' ;
	
	$contenu[$i]['Code'] = $liste[$i][4] ;
}

// Retour HTML

$tmp = benevole_infos( $session_infos['IDBenevole'] ) ;

$titre	=	"Mon comit&eacute;" ;
$texte	=	"<h2>Liste brute</h2>" .
			"<p>Cette page vous permet de consulter la liste compl&egrave;te des b&eacute;n&eacute;voles inscrits dans votre comit&eacute; " .
			"(".$tmp['Comite']['Nom'].")" .
				" pour l'ann&eacute;e ".$global['annee'].".</p>" ;		
$texte .= 	liste( $contenu , $infos , 5 , 25 , 1 , 20 ) ;
$texte .=	$bdp ;

// Renvoi des options

if( isset( $_GET['select_c'] ) && !isset( $_GET['xid'] ) )
{				
	$infos_mp = benevole_infos( $liste[$_GET['select_c']][6] ) ;
	
	$texte.= '<a name="MP"></a>' .
				"<h2>Options</h2>" .
				"<p>Les options suivantes s'appliquent au b&eacute;n&eacute;vole actuellement " .
				"s&eacute;lectionn&eacute; (".$liste[$_GET['select_c']][1].' '.$liste[$_GET['select_c']][0].") :</p>" .
				"<blockquote>" .
					"<p>".lk("Profil","profil_benevoles",TRUE,"uid=".$liste[$_GET['select_c']][6],'profil.png',"Cliquez ici pour afficher le profil complet de ce b&eacute;n&eacute;vole." )."</p>" .
					"<p>".lk("Exclure","mon_comite",FALSE,"xid=".$liste[$_GET['select_c']][6]."&select_c=".$_GET['select_c']."&ok=0#CC",'retrait.png',"Cliquez ici pour retirer ce b&eacute;n&eacute;vole de votre comit&eacute;." )."</p>" .
					"<p>".lk("Modifier","modifier_benevole",FALSE,"bid=".$liste[$_GET['select_c']][6],'editer.png',"Cliquez ici pour modifier les informations li&eacute;es &agrave; cette fiche b&eacute;n&eacute;vole." )."</p>" .
				"</blockquote>" ;
	
	$texte	.=	"<h2>Aper&ccedil;u du profil</h2>" .
				'<blockquote><table border="0" cellpading="5" cellspacing="5"><tr>' .
					'<td valign="top">'.html_photo($infos_mp['IDBenevole']).'</td>' .
					'<td valign="top">' .
						'<p>' . $infos_mp['GInfos'] .'</p>' .
						"<p><strong>Nom :</strong> ".$infos_mp['Nom']."</p>" .
						"<p><strong>Pr&eacute;nom :</strong> ".$infos_mp['Prenom']."</p>" .
						"<p><strong>Fonction :</strong> ".$infos_mp['Fonction']."</p>" ;
					
					if( $infos_mp['Comite']['IDComite'] == $session_infos['IDComite'] )
					{
						$texte .= "<p><strong>Comit&eacute secondaire :</strong> ".$infos_mp['ComiteS']['Nom']."</p>" ;
					}
					else
					{
						$texte .= "<p><strong>Comit&eacute principal :</strong> ".$infos_mp['Comite']['Nom']."</p>" ;
					}

	$texte	.=		"<br><strong>Informations confidentielles</strong>" .
						"<p><strong>T&eacute;l&eacute;phone fixe :</strong> ".$infos_mp['TelephoneFixe']."</p>" .
						"<p><strong>T&eacute;l&eacute;phone cellulaire :</strong> ".$infos_mp['TelephoneCellulaire']."</p>" .
						"<p><strong>Date de naissance :</strong> ".html_date($infos_mp['DateNaissance'])."</p>" ;
				
	$texte	.=	'</td>' .
				'</tr></table></blockquote>' ; 
}

?>