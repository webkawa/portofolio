<?php

$texte = '<p>Tu crains, Marilyn !!!!!</p>'

?>
