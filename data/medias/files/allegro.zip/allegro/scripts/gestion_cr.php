<?php

niveau_securite( 1 , STRICT ) ;

// Traitement

if( isset( $_GET['nom'] ) && isset( $_GET['prenom'] ) && isset( $_GET['date']) )
{	
	// Traitement brut
	if( isset( $_POST['att_nbr_date'] ) )
	{
		$preselection = select_sql( "CouponRepas" , "IDWeb = ".$session_infos['IDWeb']." && Nom = '".$_GET['nom']."' && Prenom = '".$_GET['prenom']."' && DateUsage = '".$_GET['date']."'" ) ;
		
		if( !checkdate( $_POST['att_mm'] , $_POST['att_jj'] , $_POST['att_aaaa'] ) )	e_erreur(25) ;
		if( depassee( $_POST['att_jj'] , $_POST['att_mm'] , $_POST['att_aaaa'] ) )		e_erreur(26) ;
		if( $preselection['nbr'] < $_POST['att_nbr_date'] )								e_erreur(27) ;
		if( $_POST['att_nbr_date'] < 1 )												e_erreur(27) ;
		
		if( !$contenu['erreur'] )
		{
			$on[0] = array( "DateUsage" , $_POST['att_aaaa']."-".$_POST['att_mm']."-".$_POST['att_jj'] , TRUE ) ;		
			journal( "Datation coupons-repas : Nombre[".$_POST['att_nbr_date']."]-Date[".$_POST['att_aaaa']."-".$_POST['att_mm']."-".$_POST['att_jj']."]" );
			update_sql( "CouponRepas" , $on , "IDWeb = ".$session_infos['IDWeb']." && Nom = '".$_GET['nom']."' && Prenom = '".$_GET['prenom']."' && DateUsage = '".$_GET['date']."'" , "LIMIT ".$_POST['att_nbr_date'] );
			$_GET['date'] = $_POST['att_aaaa']."-".$_POST['att_mm']."-".$_POST['att_jj'] ;
		}
	}
	if( isset( $_POST['att_nbr_nom'] ) )
	{
		$preselection = select_sql( "CouponRepas" , "IDWeb = ".$session_infos['IDWeb']." && Nom = '".$_GET['nom']."' && Prenom = '".$_GET['prenom']."' && DateUsage = '".$_GET['date']."'" ) ;
		$postulant = select_sql( "Benevole" , "IDBenevole = ".$_POST['att_id'] ) ;
		
		if( $preselection['nbr'] < $_POST['att_nbr_nom'] )								e_erreur(27) ;
		if( $_POST['att_nbr_nom'] < 1 )													e_erreur(27) ;
		
		if( !$contenu['erreur'] )
		{
			$on[0] = array( "Nom" , $postulant['Nom'] , TRUE ) ;
			$on[1] = array( "Prenom" , $postulant['Prenom'] , TRUE ) ;
			journal( "Nomination coupons-repas : Nombre[".$_POST['att_nbr_nom']."]-Nom[".$postulant['Nom']."]-Prenom[".$postulant['Prenom']."]" );
			update_sql( "CouponRepas" , $on , "IDWeb = ".$session_infos['IDWeb']." && Nom = '".$_GET['nom']."' && Prenom = '".$_GET['prenom']."' && DateUsage = '".$_GET['date']."'" , "LIMIT ".$_POST['att_nbr_nom'] );
			$_GET['nom'] 	= $postulant['Nom'] ;
			$_GET['prenom'] = $postulant['Prenom'] ;
		}
	}
	
	// Sélection des infos sur le lot
	$lot = select_sql( "CouponRepas" , "IDWeb = ".$session_infos['IDWeb']." && Nom = '".$_GET['nom']."' && Prenom = '".$_GET['prenom']."' && DateUsage = '".$_GET['date']."'" ) ;
	
	if( !$lot['nbr'] )
	{
		f_erreur( 31 , 'gestion_cr.php' , 4 , "Lot invalide pour [".$lot['requete']."]" ) ;
	}
	
	// Renvoi à l'écran	
	$bdp = '<a name="CC"></a>' .
			"<h2>Pr&eacute;paration des coupons-repas</h2>" .
			"<p>Vous travaillez actuellement sur un lot de ".$lot['nbr']." coupons-repas.</p>" ;
			
	$bdp .= "<h3>Date d'usage</h3>" ;
	if( $lot[0]['DateUsage'] == '0000-00-00' )
	{
		$bdp .= "<p>Ce lot n'est pas dat&eacute;. Pour lui attribuer une date, faites usage du formulaire ci-dessous." .
				"Attention : ce choix est d&eacute;finitif.</p>" ;
		$bdp .= '<blockquote><form method="post" action="?in='.$_GET['in'].'&date='.$_GET['date'].'&nom='.$_GET['nom'].'&prenom='.$_GET['prenom'].'#CC"><table cellspacing="5">' .
						"<tr>" .
							'<td width="150"><p><strong>Nombre </strong>('.$lot['nbr'].' max.) <strong>:</strong></p>' .
							'<p><input type="text" name="att_nbr_date" maxlength="3" size="5" value="'.$lot['nbr'].'"></p></td>' .
							'<td><p><strong>Date au format JJ-MM-AAAA :</strong>' .
							'<p><input type="text" name="att_jj" maxlength="2" size="5">' .
							'<input type="text" name="att_mm" maxlength="2" size="5">' .
							'<input type="text" name="att_aaaa" maxlength="4" size="10" value="'.$global['annee'].'"></p></td>' .
							'<td valign="center">' .
							html_button( 'Dater' , 'activite.png' , 'Cliquez ici pour dater tout ou partie du lot s&eacute;lectionn&eacute;.' ) .
							'</td>' .
						"</tr>" .
					"</table></form></blockquote>" ;
	}
	else
	{
		$bdp .= "<p>Ce lot est dat&eacute; pour le <strong>".html_date( $lot[0]['DateUsage'] )."</strong>.</p>" ;
		
		$bdp .= "<h3>B&eacute;n&eacute;ficiaire</h3>" ;
		if( empty( $lot[0]['Nom'] ) )
		{
			$beneficiaires = select_sql( "Benevole" , "IDComite = ".$session_infos['IDComite']." || IDComiteSecondaire = ".$session_infos['IDComite'] , "*" , "ORDER BY Nom") ;
			
			$bdp .= "<p>Ce lot n'est pas attribu&eacute; &agrave; aucun membre de votre comit&eacute;. " .
					"Pour ce faire, faites usage du formulaire ci-dessous. Attention : ce choix est d&eacute;finitif.</p>" ;
					
			$bdp .= '<blockquote><form method="post" action="?in='.$_GET['in'].'&date='.$_GET['date'].'&nom='.$_GET['nom'].'&prenom='.$_GET['prenom'].'#CC"><table cellspacing="5">' .
						"<tr>" .
							'<td width="150"><p><strong>Nombre </strong>('.$lot['nbr'].' max.) <strong>:</strong></p>' .
							'<p><input type="text" name="att_nbr_nom" maxlength="3" size="5" value="1"></p></td>' .
							'<td><p><strong>Nom du b&eacute;n&eacute;ficiaire :</strong>' .
							'<p><select name="att_id">' ;
							
							for( $i = 0 ; $i < $beneficiaires['nbr'] ; $i++ )
							{
								$bdp .= '<option value="'.$beneficiaires[$i]['IDBenevole'].'">'.$beneficiaires[$i]['Prenom']." ".$beneficiaires[$i]['Nom']."</option>" ;
							}
							
							$bdp .= '</select></p></td>' .
							'<td valign="center">' .
							html_button( 'Attribuer' , 'benevole.png' , 'Cliquez ici pour attribuer tout ou partie du lot s&eacute;lectionn&eacute;.') .
							'</td>' .
						"</tr>" .
					"</table></form></blockquote>" ;
		}
		else
		{
			$bdp .= "<p>Ce lot est attribu&eacute; &agrave; <strong>".$lot[0]['Prenom']." ".$lot[0]['Nom']."</strong>.</p>" ;
			
			$bdp .= "<h3>Impression</h3>" .
						"<p>Ce lot de coupons-repas est pr&ecirc;t &agrave; &ecirc;tre imprim&eacute;. Cliquez sur l'icone ci-dessous pour lancer le PDF d'impression.</p>" .
						lk_pdf("coupons_repas",TRUE) .
						"<h3>Avertissement</h3>" .
						"<p>Vous avez le droit d'imprimer un et un seul exemplaire de chaque coupon vous ayant &eacute;t&eacute; remis par le Mondial. " .
						"Ces derniers sont num&eacute;rot&eacute;s individuellement et leur impression control&eacute;e. " .
						"Assurez-vous de ne pas remettre plus de coupons que vous n'en avez &agrave; disposition ; " .
						"tout abus sera r&eacute;primand&eacute;. </p><p>En cas de doute quand au fonctionnement des impressions, r&eacute;f&eacute;rez-vous " .
						"&agrave; la documentation du syst&egrave;me.</p>" .
						"<p>Merci de votre compr&eacute;hension.</p>" ;
		}
	}
}

// Remplissage du tableau

$titre = "Distribution des coupons-repas" ;

$coupons_dispos = select_sql( "CouponRepas" , "IDWeb = ".$session_infos['IDWeb'] , "DISTINCT DateUsage,Nom,Prenom" , "ORDER BY Nom,DateUsage") ;

$infos['titre'][0]	=	"Nombre" ;							$infos['taille'][0]	=	50 ;
$infos['titre'][1]	=	"Date" ;							$infos['taille'][1]	=	200 ;
$infos['titre'][2]	=	"B&eacute;n&eacute;ficiaire" ;		$infos['taille'][2]	=	NULL ;
$infos['titre'][3]	=	NULL ;								$infos['taille'][3]	=	150 ;

for( $i = 0 ; $i < $coupons_dispos['nbr'] ; $i++ )
{
	if( $coupons_dispos[$i]['Prenom'] == $_GET['prenom'] && $coupons_dispos[$i]['Nom'] == $_GET['nom'] && $coupons_dispos[$i]['DateUsage'] == $_GET['date'] )
	{
		$_GET['select_c'] = $i ;
	}
	
	if( empty($coupons_dispos[$i]['Prenom']) && empty($coupons_dispos[$i]['Nom']) )
	{
		$tmp_prenom = "''" ;
		$tmp_nom = "''" ;
		$tmp_full = "Non-attribu&eacute;(s)" ;
	}
	else
	{
		$tmp_prenom = "'".$coupons_dispos[$i]['Prenom']."'" ;
		$tmp_nom = "'".$coupons_dispos[$i]['Nom']."'" ;
		$tmp_full = $coupons_dispos[$i]['Prenom']." ".$coupons_dispos[$i]['Nom'] ;
	}
	
	$tmp_count = denombrer_sql( "CouponRepas" , "IDWeb = ".$session_infos['IDWeb']." && DateUsage = '".$coupons_dispos[$i]['DateUsage']."' && Nom = ".$tmp_nom." && Prenom = ".$tmp_prenom ) ;
	
	if( $coupons_dispos[$i]['DateUsage'] == '0000-00-00' )
	{
		$tmp_date = "Ind&eacute;fini(s)" ;
	}
	else
	{
		$tmp_date = html_date($coupons_dispos[$i]['DateUsage']) ;
	}
		
	$contenu[$i][0]	=	$tmp_count ;
	$contenu[$i][1] =	$tmp_date ;
	$contenu[$i][2]	=	$tmp_full ;
	$contenu[$i][3] =	'<font size="-1">'.lk("Options","gestion_cr",FALSE,"nom=".$coupons_dispos[$i]['Nom']."&prenom=".$coupons_dispos[$i]['Prenom']."&date=".$coupons_dispos[$i]['DateUsage']."&select_c=".$i."#CC").'</font>' ;
}

$texte .= "<h2>Liste brute</h2>" .
			"<p>La liste ci-dessous r&eacute;sume l'ensemble des coupons-repas actuellement attribu&eacute;s " .
			"&agrave; votre comit&eacute;.</p>" .
			"<p>Leur attribution aux diff&eacute;rents membres de votre &eacute;quipe est libre mais d&eacute;finitive : " .
			"aucun retour n'est possible une fois date et nom attribu&eacute;s aux coupons.</p>" ;
$texte .= liste( $contenu , $infos , 4 , 25 ) ;
$texte .= $bdp ;


?>
