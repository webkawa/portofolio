<?php

niveau_securite(0);

// Définition de l'ID à rechercher

if( isset( $_GET['bid'] ) )						$id = $_GET['bid'] ;
if( isset( $_GET['uid'] ) )						$id = $_GET['uid'] ;
if( isset( $_GET['wid'] ) )						$id = web2benevole( $_GET['wid'] ) ;

// Stockage des informations utilisateur

if( !$b_infos = benevole_infos( $id ) )							e_erreur(9) ;

// Gestion du titre

$titre		=	"Profil b&eacute;n&eacute;vole" ;

// Information primaires

$texte		.=	"<h2>Lien</h2>" .
				lk('Acc&egrave;s direct aux options','profil_benevoles',FALSE,'uid='.$id.'#OPT','options.png',"Cliquez ici pour acc&eacute;der aux options de la fiche b&eacute;n&eacute;vole.") .
				"<h2>Identit&eacute;</h2>" .
				'<p><font size="-1">Les information d&eacute;livr&eacute;es dans ce paragraphe sont publiques.' ;
				
				if( $session_infos['NiveauAutorisation'] > 0 )
				{
					$texte .= lk( " Modifier ces informations ..." , "modifier_benevole" , FALSE , "bid=".$id."&action=primaires&ok=0#CC" ) ;
				}
				
$texte		.=	'</font></p>' .
				'<p><table align="center" cellpadding="2">' .
					'<tr>' .
						'<td colspan="2" align="center"><p>' . html_photo( $id ) .'</p>' ;
				
				if( $session_infos['NiveauAutorisation'] > 0 )
				{
					$texte .= '<p>' . lk( '<font size="-1">Modifier la photographie</font>' , "modifier_benevole" , FALSE , "bid=".$id."&action=photo&ok=0" ) . '</p>' ;
				}
				
$texte		.=	'</td>' .
					'</tr>' .
					'<tr>' .
						'<td height="30" colspan="2" align="center"><p>' . $b_infos['GInfos'] . '</p></td>' .
					'</tr>' .
					'<tr>' .
						'<td width="400" align="right"><strong>Nom :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['Nom'] . '</td>' .
					'</tr>' .
					'<tr>' .
						'<td width="400" align="right"><strong>Pr&eacute;nom :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['Prenom'] . '</td>' .
					'</tr>' .
					'<tr>' .
						'<td width="400" align="right"><strong>Fonction :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['Fonction'] . '</td>' .
					'</tr>' .
					'<tr>' .
						'<td width="400" align="right"><strong>Compte :</strong></td>' .
						'<td width="400" align="left">' . type_compte( $b_infos['Web']['NiveauAutorisation'] ) . '</td>' .
					'</tr>' .
					'<tr>' .
						'<td width="400" align="right"><strong>Majeur(e) :</strong></td>' .
						'<td width="400" align="left">' ;
						
	if( substr( $b_infos['DateNaissance'] , 0 , 4 ) > (date("Y")-18) )		$texte .= "non" ;
	else																	$texte .= "oui" ;
	
	if( voir_confidentiel( $id ) )											$texte .= " (n&eacute; le ".html_date( $b_infos['DateNaissance'] ).")" ;			
						
$texte .=				'</td>' .
					'</tr>' .
				'</table></p>' ;

// Informations de comité

$texte		.=	"<h2>Activit&eacute;</h2>" .
				'<p><font size="-1">Les informations suivantes sont publiques mais essentiellement adress&eacute;es aux responsables de comit&eacute;.' ;
				
				if( $session_infos['NiveauAutorisation'] > 1 )
				{
					$texte .= lk( " Modifier ces informations ..." , "modifier_benevole" , FALSE , "bid=".$id."&action=activite&ok=0#CC" ) ;
				}
				
$texte		.=	'</font></p>' .
				'<p><table align="center" cellpadding="2">' .
					'<tr height="50" valign="bottom">' .
						'<td align="center" colspan="2"><font size="+1"><strong>Informations</strong></font></td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Volume horaire :</strong></td>' .
						'<td width="400" align="left">' . vide( $b_infos['Heures'] ). '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Zone :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['ZoneL']. '</td>' .
					'</tr>' .
					'<tr height="50" valign="bottom">' .
						'<td align="center" colspan="2"><font size="+1"><strong>Comit&eacute; principal</strong></font></td>' .
					'</tr>' ;
					
if( $b_infos['Comite'][0] == 0 )
{
	$texte	.=		'<tr>' .
						'<td align="center" colspan="2"><em>Disponible</em></td>' .
					'</tr>' ;
}
else
{
	$texte	.=		'<tr valign="top">' .
						'<td width="400" align="right"><strong>Nom :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['Comite']['Nom']. ' ('.$b_infos['Comite']['Code'].')' . '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Description :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['Comite']['Description']. '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Responsable :</strong></td>' .
						'<td width="400" align="left">' . lk( $b_infos['RComite']['Nom'].' '.$b_infos['RComite']['Prenom'] , 'profil_benevoles' , FALSE , 'uid='.$b_infos['RComite']['IDBenevole'] ) . '</td>' .
					'</tr>' .
					'<tr height="50" valign="bottom">' .
						'<td align="center" colspan="2"><font size="+1"><strong>Comit&eacute; secondaire</strong></font></td>' .
					'</tr>' ;
	
	if( $b_infos['ComiteS'][0] == 0 )
	{
		$texte .=	'<tr>' .
						'<td align="center" colspan="2"><em>Disponible</em></td>' .
					'</tr>' ;
	}
	else
	{
		$texte	.=	'<tr valign="top">' .
						'<td width="400" align="right"><strong>Nom :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['ComiteS']['Nom']. ' ('.$b_infos['ComiteS']['Code'].')' . '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Description :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['ComiteS']['Description']. '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Responsable :</strong></td>' .
						'<td width="400" align="left">' . lk( $b_infos['RComiteS']['Nom'].' '.$b_infos['RComiteS']['Prenom'] , 'profil_benevoles' , FALSE , 'uid='.$b_infos['RComiteS']['IDBenevole'] ) . '</td>' .
					'</tr>' ;
	}
}

$texte		.=	'</table></p>' ;

// Informations personnelles

if( voir_confidentiel( $id ) )
{
	$texte	.=	"<h2>Personnel</h2>" .
				'<p><font size="-1">Les informations suivantes sont confidentielles et ne doivent pas &ecirc;tre divulgu&eacute;es.' ;
				
				if( voir_confidentiel( $id ) )
				{
					$texte .= lk( " Modifier ces informations ..." , "modifier_benevole" , FALSE , "bid=".$id."&action=perso&ok=0#CC" ) ;
				}
				
$texte		.=	'</font></p>' .
				'<p><table align="center" cellpadding="2">' .
					'<tr height="50" valign="bottom">' .
						'<td align="center" colspan="2"><font size="+1"><strong>Coordonn&eacute;es</strong></font></td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Adresse :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['Adresse']. '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Ville :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['Ville'] . '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Code postal :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['CodePostal'] . '</td>' .
					'</tr>' .
					'<tr height="50" valign="bottom">' .
						'<td align="center" colspan="2"><font size="+1"><strong>Contacts</strong></font></td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>T&eacute;l&eacute;phone principal :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['TelephoneFixe']. '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>T&eacute;l&eacute;phone cellulaire :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['TelephoneCellulaire'] . '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Adresse de messagerie :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['Mail'] . '</td>' .
					'</tr>' ;
$texte		.=	'</table></p>' ;
}

// Gestion des coupons-repas

$cr = select_sql( "CouponRepas" , "Nom='".$b_infos['Nom']."' && Prenom='".$b_infos['Prenom']."'" );

if( voir_confidentiel( $id ) && $cr['nbr'] != 0 )
{	
	$texte	.=	"<h2>Coupons-repas</h2>" .
				'<p><font size="-1">La liste suivante r&eacute;sume l\'ensemble des coupons-repas remis &agrave; ce b&eacute;n&eacute;vole.</font></p>' .
				'<p><table align="center" cellpadding="2">' ;

		for( $i = 0 ; $i < $cr['nbr'] ; $i++ )
		{
			$texte .= '<tr valign="top">' .
							'<td width="400" align="right"><strong>ID['.$cr[$i][0].'] :</strong></td>' .
							'<td width="400" align="left">' . html_date( $cr[$i]['DateUsage'] ) . '</td>' .
						'</tr>' ;
		}
					
	$texte		.=	'</table></p>' ;
}

// Informations administratives

if( $session_infos['NiveauAutorisation'] > 1 )
{
		$texte	.=	"<h2>Administration</h2>" .
				'<p><font size="-1">Les informations suivantes sont r&eacute;serv&eacute;es &agrave; l\'&eacute;quipe du Mondial.' ;
				
				if( $session_infos['NiveauAutorisation'] > 1 )
				{
					$texte .= lk( " Modifier ces informations ..." , "modifier_benevole" , FALSE , "bid=".$id."&action=admin&ok=0#CC" ) ;
				}
				
$texte		.=	'</font></p>' .
				'<p><table align="center" cellpadding="2">' .
					'<tr height="50" valign="bottom">' .
						'<td align="center" colspan="2"><font size="+1"><strong>Statut</strong></font></td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Liste noire :</strong></td>' .
						'<td width="400" align="left">' . html_yesno( naeloob( $b_infos['Recommandable'] ) ) . '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Privil&egrave;ges :</strong></td>' .
						'<td width="400" align="left">' . html_yesno( $b_infos['Privileges'] ) . '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Statut :</strong></td>' .
						'<td width="400" align="left">' . $b_infos['StatutL'] . '</td>' .
					'</tr>' .
					'<tr valign="top">' .
						'<td width="400" align="right"><strong>Carte imprim&eacute;e :</strong></td>' .
						'<td width="400" align="left">' . html_yesno( $b_infos['Imprime'] ) . '</td>' .
					'</tr>' .
					'<tr height="50" valign="bottom">' .
						'<td align="center" colspan="2"><font size="+1"><strong>Niveau d\'accr&eacute;ditation</strong></font></td>' .
					'</tr>' ;
			
		if( !$b_infos['CA'] )
		{
			$texte .=	'<tr>' .
							'<td align="center" colspan="2"><em>Aucun</em></td>' .
						'</tr>' ;
		}
		else
		{
			$texte .=	'<tr valign="top">' .
							'<td width="400" align="right" valign="middle"><strong>Visuel :</strong></td>' .
							'<td width="400" align="left" valign="middle"><table width="15" height="15" border="1" bgcolor="#'.$b_infos['CA']['CodeCouleur'].'"></table></td>' .
						'</tr>' .
						'<tr valign="top">' .
							'<td width="400" align="right"><strong>Type :</strong></td>' .
							'<td width="400" align="left">' . vide( $b_infos['CA']['Nom'] ) . '</td>' .
						'</tr>' .
						'<tr valign="top">' .
							'<td width="400" align="right"><strong>Description :</strong></td>' .
							'<td width="400" align="left">' . vide( $b_infos['CA']['Description'] ) . '</td>' .
						'</tr>' ;
		}
								
	$texte		.=	'</table></p>' ;
}

// Options

$texte 		.=	"<h2>Options</h2>" .
				'<a name="OPT">' ;
				
if( $b_infos['Mail'] != '' )
{
	$texte	.=	lk( 'Envoyer un message' , 'mail' , FALSE , 'uid='.$id , 'mail.png' , 'Cliquez ici pour envoyer un courriel &agrave; ce b&eacute;n&eacute;vole.' ) ;	
}
if( $session_infos['NiveauAutorisation'] == 1 && $b_infos['Comite']['IDComite'] != $session_infos['IDComite'] && $b_infos['ComiteS']['IDComite'] != $session_infos['IDComite'] && $b_infos['Web']['NiveauAutorisation'] != 1 )
{
	$texte	.=	lk( 'Joindre ce b&eacute;n&eacute;vole &agrave; mon comit&eacute;' , 'joindre_benevole' , FALSE , 'bid='.$id , 'in.png' ) ;
}
if( voir_confidentiel( $id ) )
{
	$texte	.=	lk( 'Modifier' , 'modifier_benevole' , FALSE , 'bid='.$id , 'editer.png' , 'Cliquez ici pour modifier les informations de la fiche b&eacute;n&eacute;vole.' ) ;
	$texte	.=	lk( 'Effacer' , 'effacer_benevole' , FALSE , 'bid='.$id , 'corbeille.png' , 'Cliquez ici pour supprimer la fiche b&eacute;n&eacute;vole.' ) ;
}
if( $session_infos['NiveauAutorisation'] > 1 && $b_infos['Recommandable'] )
{
	$texte	.=	lk( 'Placer sur liste noire' , 'blacklist' , FALSE , 'uid='.$id.'&mode=on' , 'on_bl.png' , 'Cliquez ici pour ajouter ce b&eacute;n&eacute;vole &agrave; la liste noire.' ) ;
}
if( $session_infos['NiveauAutorisation'] > 1 && !$b_infos['Recommandable'] )
{
	$texte	.=	lk( 'D&eacute;sincrire de la liste noire' , 'blacklist' , FALSE , 'uid='.$id.'&mode=off' , 'off_bl.png' , 'Cliquez ici pour retirer ce b&eacute;n&eacute;vole de la liste noire.' ) ;
}
$texte		.=	lk( 'Liste des b&eacute;n&eacute;voles' , 'liste_benevoles' , FALSE , '' , 'liste.png' , 'Cliquez ici pour retourner &agrave; la liste des b&eacute;n&eacute;voles' ) ;
$texte		.=	lk( 'Accueil' , 'liste_benevoles' , FALSE , '' , 'home.png' ) ;

?>
