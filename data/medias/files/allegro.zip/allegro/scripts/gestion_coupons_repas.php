<?php 

niveau_securite(2) ;

// Prise en compte de la gestion

if( $_GET['mode'] == 'gestion' )
{
	$bdp = '<a name="CC"></a>' ;
	
	$comite 			= select_sql( "Comite" , "IDWeb = ".$_GET['wid'] ) ;

	if( $comite['nbr'] != 1 )
	{
		f_erreur( 25 , "gestion_coupons_repas" , 1 , 'Erreur pour $wid='.$_GET['wid'] ) ;
	}
	
	if( $_GET['ok'] == 0 )
	{
		$dates_dispo = select_sql( "CouponRepas" , "Nom = '' && Prenom = '' && IDWeb = ".$_GET['wid'] , "DISTINCT DateUsage" , "ORDER BY DateUsage" );
		
		$bdp .= "<h2>Administration des coupons-repas du comit&eacute;</h2>" .
					"<p>Les formulaires ci-dessous vous permettent d'ajouter ou de supprimer des " .
					"coupons-repas au comit&eacute; actuellement s&eacute;lectionn&eacute; (".$comite['Nom'].").</p>" .
				"<h3>Ajout</h3>" .
				"<p>Faites usage de ce formulaire pour attribuer des coupons-repas au responsable du comit&eacute; " .
				"en cours. Celui-ci se chargera par la suite de les distribuer aux diff&eacute;rents b&eacute;n&eacute;voles " .
				"de son comit&eacute;.</p>" .
					'<blockquote><form method="post" action="?in='.$_GET['in'].'&ok=1&select_c='.$_GET['select_c'].'&wid='.$_GET['wid'].'&mode='.$_GET['mode'].'#CC"><table cellspacing="5">' .
						"<tr>" .
							'<td width="100"><p><strong>Nombre :</strong></p>' .
							'<p><input type="text" name="add_nbr" maxlength="3" size="5"></p></td>' .
							'<td width="350"><p><strong>Date au format JJ-MM-AAAA </strong>(optionnel)<strong> :</strong>' .
							'<p><input type="text" name="add_jj" maxlength="2" size="5">' .
							'<input type="text" name="add_mm" maxlength="2" size="5">' .
							'<input type="text" name="add_aaaa" maxlength="4" size="10"></p></td>' .
							'<td valign="center">' .
							html_button( 'Ajouter' , 'ajout.png' , "Cliquez ici pour valider l'ajout de coupons-repas au comit&eacute;.") .
							'</td>' .
						"</tr>" .
					"</table></form></blockquote>" ;
				
		if( $dates_dispo['nbr'] != 0 )
		{
				$bdp .= "<h3>Retrait</h3>" .
				"<p>Faites usage de ce formulaire pour supprimer des coupons-repas encore non assign&eacute;s au responsable " .
				"du comit&eacute;. Si aucune date n'est pr&eacute;cis&eacute;e, des coupons-repas vierges seront retir&eacute;s en " .
				"priorit&eacute;.</p>" .
					'<blockquote><form method="post" action="?in='.$_GET['in'].'&ok=2&select_c='.$_GET['select_c'].'&wid='.$_GET['wid'].'&mode='.$_GET['mode'].'#CC"><table cellspacing="5">' .
						"<tr>" .
							'<td width="100"><p><strong>Nombre :</strong></p>' .
							'<p><input type="text" name="del_nbr" maxlength="3" size="5"></p></td>' .
							'<td width="350"><p><strong>Date :</strong>' .
							'<p><select name="del_date">' ;
								
								for( $i = 0 ; $i < $dates_dispo['nbr'] ; $i++ )
								{
									$tmp = denombrer_sql( "CouponRepas" , "Nom = '' && Prenom = '' && IDWeb = ".$_GET['wid']." && DateUsage = '".$dates_dispo[$i][0]."'" ) ;
									
									if( $dates_dispo[$i][0] == '0000-00-00' )
									{
										$bdp .= '<option value="0000-00-00">Vierges ('.$tmp.' disponibles)</option>' ;
									}
									else
									{
										$bdp .= '<option value="'.$dates_dispo[$i][0].'">'.html_date( $dates_dispo[$i][0] ).' ('.$tmp.' disponibles)</option>' ;
									}
								}
								
							$bdp .= '</select></p></td>' .
							'<td valign="center">' .
							html_button( 'Supprimer' , 'retrait.png' , 'Cliquez ici pour confirmer le retrait de coupons-repas au comit&eacute;.') .
							'</td>' .
						"</tr>" .
					"</table></form></blockquote>" ;
		}
	}
	if( $_GET['ok'] == 1 )
	{
		if( $_POST['add_mm'] || $_POST['add_jj'] || $_POST['add_aaaa'] )
		{
			if( depassee( $_POST['add_jj'] , $_POST['add_mm'] , $_POST['add_aaaa'] ) )	
			{
				e_erreur(26) ;
			}
			if( !$contenu['erreur'] )
			{
				if( !checkdate( $_POST['add_mm'] , $_POST['add_jj'] , $_POST['add_aaaa'] ) && ( $_POST['add_mm'] || $_POST['add_jj'] || $_POST['add_aaaa'] ) )
				{
					e_erreur(25) ;
				}
			}
		}
		if( empty( $_POST['add_nbr'] ) || $_POST['add_nbr'] < 1 )		e_erreur(27) ;
		
		if( !$contenu['erreur'] )
		{
			if( empty( $_POST['add_mm'] ) && empty( $_POST['add_jj'] ) && empty( $_POST['add_aaaa'] ) )
			{
				$_POST['add_mm'] 	= '00' ;
				$_POST['add_jj'] 	= '00' ;
				$_POST['add_aaaa']	= '0000' ;
			}
			
			$on[0] = array( 'IDWeb' , $_GET['wid'] , FALSE ) ;
			$on[1] = array( 'DateUsage' , $_POST['add_aaaa']."-".$_POST['add_mm']."-".$_POST['add_jj'] , TRUE ) ;
			
			for( $i = 0 ; $i < $_POST['add_nbr'] ; $i++ )
			{
				insert_sql( "CouponRepas" , $on ) ;
			}
			
			journal( "Attribution coupons-repas : IDWeb[".$_GET['wid']."]-Nombre[".$_POST['add_nbr']."]-Date[".$_POST['add_aaaa']."-".$_POST['add_mm']."-".$_POST['add_jj']."]") ;
			
			$bdp .= "<h2>Insertion r&eacute;ussie</h2>" .
						"<p>Vous avez attribu&eacute; ".$_POST['add_nbr']." coupons-repas au " .
						"comit&eacute; ".$comite['Nom'].".</p>" ;
		}
	}
	if( $_GET['ok'] == 2 )
	{
		$del_infos = select_sql( "CouponRepas" , "IDWeb = ".$_GET['wid']." && DateUsage = '".$_POST['del_date']."'" ) ;
		
		if( empty( $_POST['del_nbr'] ) || $_POST['del_nbr'] < 1 )		e_erreur(27) ;
		if( $del_infos['nbr'] < $_POST['del_nbr'] )						e_erreur(28) ;
		
		if( !$contenu['erreur'] )
		{
			delete_sql( "CouponRepas" , "IDWeb = ".$_GET['wid']." && DateUsage = '".$_POST['del_date']."'" , $_POST['del_nbr'] ) ;
			
			journal( "Suppression coupons-repas : IDWeb[".$_GET['wid']."]-Nombre[".$_POST['del_nbr']."]-Date[".$_POST['del_date']."]") ;
			
			$bdp .= "<h2>Suppression r&eacute;ussie</h2>" .
						"<p>Vous avez supprim&eacute; ".$_POST['del_nbr']." coupons-repas au comit&eacute; ".$comite['Nom'].".</p>" ;
		}
	}
}

// Recherche des responsables de comité

$utilisateur = select_sql( "Web W,Benevole B,Comite C" , "C.IDWeb=W.IDWeb && B.IDBenevole=W.IDBenevole && W.NiveauAutorisation = 1" , "W.IDWeb,W.IDBenevole,B.Nom,B.Prenom,C.Code,C.Nom,C.IDWeb,B.IDBenevole,W.NiveauAutorisation" , "ORDER BY C.Code" ) ;

// Définition des informations du tableau

$infos['titre'][0]	=	"Code" ;								$infos['taille'][0] = 50 ;
$infos['titre'][1]	=	"Comit&eacute;" ;						$infos['taille'][1] = NULL ;
$infos['titre'][2]	=	"Responsable" ;							$infos['taille'][2]	= 150 ;
$infos['titre'][3]	=	"Coupons vierges" ;						$infos['taille'][3]	= 100 ;
$infos['titre'][4]	=	"Coupons &eacute;dit&eacute;s" ;		$infos['taille'][4]	= 100 ;
$infos['titre'][5]	=	NULL ;									$infos['taille'][5] = 100 ;

for( $i = 0 ; $i < $utilisateur['nbr'] ; $i++ )
{
	$contenu[$i][0] = $utilisateur[$i][4] ;
	$contenu[$i][1] = $utilisateur[$i][5] ;
	$contenu[$i][2] = lk( $utilisateur[$i][2]." ".$utilisateur[$i][3] , "profil_benevoles" , TRUE , "uid=".$utilisateur[$i][1] ) ;
	$contenu[$i][3] = denombrer_sql( "CouponRepas" , "IDWeb = ".$utilisateur[$i][0]." && Nom = '' && Prenom = ''" ) ;
	$contenu[$i][4] = denombrer_sql( "CouponRepas" , "IDWeb = ".$utilisateur[$i][0] ) - $contenu[$i][3] ;
	$contenu[$i][5] = '<font size="-1">'.lk("D&eacute;tail","gestion_coupons_repas",FALSE,"select_c=".$i."&wid=".$utilisateur[$i][0]."&mode=voir&ok=0#CC").
			'<br>'.lk("G&eacute;rer","gestion_coupons_repas",FALSE,"select_c=".$i."&wid=".$utilisateur[$i][0]."&mode=gestion#CC").'</font>' ;
}

$titre = "Gestion des coupons-repas" ;
$texte.= "<h2>Liste brute</h2>" .
			"<p>La liste ci-dessous contient la liste des coupons-repas attribu&eacute;s &agrave; chacun des comit&eacute;s.</p>".
			liste( $contenu , $infos , 6 , 25 ).
			$bdp ;

// Prise en compte de la visualisation

if( $_GET['mode'] == 'voir' )
{
	$comite 			= select_sql( "Comite" , "IDWeb = ".$_GET['wid'] ) ;
	$responsable_w		= select_sql( "Web" , "IDWeb = ".$_GET['wid'] ) ;
	$responsable		= select_sql( "Benevole" , "IDBenevole = ".$responsable_w['IDBenevole'] ) ;
	$nombre_coupons 	= denombrer_sql( "CouponRepas" , "IDWeb = ".$_GET['wid'] ) ;
	$nombre_coupons_v	= denombrer_sql( "CouponRepas" , "IDWeb = ".$_GET['wid']." && Nom = '' && Prenom = '' && DateUsage = '0000-00-00'") ;
	$nombre_coupons_d	= denombrer_sql( "CouponRepas" , "IDWeb = ".$_GET['wid']." && Nom = '' && Prenom = '' && DateUsage != '0000-00-00' ") ;
	$nombre_coupons_a	= denombrer_sql( "CouponRepas" , "IDWeb = ".$_GET['wid']." && Nom != '' && Prenom != '' && DateUsage != '0000-00-00' ") ;
	$dates_distinctes	= select_sql( "CouponRepas" , "IDWeb = ".$_GET['wid']." && DateUsage != '0000-00-00'" , "DISTINCT DateUsage" , "ORDER BY DateUsage" );
	
	if( $comite['nbr'] != 1 || $responsable_w['nbr'] != 1 || $responsable['nbr'] != 1 )
	{
		f_erreur( 25 , "gestion_coupons_repas" , 1 , 'Erreur pour $wid='.$_GET['wid'] ) ;
	}
	
	$texte .= 	'<a name="CC"></a>' .
				"<h2>D&eacute;tail</h2>" .
				"<p>La liste ci-dessous d&eacute;taille l'ensemble des coupons-repas attribu&eacute;s au comit&eacute; " .
				$comite['Nom']." (".$comite['Code'].") sous la direction de ".
				lk( $responsable['Prenom']." ".$responsable['Nom'] , "profil_benevoles" , TRUE , "uid=".$responsable['IDBenevole'] ).
				".</p><blockquote>" ;

	$texte .= 	'<table cellspacing="5" width="100%">' .
					"<tr>" .
						'<td width="50%" align="right"><strong>Nombre total de coupons-repas non-p&eacute;rim&eacute;s :</strong></td>' .
						"<td>".$nombre_coupons."</td>" .
					"</tr>" .
					"<tr>" .
						'<td align="right"><em>... dont vierges </em>:</td>' .
						"<td>".$nombre_coupons_v."</td>" .
					"</tr>" .
					"<tr>" .
						'<td align="right"><em>... dont dat&eacute;s </em>:</td>' .
						"<td>".$nombre_coupons_d."</td>" .
					"</tr>" .
					"<tr>" .
						'<td align="right"><em>... dont attribu&eacute;s </em>:</td>' .
						"<td>".$nombre_coupons_a."</td>" .
					"</tr>"  ;
					
	for( $i = 0 ; $i < $dates_distinctes['nbr'] ; $i++ )
	{
		$tmp   = select_sql( "CouponRepas" , "IDWeb = ".$_GET['wid']." && DateUsage = '".$dates_distinctes[$i]['DateUsage']."'" , "DISTINCT Nom,Prenom" ) ;
		$count = denombrer_sql ( "CouponRepas" , "IDWeb = ".$_GET['wid']." && DateUsage = '".$dates_distinctes[$i]['DateUsage']."'" ) ;
		
		$texte .= "<tr>" .
						'<td align="right"><strong>Dat&eacute; pour le '.html_date($dates_distinctes[$i]['DateUsage']).' :</strong></td>' .
						"<td>".$count."</td>" .
					"</tr>" ;
					
		for( $j = 0 , $c = 0 ; $j < $tmp['nbr'] ; $j++ )
		{
			$local = denombrer_sql( "CouponRepas" , "Nom = '".$tmp[$j]['Nom']."' && Prenom = '".$tmp[$j]['Prenom']."' && DateUsage = '".$dates_distinctes[$i]['DateUsage']."'" ) ;
			
			if( empty( $tmp[$j]['Nom'] ) && empty( $tmp[$j]['Prenom'] ) )
			{
				$tmp[$j]['Nom'] = "... vierges" ;
			}
			
			$texte .= "<tr>" .
						'<td align="right"><em>'.$tmp[$j]['Prenom'].' '.$tmp[$j]['Nom'].' </em>:</td>' .
						"<td>".$local."</td>" .
					"</tr>" ;
		}
	}
	
	$texte .= "</table>" ;			
}
if( !isset( $_GET['mode'] ) )
{
	$texte .= "<h2>Options</h2>" .
				lk( 'Identifier' , 'id_cr' , FALSE , '' , 'chercher.png' , 'Cliquez ici pour identifier un coupon-repas &agrave; partir de son num&eacute;ro.' ) .
				lk( 'Liste des comit&eacute;s' , 'gestion_comites' , FALSE , '' , 'liste.png' , 'Cliquez ici pour acc&eacute;der &agrave; la liste compl&egrave;te des comit&eacute;s.' ) .
				lk( 'Retour &agrave; l\'accueil' , 'home' , FALSE , '' , 'home.png' ) ;
}

?>
