<?php

$base = select_sql( 'Benevole' , '1' , 'IDBenevole , Nom , Prenom , Fonction' , 'ORDER BY Nom, Prenom' ) ;

$infos['titre'][0] = 'Nom' ;							$infos['taille'][0] = 150 ;
$infos['titre'][1] = 'Pr&eacute;nom' ;					$infos['taille'][1] = 150 ;
$infos['titre'][2] = 'Fonction' ;						$infos['taille'][2] = NULL ;
$infos['titre'][3] = lk_pdf("liste_benevoles_pdf");		$infos['taille'][3] = 100 ;

for( $i = 0 ; $i < $base['nbr'] ; $i++ )
{
	$contenu[$i][0] = $base[$i]['Nom'] ;
	$contenu[$i][1] = $base[$i]['Prenom'] ;
	$contenu[$i][2] = $base[$i]['Fonction'] ;
	$contenu[$i][3] = '<font size="-1">'.lk('Profil','profil_benevoles',FALSE,'bid='.$base[$i]['IDBenevole']).'<br>'.lk('Aper&ccedil;u','liste_benevoles',FALSE,'select_c='.$i.'&mp='.$base[$i]['IDBenevole'].'#CC').'</font>' ;
}

$titre = 'Liste des b&eacute;n&eacute;voles' ;
$texte = '<h2>Liste brute</h2>' .
			'<p>Vous trouverez ci-dessous la liste compl&egrave;te des b&eacute;n&eacute;voles inscrits au syst&egrave;me.</p>' .
			liste( $contenu , $infos , 4 , 20 , 1 , 50 ) ;
			
if( isset( $_GET['mp'] ) )
{
	$infos_mp = benevole_infos( $_GET['mp'] ) ;
	
	$texte.= '<a name="CC"></a>' ;
	$texte	.=	"<h2>Aper&ccedil;u du profil</h2>" .
			"<p>Les informations ci-dessous concernent le b&eacute;n&eacute;vole actuellement s&eacute;lectionn&eacute;.</p>" .
				'<blockquote><table border="0" cellpading="5" cellspacing="5"><tr>' .
					'<td valign="top">'.html_photo($infos_mp['IDBenevole']).'</td>' .
					'<td valign="top">' .
						'<p>' . $infos_mp['GInfos'] .'</p>' .
						"<p><strong>Nom :</strong> ".$infos_mp['Nom']."</p>" .
						"<p><strong>Pr&eacute;nom :</strong> ".$infos_mp['Prenom']."</p>" .
						"<p><strong>Fonction :</strong> ".$infos_mp['Fonction']."</p>" ;
					
					if( $infos_mp['Comite']['IDComite'] == $session_infos['IDComite'] )
					{
						$texte .= "<p><strong>Comit&eacute secondaire :</strong> ".$infos_mp['ComiteS']['Nom']."</p>" ;
					}
					else
					{
						$texte .= "<p><strong>Comit&eacute principal :</strong> ".$infos_mp['Comite']['Nom']."</p>" ;
					}

	$texte	.=		"<br><strong>Informations confidentielles</strong>" .
						"<p><strong>T&eacute;l&eacute;phone fixe :</strong> ".$infos_mp['TelephoneFixe']."</p>" .
						"<p><strong>T&eacute;l&eacute;phone cellulaire :</strong> ".$infos_mp['TelephoneCellulaire']."</p>" .
						"<p><strong>Date de naissance :</strong> ".html_date($infos_mp['DateNaissance'])."</p>" ;
				
	$texte	.=	'</td>' .
				'</tr></table></blockquote>' ;
				
	$texte .= "<h2>Options</h2>" .
				lk( 'Profil' , 'profil_benevoles' , FALSE , 'bid='.$_GET['mp'] , 'profil.png' , 'Cliquez ici pour visualiser le profil du b&eacute;n&eacute;vole.' ) ;
				
				if( voir_confidentiel( $_GET['mp'] ) )
				{
					$texte .= lk( 'Modifier' , 'modifier_benevole' , FALSE , 'bid='.$_GET['mp'] , 'modifier_infos.png' , 'Cliquez ici pour modifier les informations li&eacute;es &agrave; ce b&eacute;n&eacute;vole.' ) ;
				}
				if( $session_infos['NiveauAutorisation'] == 1 && $infos_mp['Comite']['IDComite'] != $session_infos['IDComite'] && $infos_mp['Comite']['IDComite'] != $session_infos['IDComiteSecondaire'] )
				{
					$texte .= lk( 'Joindre' , 'joindre_benevole' , FALSE , 'bid='.$_GET['mp'] , 'comite.png' , 'Cliquez ici pour joindre ce b&eacute;n&eacute;vole &agrave; votre comit&eacute;.' ) ;
				}
				
				$texte .= lk( 'Retour &agrave; l\'accueil' , 'home' , FALSE , '' , 'home.png' ) ;
}

?>
