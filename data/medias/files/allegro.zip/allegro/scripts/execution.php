<?php

niveau_securite(3) ;

$titre = 'Requ&ecirc;te directe' ;
$texte = "<h2>Avertissement</h2>" .
			"<p>Le formulaire ci-dessous permet l'ex&eacute;cution directe d'une commande sur le " .
			"serveur SQL.</p>" .
			"<p>Cette manipulation n'est pas soumise &agrave; v&eacute;rification et peut se r&eacute;v&eacute;ler " .
			"dangereuse pour l'&eacute;quilibre de la base de donn&eacute;es. Ne faites pas usage de cet outil si " .
			"vous n'&ecirc;tes pas connaisseur du langage SQL et de la structure des bases de donn&eacute;es du syst&egrave;me.</p>" .
			"<p>Par ailleurs, veuillez noter que ce formulaire ne retourne pas de r&eacute;sultat en cas de commande de type " .
			"SELECT.</p>" .
		"<h2>Formulaire de commande</h2>" .
			"<p>Votre commande :</p>" .
			'<div align="center"><form method="post" type="?in=execution">' .
				'<p><textarea name="query" rows="8" cols="80">SELECT * FROM Benevole WHERE 1</textarea></p>' .
				'<p><input type="submit" value="Ex&eacute;cuter"></p>' .
			'</form></div>' ;
			
if( $_POST )
{
	$result = mysql_query( $_POST['query'] ) ;
	
	$texte = "<h2>R&eacute;sultat</h2>" .
				"<p>SQL a retourn&eacute; :</p>" .
				"<p><strong>".$result."</strong></p>" ;
}

?>
