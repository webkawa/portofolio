<?php 

/*	----------------------------------------------------------------
 * 	login.php
 * 	----------------------------------------------------------------
 * 	[Description]
 * 		Fichier de login au système.
 *	----------------------------------------------------------------	*/

$formulaire = "<h2>Formulaire de connexion</h2>" .
'<p>Veuillez entrer vos identifiants pour vous connecter au syst&egrave;me.</p>
<form method="post" action=""><blockquote>
	<p><strong>Votre login :</strong></p><p><input type="text" name="login" size="25"></p>
	<p><strong>Votre mot de passe :</strong></p><p><input type="password" name="password" size="25"></p>
	<p><br>'.html_button('Connexion','connexion.png','Cliquez ici pour vous connecter au syst&egrave;me.').'</p></blockquote>
</form>' ;

if( isset( $_POST['login'] ) || isset( $_POST['password']) )
{	
	if( !login( $_POST['login'] , $_POST['password'] ) )
	{
		e_erreur(1) ;
	}
	else
	{	
		session_infos() ;

		nl_journal() ;
		journal( "Login : ".$_POST['login']."@".md5($_POST['password']) );
	
		$texte 	.= 		"<h2>Identification correcte</h2>" .
					"<p>Vous &ecirc;tes &agrave; pr&eacute;sent connect&eacute;(e) au syst&egrave;me.</p>" .
					"<p>Le paragraphe ci-dessous r&eacute;sume les informations li&eacute;es &agrave; votre compte. Veuillez v&eacute;rifier leur exactitude ; " .
					"en cas d'erreur avec votre nom ou votre pr&eacute;nom, merci de contacter l'administration du syst&egrave;me.</p>" .
						"<h2>Mes identifiants</h2>" .
						"<p><strong>Nom :</strong> ".$session_infos['Nom']."</p>" .
						"<p><strong>Pr&eacute;nom :</strong> ".$session_infos['Prenom']."</p>" .
						"<p><strong>Courriel :</strong> ".$session_infos['Mail']."</p>" .
						"<p><strong>Statut :</strong> ".$session_infos['Fonction']."</p>" .
						"<p><strong>Compte b&eacute;n&eacute;vole :</strong> " .$session_infos['Benevole']['Profil']. "</p>" .
						lk( 'Options' , 'profil' , FALSE , '' , 'options.png' , "Personnalisez votre compte : pseudonyme, mot de passe & adresse de messagerie." ) .
						lk( 'Accueil' , 'home' , FALSE , '' , 'home.png' ) ;
		$titre 	 = "Indentifiants corrects" ;
		$help	 = "F&eacute;licitations ! Vous &ecirc;tes &agrave; pr&eacute;sent connect&eacute;(e) au syst&egrave;me." .
						"Vous pouvez d&eacute;sormais acc&eacute;der &agrave; plusieurs fonctionnalit&eacute;s " .
						"avanc&eacute;es, accessibles via le menu lat&eacute;ral gauche.</p>" ;
	}
}
else
{
	$texte	.=	$formulaire . 
					"<h2>Note</h2>" .
					"<p>Ce formulaire est adress&eacute; aux membres de l'&eacute;quipe du Mondial ainsi " .
					"qu'aux responsables de comit&eacute;. Si vous &ecirc;tes vous m&ecirc;me dans ce second " .
					"cas, mais que vous ne poss&eacute;dez pas d'identifiants, veuillez prendre contact avec " .
					"l'administration du syst&egrave;me en cliquant " . lk('ici','g_contact') . ".</p>" ; 
	$titre	 = "Login" ;
	$help	 = "<p>Perdu votre mot de passe ? Cliquez " . lk('ici','perdu_mdp') . ".</p>" ;
	
	if( $_SESSION['UID'] != 0 )
	{
		$texte.= "<h3>Attention !</h3>" .
					"<p>Vous &ecirc;tes actuellement connect&eacute;(e) au syst&egrave;me. " .
					"Vous loguer &agrave; nouveau aura pour effet de vous d&eacute;connecter de la session actuelle. " .
					"Par ailleurs, poss&eacute;der plusieurs identifiants de connection diff&eacute;rents est une situation anormale ; " .
					"si vous n'&ecirc;tes pas administrateur du syst&egrave;me, merci de " . lk('contacter','g_contact') .
					" les responsables du site.</p>" ;
	}
	else
	{
		$texte	.= "<h2>Options</h2>" .
					lk( 'Restauration' , 'perdu_mdp' , FALSE , '' , 'clef.png' , 'Cliquez ici en cas de perte de vos identifiants.' ) .
					lk( 'Retour &agrave; l\'accueil' , 'home' , FALSE , '' , 'home.png' ) ;
	}
}

?>
