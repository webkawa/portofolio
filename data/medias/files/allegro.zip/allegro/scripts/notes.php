<?php

$titre = 'Notes' ;
$texte = "<p>Les notes suivantes sont relatives &agrave; la version courante d'Allegro.</p>" .
		'<blockquote>' .
			'<table cellspacing="15">' .
				'<tr valign="middle">' .
					'<td><img src="'.$folder['picts'].'infos_version.png" border="0"></td>' .
					'<td>' .
						'<p><font size="+1"><strong>Notes de version</strong></font></p>' .
						'<font size="-1">' .
							"<p>Version courante : " . $global['version'] . "</p>" .
							"<p>Derni&egrave;re mise &agrave; jour : " . html_date( $global['maj'] ) . "</p>" .
							"<p>Adresse courante : " . $global['url'] . "</p>" .
						'</font>' .
					'</td>' .
				'</tr>' .
			'</table>' .
			'<table cellspacing="15">' .
				'<tr valign="middle">' .
					'<td><img src="'.$folder['picts'].'resolution.png" border="0"></td>' .
					'<td>' .
						'<p><font size="+1"><strong>R&eacute;solution minimale</strong></font></p>' .
						'<font size="-1">' .
							"<p>Ce site est optimis&eacute; pour un affichage minimal de 1024 pixels de large, 16 millions de couleurs ou sup&eacute;rieur.</p>" .
							"<p>L'affichage en dessous de cette r&eacute;solution est possible mais d&eacute;conseill&eacute; car inconfortable.</p>" .
						'</font>' .
					'</td>' .
				'</tr>' .
			'</table>' .
			'<table cellspacing="15">' .
				'<tr valign="middle">' .
					'<td><img src="'.$folder['picts'].'securite.png" border="0"></td>' .
					'<td>' .
						'<p><font size="+1"><strong>Informations s&eacute;curis&eacute;es</strong></font></p>' .
						'<font size="-1">' .
							"<p>Ce syst&egrave;me stocke des informations &agrave; caract&egrave;re priv&eacute;.</p>" .
							"<p>La conservation de ces donn&eacute;es se fait &agrave; travers des m&eacute;canismes s&eacute;curis&eacute;s afin de guarantir " .
							"le total respect de l'intimit&eacute; des b&eacute;n&eacute;voles concern&eacute;s.</p>" .
							"<p>Le retrait de tout ou partie des informations vous concernant est toutefois possible sur simple demande, conform&eacute;ment &agrave; " .
							"la r&eacute;glementation en vigueur.</p>" .
						'</font>' .
					'</td>' .
				'</tr>' .
			'</table>' .
			'<table cellspacing="15">' .
				'<tr valign="middle">' .
					'<td><a href="http://www.mozilla-europe.org/fr/firefox/"><img src="'.$folder['picts'].'firefox.png" border="0"></a></td>' .
					'<td>' .
						'<p><font size="+1"><strong>Con&ccedil;u pour Mozilla Firefox</strong></font></p>' .
						'<font size="-1">' .
							"<p>Ce site a &eacute;t&eacute; r&eacute;alis&eacute; et test&eacute; sous Firefox 3.0</p>" .
							"<p>Firefox est un navigateur gratuit, simple et efficace aux fonctionnalit&eacute;s multiples. Essayez le d&egrave;s maintenant : " .
							'<a href="http://www.mozilla-europe.org/fr/firefox/">http://www.mozilla-europe.org</a></p>' .
						'</font>' .
					'</td>' .
				'</tr>' .
			'</table>' .
			
			'<table cellspacing="15">' .
				'<tr valign="middle">' .
					'<td><a href="http://www.gnu.org/home.fr.html"><img src="'.$folder['picts'].'gnu.png" border="0"></a></td>' .
					'<td>' .
						'<p><font size="+1"><strong>Logiciel sous licence GFDL</strong></font></p>' .
						'<font size="-1">' .	
							'<p>Ce logiciel est d&eacute;pos&eacute; sous licence libre GNU.</p>' .
							'<p>Vous pouvez consulter les termes de la licence GFDL &agrave; ' . lk( "cette adresse" , "gnu" , TRUE ) . ', ou vous ' .
							'rendre sur le site officiel : <a href="http://www.gnu.org/home.fr.html">http://www.gnu.org</a></p>' .
							'<p>Pour obtenir tout ou partie des sources du logiciel, merci de contacter G.ZAVAN &agrave; l\'adresse webkawa[@]gmail.com' .
							'</p>' .
						'</font>' .
					'</td>' .
				'</tr>' .
			'</table>' .
			'</blockquote>' ;

?>
