<?php

niveau_securite(3) ;

// Variable d'usage

$lvl = 2 ;

// Gestion des actions

if( empty( $_GET['mode'] ) || $_GET['mode'] == 'add' )
{
	if( $_GET['ok'] != 1 )
	{
		// Recherche des bénévoles élisibles au poste de responsable
			
		$query = "SELECT distinct B.Nom,B.Prenom,B.IDBenevole,B.Mail
					FROM Benevole B,Web W
					WHERE 1
					AND 
						( NOT EXISTS 
							( SELECT  W.IDBenevole 
								FROM  Web W
								WHERE B.IDBenevole=W.IDBenevole
							)
						)
					ORDER BY B.Nom" ;
		
		$cid = connection_sql() ;
			
		if( !$res = mysql_query( $query ) )
		{
			f_erreur( 23 , 'gestion_moderateurs.php' , 4 , 'Erreur SQL in ['.$query.']' ) ;
		}
			
		deconnection_sql( $cid ) ;
			
		// Retour du formulaire
			
		$bdp	.=	"<h2>Cr&eacute;ation du compte mod&eacute;rateur</h2>" .
						"<p>Remplissez les champs ci-dessous pour cr&eacute;er un nouveau compte mod&eacute;rateur. " .
						"Un mail sera exp&eacute;di&eacute; &agrave; l'adresse sp&eacute;cifi&eacute;e " .
						"avec les informations n&eacute;cessaires &agrave; la connexion au compte.</p>" .
					'<blockquote><form method="post" action="?in=gestion_moderateurs&ok=1">' .
					'<table cellpading="10" width="100%">' .
					'<tr><td>' .
						'<p><strong>Nom :</strong></p><p><input type="text" maxlength="32" name="nom"></p>' .
					'</td><td>' .
						'<p><strong>Pr&eacute;nom :</strong></p><p><input maxlength="32" type="text" name="prenom"></p>' .
					'</td></tr>' .
					'<tr><td>' .
						'<p><strong>Adresse de messagerie :</strong></p><p><input maxlength="64" type="text" name="mail"></p>' .
					'</td><td>' .
						'<p><strong>Fiche b&eacute;n&eacute;vole associ&eacute;e :</strong></p>' .
						'<p><select name="benevole">' ;
						
		for( $i = 0 ; $tmp = mysql_fetch_array( $res , MYSQL_BOTH ) ; $i++ )
		{
			$bdp.= '<option value="'.$tmp[2].'">'.$tmp[0].' '.$tmp[1].' ('.vide($tmp[3]).')</option>' ;
		}
		
		$bdp.=		'</select></p>' .
					'</td></tr>' .
					'<tr><td>' .
						'<p><input type="submit" value="Cr&eacute;er"></p>' .
					'</td><td></td></tr>' .
					'</table></form></blockquote>' .
				"<p><strong>Note : </strong>si aucune valeur n'est pr&eacute;cis&eacute; pour le nom, le pr&eacute;nom ou l'adresse mail, " .
				"les informations contenues dans la fiche b&eacute;n&eacute;vole li&eacute;e seront utilis&eacute;es.</p>" ;
	}
	else
	{
		// Sélection des informations bénévole
		
		$fiche_b = select_sql( "Benevole" , "IDBenevole = ".$_POST['benevole'] ) ;
		
		// Validation de la fiche
		
		if( $fiche_b['nbr'] != 1 )
		{
			f_erreur( 32 , 'gestion_moderateurs.php' , 1 , "Benevole invalide pour ID=".$_POST['benevole'] ) ;
		}
		
		// Récupération des informations
		
		if( empty( $_POST['nom'] ) || empty( $_POST['prenom'] ) )
		{
			$_POST['nom']		= $fiche_b['Nom'] ;
			$_POST['prenom']	= $fiche_b['Prenom'] ;
		}
		if( empty( $_POST['mail'] ) )
		{
			$_POST['mail']		= $fiche_b['Mail'] ;
		}
		
		// Validation des champs
		
		if( empty($_POST['nom']) || empty($_POST['prenom'] ) )					e_erreur(15) ;
		if( !valider_mail( $_POST['mail'] ) )									e_erreur(16) ;
		
		// Création
		
		if( !$contenu['erreur'] )
		{
			creer_compte( 2 , $_POST['nom'] , $_POST['prenom'] , $_POST['mail'] , $_POST['benevole'] ) ;
			journal( "Creation du compte moderateur : IDWeb[".select_max_sql('Web','IDWeb')."]" ) ;
			
			$on[0] = array( "Mail" , $_POST['mail'] , TRUE ) ;
			
			update_sql( "Benevole" , $on , "IDBenevole = ".$_POST['benevole'] ) ;
			
			$bdp = "<h2>Cr&eacute;ation r&eacute;ussie</h2>" .
					"<p>Le compte a &eacute;t&eacute; correctement cr&eacute;&eacute;.</p>" ;
		}
	}
}
if( $_GET['mode'] == 'voir' )
{
	$mod_infos = select_sql( "Web W, Benevole B" , "B.IDBenevole = W.IDBenevole && NiveauAutorisation = ".$lvl." && W.IDWeb = ".$_GET['uid'] , "W.*,B.Nom,B.Prenom" ) ;
	
	if( $mod_infos['nbr'] != 1 )
	{
		f_erreur( 25 , "gestion_moderateurs.php" , 1 , "ID moderateur invalide : ID[".$mod_infos[0]."]") ;
	}
	
	$bdp .= "<h2>Aper&ccedil;u du compte</h2>" .
			"<p>Les informations ci-dessous sont relatives au compte actuellement s&eacute;lectionn&eacute; :</p>" .
			'<blockquote>' .
				'<p><strong>Pseudonyme :</strong> '.$mod_infos[2].'</p>' .
				'<p><strong>Nom :</strong> '.$mod_infos[5].'</p>' .
				'<p><strong>Pr&eacute;nom :</strong> '.$mod_infos[6].'</p>' .
				'<p><strong>Niveau :</strong> '.type_compte( $mod_infos[7] ).'</p>' .
				'<p><strong>Adresse de messagerie :</strong> ' .$mod_infos[4].'</p>' .
				'<p><strong>Fiche b&eacute;n&eacute;vole li&eacute;e :</strong> '.lk( $mod_infos[8] .' '. $mod_infos[9] , 'profil_benevoles' , FALSE , 'wid='.$_GET['uid'] ).'</p>' .
			'</blockquote>' ;
}
if( $_GET['mode'] == 'delete' )
{
	if( $_GET['ok'] != 1 )
	{
		$bdp .= '<h2>Suppression du compte</h2>' .
				'<p>Confirmez-vous la suppression du compte actuellement s&eacute;lectionn&eacute; ?</p>' .
				'<blockquote>' .
					lk('Supprimer le compte','gestion_moderateurs',FALSE,'uid='.$_GET['uid'].'&ok=1&mode=delete','valider.png').
					lk('Annuler','gestion_moderateurs',FALSE,'select_c='.$_GET['select_c'],'annuler.png').
				'</blockquote>' ;
	}
	else
	{
		$tmp = denombrer_sql( "Web" , "IDWeb = ".$_GET['uid'] ) ;
		
		if( $tmp != 1 )
		{
			f_erreur( 25 , "gestion_moderateurs.php" , 1 , "ID moderateur invalide : ID[".$_GET['uid']."]") ;
		}
		
		delete_sql( "Web" , "IDWeb = ".$_GET['uid']." && NiveauAutorisation = ".$lvl ) ;
		journal( "Suppression du compte moderateur : ID[".$_GET['uid']."]" ) ;
		
		$bdp = "<h2>Suppression effectu&eacute;e</h2>" .
				"<p>Le compte mod&eacute;rateur a &eacute;t&eacute; correctement supprim&eacute;.</p>" ;
	}
}

// Génération de la liste

$wu = select_sql( "Web W, Benevole B" , "B.IDBenevole = W.IDBenevole && W.NiveauAutorisation = ".$lvl , "W.*,B.IDBenevole,B.Nom,B.Prenom" , "ORDER BY W.Nom, W.Prenom" ) ;

$infos['titre'][0]	=	"ID" ;						$infos['taille'][0]	=	50 ;
$infos['titre'][1]	=	"Pseudonyme" ;				$infos['taille'][1]	=	150 ;
$infos['titre'][2]	=	"Mail" ;					$infos['taille'][2]	=	NULL ;
$infos['titre'][3]	=	"Identit&eacute;" ;			$infos['taille'][3]	=	250 ;
$infos['titre'][4]	=	NULL ;						$infos['taille'][4]	=	150 ;

for( $i = 0 ; $i < $wu['nbr'] ; $i++ )
{	
	$contenu[$i][0]	=	$wu[$i][0] ;
	$contenu[$i][1]	=	$wu[$i][2] ;
	$contenu[$i][2]	=	$wu[$i][4] ;
	$contenu[$i][3]	=	$wu[$i][5]." ".$wu[$i][6].'<br><font size="-1">Fiche li&eacute;e : '.lk( $wu[$i][9].' '.$wu[$i][10] , 'profil_benevoles' , FALSE , 'uid='.$wu[$i][8] ).'</font>' ;
	$contenu[$i][4]	=	'<font size="-1">'.lk('Aper&ccedil;u','gestion_moderateurs',FALSE,'mode=voir&select_c='.$i.'&uid='.$wu[$i]['IDWeb'].'#CC').'<br>'.lk('Supprimer','gestion_moderateurs',FALSE,'mode=delete&select_c='.$i.'&uid='.$wu[$i]['IDWeb'].'#CC').'</font>' ;
}

// Retour

$titre	=	"Gestion des mod&eacute;rateurs" ;
$texte	.=	"<h2>Liste brute</h2>" .
				"<p>Cette liste r&eacute;sume l'ensemble des comptes mod&eacute;rateur enregistr&eacute;s sur le syst&egrave;me.</p>" ;
				
if( $wu['nbr'] != 0 )
{
	$texte	.=	liste( $contenu , $infos , 5 , 50 ) ;
}
else $texte	.=	'<blockquote><em>Aucun mod&eacute;rateur d&eacute;fini</em></blockquote>' ;

$texte	.=	'<a name="CC"></a>' ;
$texte	.=	$bdp ;

?>
