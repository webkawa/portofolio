<?php

niveau_securite(1) ;

$titre 	= "Insertion d'un b&eacute;n&eacute;vole" ;

// Départ d'insertion

if( !isset( $_SESSION['InsertB']['Step'] ) )
{
	$_SESSION['InsertB']['Step'] = 1 ;
}

// Traitement

if( $_GET['ok'] == 'kill' )
{
	$_SESSION['InsertB'] = FALSE ;
	$_SESSION['InsertB']['Step'] = 1 ;
}
if( $_GET['ok'] == 1 )
{
	$tmp = denombrer_sql( "Benevole" , "Nom = '".$_POST['nom']."' && Prenom = '".$_POST['prenom']."'" ) ;
	
	if( empty( $_POST['nom'] ) || empty( $_POST['prenom'] ) )						e_erreur(15) ;
	if( $tmp != 0 && !$_POST['forcer'] )											e_erreur(33) ;
	
	if( !$contenu['erreur'] )
	{
		$_SESSION['InsertB'][1] = $_POST ;
		$_SESSION['InsertB']['Step'] = 2 ;
		
		if( $_SESSION['InsertB'][1]['sexe'] == 'm' )
		{
			$_SESSION['InsertB'][1]['sexe_l'] = "monsieur" ;
			$_SESSION['InsertB'][1]['sexe_b'] = 0 ;
		}
		else
		{
			$_SESSION['InsertB'][1]['sexe_l'] = "madame" ;
			$_SESSION['InsertB'][1]['sexe_b'] = 1 ;
		}
	}
}
if( $_GET['ok'] == 2 )
{
	if( $_POST['ville'] == 'NULL' )						$_POST['ville'] = $_POST['ville_autre'] ;
	
	if( !checkdate( $_POST['mm'] , $_POST['jj'] , $_POST['aaaa'] ) )				e_erreur(18) ;
	if( !depassee( $_POST['jj'] , $_POST['mm'] , $_POST['aaaa'] ) )					e_erreur(18) ;
	if( empty( $_POST['adresse'] ) )												e_erreur(20) ;
	if( empty( $_POST['ville'] ) )													e_erreur(34) ;
	if( empty( $_POST['telephone_p'] ) || strlen( $_POST['telephone_p'] ) != 10 )	e_erreur(21) ;
	if( $_POST['telephone_s'] != '' && strlen( $_POST['telephone_s'] ) != 10 )		e_erreur(21) ;
	if( strlen( $_POST['cp'] ) != 6 )												e_erreur(35) ;
	if( empty( $_POST['province'] ) )												e_erreur(36) ;
	if( $_POST['mail'] != '' && !valider_mail( $_POST['mail'] ) )					e_erreur(16) ;
	
	if( !$contenu['erreur'] )
	{
		$_SESSION['InsertB'][2] = $_POST ;
		$_SESSION['InsertB']['Step'] = 3 ;
	}
}
if( $_GET['ok'] == 3 )
{
	if( $_POST['comite'] == 'NULL' )					$_POST['comite'] = 0 ;
	
	if( denombrer_sql( "Comite" , "IDComite = ".$_POST['comite'] ) != 1 )
	{
		f_erreur( 33 , "inserer_benevoles.php" , 1 , "Comite inexistant : IDComite[".$_POST['comite']."]" ) ;
	}
	
	if( $_POST['fonction'] == 'NULL' )					$_POST['fonction'] = $_POST['fonction_autre'] ;
	if( empty( $_POST['horaire'] ) )					$_POST['horaire'] = 0 ;
	
	if( empty( $_POST['fonction'] ) )												e_erreur(37) ;
	if( !is_numeric( $_POST['horaire'] ) )											e_erreur(43) ;
	
	if( !$contenu['erreur'] )
	{
		$_SESSION['InsertB'][3] = $_POST ;
		$_SESSION['InsertB']['Step'] = 4 ;		
	}
}
if( $_GET['ok'] == 4 )
{
	if( $_POST['zone'] == '0' )			$_POST['zone'] = 0 ;
	else								$_POST['zone'] = 1 ;
	
	if( empty( $_POST['na'] ) )			$_POST['na'] = 0 ;
	
	$tmp = select_sql( "CouleurAccreditation" , "IDCouleurAccreditation = ".$_POST['na'] ) ;
	
	$_POST['na_l'] = $tmp['Nom'] ;
	
	if( !$_POST['recommandable'] )													e_erreur(38) ;
	
	if( !$contenu['erreur'] )
	{
		$_SESSION['InsertB'][4] = $_POST ;
		$_SESSION['InsertB']['Step'] = 5 ;
	}
}
if( $_GET['ok'] == 5 )
{
	$upload_erreur = FALSE ;
	
	if( $_POST['statut'] )					$_POST['statut'] = 1 ;
	else									$_POST['statut'] = 0 ;
	
	$on[0]  = array( 'IDComite' , $_SESSION['InsertB'][3]['comite'] , FALSE ) ;
	$on[1]  = array( 'IDComiteSecondaire' , 0 , FALSE ) ;
	$on[2]  = array( 'IDCouleurAccreditation' , $_SESSION['InsertB'][4]['na'] , FALSE ) ;
	$on[3]  = array( 'Nom' , $_SESSION['InsertB'][1]['nom'] , TRUE ) ;
	$on[4]  = array( 'Prenom' , $_SESSION['InsertB'][1]['prenom'] , TRUE ) ;
	$on[5]  = array( 'Sexe' , $_SESSION['InsertB'][1]['sexe_b'] , FALSE ) ;
	$on[6]  = array( 'DateNaissance' , $_SESSION['InsertB'][2]['aaaa'].'-'.$_SESSION['InsertB'][2]['mm'].'-'.$_SESSION['InsertB'][2]['jj'] , TRUE ) ;
	$on[7]  = array( 'Adresse' , $_SESSION['InsertB'][2]['adresse'] , TRUE ) ;
	$on[8]  = array( 'Ville' , $_SESSION['InsertB'][2]['ville'] , TRUE ) ;
	$on[9]  = array( 'CodePostal' , $_SESSION['InsertB'][2]['cp'] , TRUE ) ;
	$on[10] = array( 'Province' , $_SESSION['InsertB'][2]['province'] , TRUE ) ;
	$on[11] = array( 'TelephoneFixe' , $_SESSION['InsertB'][2]['telephone_p'] , TRUE ) ;
	$on[12] = array( 'TelephoneCellulaire' , $_SESSION['InsertB'][2]['telephone_s'] , TRUE ) ;
	$on[13] = array( 'Mail' , $_SESSION['InsertB'][2]['mail'] , TRUE ) ;
	$on[14] = array( 'Statut' , $_POST['statut'] , FALSE ) ;
	$on[15] = array( 'Imprime' , 0 , FALSE ) ;
	$on[16] = array( 'Recommandable' , 1 , FALSE ) ;
	$on[17] = array( 'Heures' , $_SESSION['InsertB'][3]['horaire'] , FALSE ) ;
	$on[18] = array( 'Privileges' , 0 , FALSE ) ;
	$on[19] = array( 'Zone' , $_SESSION['InsertB'][4]['zone'] , FALSE ) ;
	$on[20] = array( 'Fonction' , $_SESSION['InsertB'][3]['fonction'] , TRUE ) ;
	
	insert_sql( "Benevole" , $on ) ;
	$id_nb = select_max_sql( "Benevole" , "IDBenevole" ) ;
	$on = FALSE ;
	
	$tmp_upload = upload( $id_nb ) ;
		
	if( $tmp_upload )
	{
		$on[0] = array( 'Photo' , $tmp_upload , TRUE ) ;
		update_sql( "Benevole" , $on , "IDBenevole = ".$id_nb ) ;
	}
	else
	{
		$upload_erreur = TRUE ;
	}
	
	journal( "Creation du benevole : IDBenevole[".$id_nb."]" ) ;
	
	$_SESSION['InsertB'][5] = $_POST ;
}

// En-tête

$texte .= "<p><strong>Note :</strong> merci de v&eacute;rifier que le b&eacute;n&eacute;vole dont " .
			"vous souhaitez r&eacute;aliser l'enregistrement n'est pas d&eacute;j&agrave; sur " .
			"les listes avant d'entammer toute proc&eacute;dure d'inscription !</p>" ;

// Etape 1 : informations élémentaires

if( $_SESSION['InsertB']['Step'] > 0 )
{
	if( !isset( $_SESSION['InsertB'][1] ) )
	{
		$texte .= '<a name="CC"></a>' .
					"<h2>[1/5] : Informations primaires</h2>" .
					"<p>Veuillez ins&eacute;rer le nom et le pr&eacute;nom du nouveau b&eacute;n&eacute;vole " .
					"dans le formulaire ci-dessous.</p>" .
					'<blockquote><form method="post" action="?in=inserer_benevoles&ok=1#CC"><table align="center" cellspacing="10">' .
						'<tr>' .
							'<td valign="bottom">' .
								'<select name="sexe">' .
									'<option value="m">M.</option>' .
									'<option value="f">Mme</option>' .
								'</select>' .
							'<td>' .
								'<p><strong>Nom :</strong></p>' .
								'<p><input type="text" name="nom" maxlength="32"></p>' .
							'</td>' .
							'<td>' .
								'<p><strong>Pr&eacute;nom :</strong></p>' .
								'<p><input type="text" name="prenom" maxlength="32"></p>' .
							'</td>' .
							'<td valign="bottom" align="center">' .
								'<p><strong>[F]</strong></p>' .
								'<p><input type="checkbox" name="forcer"></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td colspan="4" valign="bottom" align="center">' .
								html_button( 'Valider' , 'suivant.png' , "Cliquez ici pour passer &agrave; l'&eacute;tape suivante (2/5)." ) .
							'</td>' .
						'</tr>' .
					'</table></form></blockquote>' .
					'<p><strong>Note :</strong> laisser la case [F] d&eacute;coch&eacute;e, &agrave; moins d\'avoir re&ccedil;u des instructions contraires.</p>' ;
	}
	else
	{
		$bdp = "<h2>Rappel des informations</h2>" .
					"<h3>Information primaires</h3>" .
					"<p>Les informations suivantes servent &agrave; isoler le b&eacute;n&eacute;vole au sein de la base de donn&eacute;es.</p>" .
						"<blockquote>" .
							"<p><strong>Qualit&eacute; :</strong> ".$_SESSION['InsertB'][1]['sexe_l']."</p>" .
							"<p><strong>Nom :</strong> ".$_SESSION['InsertB'][1]['nom']."</p>" .
							"<p><strong>Pr&eacute;nom :</strong> ".$_SESSION['InsertB'][1]['prenom']."</p>" .
						"</blockquote>" ;	
	}
}

// Etape 2 : informations personnelles

if( $_SESSION['InsertB']['Step'] > 1 )
{
	if( !isset( $_SESSION['InsertB'][2] ) )
	{
		$texte .= '<a name="CC"></a>' .
					"<h2>[2/5] : Informations personnelles</h2>" .
					"<p>Veuillez ins&eacute;rer les informations personnelles du b&eacute;n&eacute;vole dans le formulaire ci-dessous. " .
					"Prenez garde &agrave; faire preuve de la plus grande exactitude possible durant cette &eacute;tape.</p>" .
					"<p><strong>Note :</strong> les champs marqu&eacute;s d'une &eacute;toile sont obligatoires.</p>" .
					'<blockquote><form method="post" action="?in=inserer_benevoles&ok=2#CC"><table align="center" cellspacing="10">' .
						'<tr>' .
							'<td>' .
								'<p><strong>* Date de naissance :</strong></p>' .
								'<p>' .
									'<input type="text" maxlength="2" size="5" name="jj">' .
									'<select name="mm">' .
										'<option value="01">Janvier</option>' .
										'<option value="02">F&eacute;vrier</option>' .
										'<option value="03">Mars</option>' .
										'<option value="04">Avril</option>' .
										'<option value="05">Mai</option>' .
										'<option value="06">Juin</option>' .
										'<option value="07">Juillet</option>' .
										'<option value="08">Aout</option>' .
										'<option value="09">Septembre</option>' .
										'<option value="10">Octobre</option>' .
										'<option value="11">Novembre</option>' .
										'<option value="12">D&eacute;cembre</option>' .
									'</select>' .
									'<input type="text" maxlength="4" size="10" name="aaaa">' .
								'</p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>* Adresse :</strong></p>' .
								'<p><input type="text" maxlength="128" size="30" name="adresse"></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>* Ville :</strong></p>' .
								'<p><select name="ville">' ;
							
		$tmp = select_sql( "Benevole" , "1" , "DISTINCT Ville", "ORDER BY Ville" ) ;
		
		for( $i = 0 ; $i < $tmp['nbr'] ; $i++ )
		{
			$texte.= '<option value="'.$tmp[$i]['Ville'].'">'.$tmp[$i]['Ville'].'</option>' ;
		}
				
					$texte.=	'<option value="NULL">Autre :</option>' .
								'<input type="text" maxlength="32" size="20" name="ville_autre"></p>' .
						'<tr>' .
							'<td>' .
								'<p><strong>* Code postal & * Province :</strong></p>' .
								'<p><input type="text" maxlength="6" size="5" name="cp"><input type="text" maxlength="32" size="20" name="province" value="Qu&eacute;bec"></p>' .
								'<p><font size="-1">Code postal &agrave; 6 caract&egrave;res uniquement (ni espace, ni tiret)</font></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>* T&eacute;l&eacute;phone fixe :</strong></p>' .
								'<p><input type="text" name="telephone_p" maxlength="10" size="15"></p>' .
								'<p><font size="-1">Num&eacute;ro &agrave; dix chiffres uniquement (ni espace, ni tirets)</font></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>T&eacute;l&eacute;phone cellulaire :</strong></p>' .
								'<p><input type="text" name="telephone_s" maxlength="10" size="15"></p>' .
								'<p><font size="-1">Num&eacute;ro &agrave; dix chiffres uniquement (ni espace, ni tirets)</font></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>Adresse de messagerie :</strong></p>' .
								'<p><input type="text" name="mail" maxlength="64" size="20"></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								html_button( "Valider" , "suivant.png" , "Cliquez ici pour passer &agrave; l'&eacute;tape suivante (3/5)." ) .
							'</td>' .
						'</tr>' .
					'</table></form></blockquote>' ;
	}
	else
	{
		$bdp .= "<h3>Informations personnelles</h3>" .
					"<p>Les informations ci-dessous permettent d'identifier de mani&eacute;re pr&eacute;cise le b&eacute;n&eacute;vole.</p>" .
					"<blockquote>" .
						"<p><strong>Date de naissance :</strong> ".html_date( $_SESSION['InsertB'][2]['aaaa'].'-'.$_SESSION['InsertB'][2]['mm'].'-'.$_SESSION['InsertB'][2]['jj'] )."</p>" .
						"<p><strong>Adresse :</strong> ".$_SESSION['InsertB'][2]['adresse']."</p>" .
						"<p><strong>Ville :</strong> ".$_SESSION['InsertB'][2]['ville']."</p>" .
						"<p><strong>Code postal :</strong> ".$_SESSION['InsertB'][2]['cp']."</p>" .
						"<p><strong>Province :</strong> ".$_SESSION['InsertB'][2]['province']."</p>" .
						"<p><strong>T&eacute;l&eacute;phone principal :</strong> ".$_SESSION['InsertB'][2]['telephone_p']."</p>" .
						"<p><strong>T&eacute;l&eacute;phone secondaire :</strong> ".vide( $_SESSION['InsertB'][2]['telephone_s'] )."</p>" .
						"<p><strong>Adresse de courriel :</strong> ".vide( $_SESSION['InsertB'][2]['mail'] )."</p>" .
					"</blockquote>" ;
	}
}

// Etape 3 : fonction - comité

if( $_SESSION['InsertB']['Step'] > 2 )
{
	if( !isset( $_SESSION['InsertB'][3] ) )
	{
		$texte .= '<a name="CC"></a>' .
					"<h2>[3/5] : Inscription au comit&eacute;</h2>" .
					"<p>Le formulaire ci-dessous vous permet d'inscrire le nouveau b&eacute;n&eacute;vole dans un " .
					"comit&eacute; et d'en pr&eacute;ciser la fonction. Si vous n'&ecirc;tes pas s&ucirc;(e) de la destination finale de ce dernier, " .
					"entrez 'Disponible'.</p>" .
					'<blockquote><form method="post" action="?in=inserer_benevoles&ok=3#CC"><table align="center" cellspacing="10">' .
						'<tr>' .
							'<td>' .
								'<p><strong>Comit&eacute; courant :</strong></p>' .
								'<p><select name="comite">' ;
									
		if( $session_infos['NiveauAutorisation'] == 1 )
		{
			$texte .= '<option value="'.$session_infos['IDComite'].'">Mon comit&eacute;</option>' .
					'<option value="0">Disponible</option>' ;
		}
		if( $session_infos['NiveauAutorisation'] > 1 )
		{
			$tmp = select_sql( "Comite" , "1" , "*" , "ORDER BY Nom" );
			
			for( $i = 0 ; $i < $tmp['nbr'] ; $i++ )
			{
				$texte .= '<option value="'.$tmp[$i]['IDComite'].'">'.$tmp[$i]['Nom'].'</option>' ;
			}
		}
		
		$texte .=				'</select></p>' .
							'</td>' .
						'<tr>' .
						'</tr>' .
							'<td>' .
								'<p><strong>Fonction :</strong></p>' .
								'<p>' .
									'<select name="fonction">' ;
									
		$tmp = select_sql( "Benevole" , "1" , "DISTINCT Fonction" , "ORDER BY Fonction" ) ;
		
		for( $i = 0 ; $i < $tmp['nbr'] ; $i++ )
		{
			$texte .= '<option value="'.$tmp[$i][0].'">'.$tmp[$i][0].'</option>' ;
		}
		
		$texte .=						'<option value="NULL">Autre :</option>' .
									'</select>' .
									'<input type="text" name="fonction_autre">' .
								'</p>' .
							'</td>' .
						'<tr>' .
						'</tr>' .
							'<td>' .
								html_button( "Valider" , "suivant.png" , "Cliquez ici pour passer &agrave; l'&eacute;tape suivante (4/5)." ) .
							'</td>' .
						'</tr>' .
					'</table></form></blockquote>' ;
	}
	else
	{
		$bdp .= "<h3>Comit&eacute; & Fonction</h3>" ;
		
		if( $_SESSION['InsertB'][3]['comite'] == 0 )
		{
			$bdp .= "<p>Le b&eacute;n&eacute;vole est inscrit comme &eacute;tant disponible.</p>" ;
		}
		else
		{
			$tmp = select_sql( "Comite" , "IDComite = ".$_SESSION['InsertB'][3]['comite'] ) ;
			
			$bdp .= "<p>Le b&eacute;n&eacute;vole est inscrit au comit&eacute; suivant :</p>" .
						"<blockquote>" .
							"<p><strong>Nom :</strong> ".$tmp['Nom']."</p>" .
							"<p><strong>Code :</strong> ".$tmp['Code']."</p>" .
							"<p><strong>Description :</strong> ".$tmp['Description']."</p>" .
						"</blockquote>" ;
		}
		
		$bdp .= "<blockquote><p><strong>Fonction :</strong> ".$_SESSION['InsertB'][3]['fonction']."</p></blockquote>" ;
	}
}

// Etape 4 : niveau d'accréditation / Administration

if( $_SESSION['InsertB']['Step'] > 3 )
{
	if( !isset( $_SESSION['InsertB'][4] ) )
	{
		$texte .= '<a name="CC"></a>' . 
				"<h2>[4/5] : Informations administratives</h2>" .
					"<p>Les informations ci-dessous sont essentiellement adress&eacute;es &agrave; l'&eacute;quipe du Mondial.</p>" .
					'<blockquote><form method="post" action="?in=inserer_benevoles&ok=4#CC"><table align="center" cellspacing="10">' .
						'<tr>' .
							'<td>' .
								'<p><strong>Statut :</strong></p>' .
								'<p><input type="checkbox" name="recommandable" checked>Je certifie ce b&eacute;n&eacute;vole comme recommandable et responsable de ses actes</p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>Volume horaire estim&eacute; :</strong></p>' .
								'<p><input type="text" maxlength="2" name="horaire" size="5">h</p>' .
								'<p><font size="-1">Laisser vacant si inconnu</font></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>Zone d\'activit&eacute; :</strong></p>' .
								'<p><input type="radio" name="zone" value="0" checked>Site <input type="radio" name="zone" value="1">H&eacute;bergement</p>' .
							'</td>' .
						'</tr>' ;
	
	if( $session_infos['NiveauAutorisation'] > 1 )
	{
		$tmp = select_sql( "CouleurAccreditation" , "1" , "*" , "ORDER BY Nom" );
		
		$texte .=		'<tr>' .
							'<td>' .
								'<p><strong>Niveau d\'accr&eacute;ditation :</strong></p>' .
								'<p><select name="na">' ;
									
		for( $i = 0 ; $i < $tmp['nbr'] ; $i++ )
		{
			$texte.= '<option value="'.$tmp[$i]['IDCouleurAccreditation'].'">'.$tmp[$i]['Nom'].'</option>' ;
		}
		
		$texte.=					'</select></p>' .
							'</td>' .
						'</tr>' ;
	}
						
		$texte .=	'<tr>' .
							'<td>' .
								html_button( "Valider" , "suivant.png" , "Cliquez ici pour passer &agrave; l'&eacute;tape suivante (5/5)." ) .
							'</td>' .
						'</tr>' .
				'</table></form></blockquote>' ;
	}
	else
	{
		$bdp .= "<h3>Informations administratives</h3>" .
					"<p>Les informations suivantes sont essentiellement relatives &agrave; la logistique du Mondial.</p>" .
					"<blockquote>" .
						"<p><strong>Recommandable :</strong> ".html_yesno($_SESSION['InsertB'][4]['recommandable'])."</p>" .
						"<p><strong>Volume horaire estim&eacute; :</strong> ".vide($_SESSION['InsertB'][4]['horaire'])."</p>" .
						"<p><strong>Zone de travail :</strong> " ;
						
		if( $_SESSION['InsertB'][4]['zone'] )
		{
			$bdp .= "site" ;
		}
		else $bdp .= "centre d'h&eacute;bergement" ;
		
		$bdp .=			"</p>" .
						"<p><strong>Niveau d'accr&eacute;ditation :</strong> " .vide($_SESSION['InsertB'][4]['na_l'])."</p>" .
					"</blockquote>" ;
	}
}

// Etape 5 : touche finale / validation

if( $_SESSION['InsertB']['Step'] > 4 )
{
	if( !isset( $_SESSION['InsertB'][5] ) )
	{
		$texte .= '<a name="CC"></a>' .
				"<h2>[5/5] : Finalisation</h2>" .
					"<p>Remplissez les derniers champs ci-dessous pour finaliser l'inscription.</p>" .
					'<blockquote><form enctype="multipart/form-data" method="post" action="?in=inserer_benevoles&ok=5#CC"><table align="center" cellspacing="10">' .
						'<tr>' .
							'<td>' .
								'<p><strong>Photographie </strong>(conseill&eacute;e)<strong> :</strong></p>' .
								'<p><input type="file" name="photo"></p>' .
								'<font size="-1"><p>Rappel des maximas : '.$misc['img_maxw'].'x'.$misc['img_maxh'].'PX - '.$misc['img_maxs'].'Ko</p>' .
								'<p>Pour plus d\'informations, se r&eacute;f&eacute;rer &agrave; la documentation utilisateur.</p></font>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								'<p><strong>Diffusion de l\'image :</strong></p>' .
								'<p><input type="checkbox" name="statut" checked>Photographie publique (visible de tous)</p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td>' .
								html_button( "Inscrire" , "database.png" , "Cliquez ici pour inscrire le b&eacute;n&eacute;vole." ) .
							'</td>' .
						'<tr>' .
					'</table></form></blockquote>' .
					"<p>Prenez le temps de relire attentivement l'ensemble des informations r&eacute;sum&eacute;es ci-dessous " .
					"avant de valider le formulaire. Le b&eacute;n&eacute;vole sera ensuite inscrit de mani&egrave;re d&eacute;finitive dans la base de donn&eacute;es.</p>" ;
	}
	else
	{
		$texte = '<a name="CC"></a>' .
				"<h2>Inscription compl&egrave;te !</h2>" .
					"<p>Le nouveau b&eacute;n&eacute;vole a &eacute;t&eacute; correctement inscrit dans la " .
					"base de donn&eacute;es. Merci de votre implication dans la pr&eacute;paration du Mondial des Cultures !</p>" ;

		if( $upload_erreur )	$texte .= "<p><strong>Note :</strong> une erreur s'est produite lors de la mise en ligne de la photographie du b&eacute;n&eacute;vole. Merci de retenter ult&eacute;rieurement.</p>" ;
					
		$texte .= 	"<p>".lk('Profil','profil_benevoles',FALSE,'uid='.$id_nb,'profil.png','Cliquez ici pour voir le profil du nouveau b&eacute;n&eacute;vole.')."</p>" ;
				 	
		$_SESSION['InsertB'] = NULL ;
		$_SESSION['InsertB']['Step'] = NULL ;
	}
}

// Retour

								$texte  = $bdp.$texte ;
if( isset( $bdp ) )				$texte .= "<h2>Options</h2>" .
											lk( "R&eacute;initialiser","inserer_benevoles",FALSE,"ok=kill",'corbeille.png','Cliquez ici pour red&eacute;marrer le processus d\'inscription.' ) .
											lk( "Retour &agrave; l'accueil","home",FALSE,'','home.png' ) ;

?>
