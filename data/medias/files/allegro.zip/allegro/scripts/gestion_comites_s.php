<?php

niveau_securite(2) ;

// Renvoi des éléments optionnels 

$texte.= '<a name="CC"></a>' ;

if( !isset( $_GET['mode'] ) || empty( $_GET['mode'] ) )
{
	if( $_GET['ok'] == 0 )
	{
		$texte.= "<h2>Cr&eacute;ation d'un comit&eacute;</h2>" .
					"<p>Faites usage du formulaire ci-dessous si vous souhaiter ajouter un nouveau comit&eacute; au syst&egrave;me.</p>" .
					"<p>Il vous sera ensuite n&eacute;cessaire de cr&eacute;er le compte utilisateur y &eacute;tant associ&eacute;.</p>" ;
		$texte.= '<blockquote><form method="post" action="?in=gestion_comites&ok=1#CC">' .
					'<table cellpading="10">' .
						'<tr>' .
							'<td>' .
								'<p><strong>Nom :</strong></p><p><input value="'.$_POST['nom'].'" type="text" name="nom" size="40" maxlength="64"></p>' .
							'</td>' .
							'<td>' .
								'<p><strong>Code :</strong></p><p><input value="'.$_POST['code'].'" type="text" name="code" size="8" maxlength="4"></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td colspan="2">' .
								'<p><strong>Description :</strong></p><p><textarea name="description" rows="5" cols="80">'.$_POST['description'].'</textarea></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td align="center">' .
								'<p>' .
									html_button( 'Cr&eacute;er' , 'ajout.png' , 'Cliquez ici pour cr&eacute;er le nouveau comit&eacute;.' ) .
								'</p>' .
							'</td>' .
							'<td>' .
							'</td>' .
						'</tr>' .
					'</table></form></blockquote>' ;
	}
	if( $_GET['ok'] == 1 )
	{	
		$_SESSION['Memory'] = NULL ;
		
		if( empty( $_POST['code'] ) || strlen( $_POST['code'] ) > 4 )									e_erreur(10) ;
		if( validation_sql( "Comite" , "Code" , $_POST['code'] ) )										e_erreur(11) ;
		if( empty( $_POST['nom'] ) || validation_sql( "Comite" , "Nom" , "'".$_POST['nom']."'" ) )		e_erreur(12) ;
		if( empty( $_POST['description'] ) || strlen( $_POST['description'] ) > 2058 )					e_erreur(13) ;
		
		if( is_e() )
		{
			e_erreur(14) ;
		}
		else
		{
			$_SESSION['Memory'] = $_POST ;
			
			// Recherche des bénévoles élisibles au poste de responsable
			
			$query = "SELECT distinct B.Nom,B.Prenom,B.IDBenevole,B.Mail
						FROM Benevole B,Web W
						WHERE 1
						AND 
							( NOT EXISTS 
								( SELECT  W.IDBenevole 
									FROM  Web W
									WHERE B.IDBenevole=W.IDBenevole
								)
							)
						ORDER BY B.Nom, B.Prenom" ;
			
			$cid = connection_sql() ;
			
			if( !$res = mysql_query( $query ) )
			{
				f_erreur( 23 , 'gestion_comites.php' , 4 , 'Erreur SQL in ['.$query.']' ) ;
			}
			
			deconnection_sql( $cid ) ;
			
			// Retour du formulaire
			
			$texte	.=	"<h2>Informations saisies</h2>" .
						"<p>Les informations saisies pour le nouveau comit&eacute; sont les suivantes :</p>" .
						"<blockquote>" .
							"<p><strong>Code :</strong> ".$_SESSION['Memory']['code']."</p>" .
							"<p><strong>Nom :</strong> ".$_SESSION['Memory']['nom']."</p>" .
							"<p><strong>Description :</strong> ".$_SESSION['Memory']['description']."</p>".
						"</blockquote>" .
						"<p>Il est &agrave; pr&eacute;sent n&eacute;cessaire de cr&eacute;er le compte utilisateur " .
						"(responsable) li&eacute; au comit&eacute;.</p>".
						"<h2>Cr&eacute;ation du compte responsable</h2>" .
							"<p>Remplissez les champs ci-dessous pour cr&eacute;er le compte du responsable pour " .
							"le nouveau comit&eacute;. Un mail sera exp&eacute;di&eacute; &agrave; l'adresse sp&eacute;cifi&eacute;e " .
							"avec les informations n&eacute;cessaires &agrave; la connexion au compte.</p>" .
						'<blockquote><form method="post" action="?in=gestion_comites&ok=2">' .
						'<table cellpading="10" width="100%">' .
						'<tr><td>' .
							'<p><strong>Nom :</strong></p><p><input type="text" maxlength="32" name="cu_nom" value="'.$_POST['cu_nom'].'"></p>' .
						'</td><td>' .
							'<p><strong>Pr&eacute;nom :</strong></p><p><input maxlength="32" type="text" name="cu_prenom" value="'.$_POST['cu_prenom'].'"></p>' .
						'</td></tr>' .
						'<tr><td>' .
							'<p><strong>Adresse de messagerie :</strong></p><p><input maxlength="64" type="text" name="cu_mail" value="'.$_POST['cu_mail'].'"></p>' .
						'</td><td>' .
							'<p><strong>Fiche b&eacute;n&eacute;vole associ&eacute;e :</strong></p>' .
							'<p><select name="cu_benevole">' ;
							
			for( $i = 0 ; $tmp = mysql_fetch_array( $res , MYSQL_BOTH ) ; $i++ )
			{
				$texte.= '<option value="'.$tmp[2].'">'.$tmp[0].' '.$tmp[1].' ('.vide($tmp[3]).')</option>' ;
			}
			
			$texte.=		'</select></p>' .
						'</td></tr>' .
						'<tr><td align="center">' .
							'<p>' .
							html_button( 'Valider' , 'valider.png' , 'Cliquez ici pour finaliser la cr&eacute;ation du comit&eacute;.' ).
							'</p>' .
						'</td><td></td></tr>' .
						'</table></form></blockquote>' .
					"<p><strong>Attention : </strong>les valeurs entr&eacute;es dans ce formulaire sont d&eacute;finitives !</p>" .
					"<p><strong>Note : </strong>si aucune valeur n'est pr&eacute;cis&eacute; pour le nom, le pr&eacute;nom ou l'adresse mail, " .
					"les informations contenues dans la fiche b&eacute;n&eacute;vole li&eacute;e seront utilis&eacute;es.</p>" ;
		}
	}
	if( $_GET['ok'] == 2 )
	{	
		// Sélection des information fiche
		
		$fiche_b = select_sql( "Benevole" , "IDBenevole = ".$_POST['cu_benevole'] ) ;
		
		// Validation
		
		if( $fiche_b['nbr'] != 1 )
		{
			f_erreur( 32 , 'gestion_comites.php' , 1 , "Benevole invalide pour ID=".$_POST['cu_benevole'] ) ;
		}
		
		// Insertion des identifiants
		
		if( empty( $_POST['cu_nom'] ) || empty( $_POST['cu_prenom'] ) )
		{
			$_POST['cu_nom']	= $fiche_b['Nom'] ;
			$_POST['cu_prenom']	= $fiche_b['Prenom'] ;
		}
		if( empty( $_POST['cu_mail'] ) )
		{
			$_POST['cu_mail']	= $fiche_b['Mail'] ;
		}
		
		// Validation des champs
		
		if( empty($_POST['cu_nom']) || empty($_POST['cu_prenom'] ) )				e_erreur(15) ;
		if( !valider_mail( $_POST['cu_mail'] ) )									e_erreur(16) ;

		if( !$contenu['erreur'] )
		{		
			// Création du compte utilisateur
			
			$tmp = creer_compte( 1 , $_POST['cu_nom'] , $_POST['cu_prenom'] , $_POST['cu_mail'] , $_POST['cu_benevole'] ) ;
			
			// Sélection des infos entrées
			
			$nu_infos = select_sql( "Web" , "IDWeb = ".$tmp ) ;
			
			// Création du comité
			
			$on[0] = array( 'IDWeb' , $tmp , FALSE ) ;
			$on[1] = array( 'Code' , $_SESSION['Memory']['code'] , TRUE ) ;
			$on[2] = array( 'Nom' , $_SESSION['Memory']['nom'] , TRUE ) ;
			$on[3] = array( 'Description' , $_SESSION['Memory']['description'] , TRUE ) ;
			
			if( !$tmp = insert_sql( "Comite" , $on ) )
			{
				f_erreur( 24 , "gestion_comites.php" , 4 , "Erreur SQL in [".$tmp."]" ) ;
			}
			
			// Mise à jour du profil bénévole
			
			$on    = NULL ;
			$on[0] = array( "IDComite" , select_max_sql( "Comite" , "IDComite" ) , FALSE ) ;
			$on[1] = array( "Mail" , $_POST['cu_mail'] , TRUE ) ;
			$on[2] = array( "Fonction" , "Responsable de comit".chr(233) , TRUE ) ;
			
			if( !$tmp = update_sql( "Benevole" , $on , "IDBenevole = ".$nu_infos['IDBenevole'] ) )
			{
				f_erreur( 27 , 'gestion_comites.php' , 4 , "Erreur SQL in [".$tmp."]" ) ;
			}
			
			// Journalisation
			
			journal( "Creation du comite : IDComite[".select_max_sql( "Comite" , "IDComite" )."]-IDWeb[".select_max_sql( "Web" , "IDWeb" )."]-IDBenevole[".$_POST['cu_benevole']."]" ) ;
			
			// Retour
			
			$texte.= "<h2>Op&eacute;ration r&eacute;ussie</h2>" .
						"<p>Le nouveau comit&eacute; a correctement &eacute;t&eacute; cr&eacute;&eacute; sous les " .
						"identifiants suivants :</p>" .
						"<blockquote>" .
							"<p><strong>Nom :</strong> ".$_SESSION['Memory']['nom']."</p>" .
							"<p><strong>Code :</strong> ".$_SESSION['Memory']['code']."</p>" .
							"<p><strong>Description :</strong> ".$_SESSION['Memory']['description']."</p>" .
						"</blockquote>" .
						"<p>Le compte du responsable a &eacute;galement &eacute;t&eacute; correctement ins&eacute;r&eacute; " .
						"dans la base :</p>" .
						"<blockquote>" .
							"<p><strong>Pseudonyme :</strong> ".$nu_infos[0]['Login']."</p>" .
							"<p><strong>Adresse mail :</strong> ".$nu_infos[0]['Mail']."</p>" .
							"<p><strong>Compte b&eacute;n&eacute;vole li&eacute; :</strong> cliquez ".lk('ici','profil_benevoles',TRUE,'uid='.$nu_infos['IDBenevole']) ."</p>" .
						"</blockquote>" .
						"<p>Un mail contenant pseudonyme et mot de passe a &eacute;t&eacute; exp&eacute;di&eacute; &agrave; l'adresse indiqu&eacute;e.</p>" ;
		}
	}
}
elseif( $_GET['mode'] == 'modifier' )
{
	if( $_GET['ok'] == 0 )
	{
		$selection = select_sql( "Comite" , "IDComite = ".$_GET['cid'] ) ;
		
		if( $selection['nbr'] != 1 )
		{
			f_erreur( 25 , "gestion_comites.php" , 2 , 'Selection invalide pour $cid='.$_GET['cid'] );
		}
		
		$texte.= "<h2>Modification du comit&eacute;</h2>" .
					"<p>Faites usage du formulaire ci-dessous pour modifier les propri&eacute;t&eacute;s " .
					"du comit&eacute; actuellement s&eacute;lectionn&eacute;.</p>" .
					'<blockquote><form method="post" action="?in=gestion_comites&mode=modifier&ok=1&select_c='.$_GET['select_c'].'&cid='.$_GET['cid'].'#CC">' .
					'<table cellpading="10">' .
						'<tr>' .
							'<td>' .
								'<p><strong>Nom :</strong></p><p><input value="'.$selection[0]['Nom'].'" type="text" name="nom" size="40" maxlength="64"></p>' .	
							'</td>' .
							'<td>' .
								'<p><strong>Code :</strong></p><p><input value="'.$selection[0]['Code'].'" type="text" name="code" size="8" maxlength="4"></p>' .
							'</td>' .
						'</tr>' .
						'<tr>' .
							'<td colspan="2">' .
								'<p><strong>Description :</strong></p><p><textarea name="description" rows="5" cols="80">'.$selection['Description'].'</textarea></p>' .
							'</td>' .
						'</tr>' .
						'<tr><td align="center">' .
							'<p>' .
								html_button( 'Modifier' , 'editer.png' , 'Cliquez ici pour enregistrer les modifications.' ) .
							'</p>' .
						'</td><td></td></tr>' .
					'</table></form></blockquote>' ;
	}
	elseif( $_GET['ok'] == 1 )
	{
		$validation = select_sql( "Comite" , "IDComite =".$_GET['cid'] ) ;
		
		if( $validation['nbr'] != 1 )
		{
			f_erreur( 25 , 'gestion_comites.php' , 2 , 'Selection invalide pour $cid='.$_GET['cid'] ) ;
		}
		
		if( empty( $_POST['code'] ) || strlen( $_POST['code'] ) > 4 )							
		{
			e_erreur(10) ;
		}
		if( !validation_sql( "Comite" , "Code" , $_POST['code'] ) && $_POST['code'] != $validation[0]['Code'] )								
		{
			e_erreur(11) ;
		}
		if( empty( $_POST['nom'] ) || ( !validation_sql( "Comite" , "Nom" , $_POST['nom'] ) && $_POST['nom'] != $validation[0]['Nom'] ) )		
		{
			e_erreur(12) ;
		}
		if( empty( $_POST['description'] ) || strlen( $_POST['description'] ) > 2058 )			e_erreur(13) ;
		
		if( $contenu['erreur'] )
		{
			e_erreur(14) ;
		}
		else
		{
			$on[0] = array( 'Code' , $_POST['code'] , TRUE ) ;
			$on[1] = array( 'Description' , $_POST['description'] , TRUE ) ;
			$on[2] = array( 'Nom' , $_POST['nom'] , TRUE ) ;
			
			update_sql( "Comite" , $on , "IDComite = ".$_GET['cid'] , "LIMIT 1" ) ;
			
			journal("Edition du comite : IDComite[".$_GET['cid']."]" ) ;
			
			$texte .= "<h2>Mise &agrave; jour r&eacute;ussie</h2>" .
						"<p>Le comit&eacute; a &eacute;t&eacute; correctement mis &agrave; jour.</p>" .
						"<p>Les nouvelles propri&eacute;t&eacute;s sont les suivantes :</p>" .
							"<blockquote>" .
								"<p><strong>Nom :</strong> ".$_POST['nom']."</p>" .
								"<p><strong>Code :</strong> ".$_POST['code']."</p>" .
								"<p><strong>Description :</strong> ".$_POST['description']."</p>" .
							"</blockquote>" ;
		}
	}
}
elseif( $_GET['mode'] == 'supprimer' )
{
	$infos_c  = select_sql( "Comite" , "IDComite =".$_GET['cid'] ) ;
	$infos_cr = select_sql( "Web" , "IDWeb = ".$infos_c['IDWeb'] ) ;
	$infos_r  = select_sql( "Benevole" , "IDBenevole = ".$infos_cr['IDBenevole'] ) ;
		
	if( $infos_c['nbr'] != 1 )
	{
		f_erreur( 25 , 'gestion_comites.php' , 2 , 'Selection invalide pour $cid='.$_GET['cid'] ) ;
	}
		
	if( $_GET['ok'] == 0 )
	{
		$texte .= "<h2>Supprimer un comit&eacute;</h2>" .
					"<p>Vous avez demand&eacute; la suppression du comit&eacute; suivant :</p>" .
					"<blockquote>" .
						"<p><strong>Code :</strong> ".$infos_c['Code']."</p>" .
						"<p><strong>Nom :</strong> ".$infos_c['Nom']."</p>" .
						"<p><strong>Description :</strong> ".$infos_c['Description']."</p>" .
					"</blockquote>" .
					"<p>Ce comit&eacute; est actuellement dirig&eacute; par " .
					lk( $infos_r['Prenom']." ".$infos_r['Nom'] , "profil_benevoles" , TRUE , "uid=".$infos_r['IDBenevole'] ) . ".</p>" .
					"<p>Le compte utilisateur lui ayant &eacute;t&eacute; attribu&eacute; sera effac&eacute; " .
					"en m&ecirc;me temps que le comit&eacute; ; " .
					"les b&eacute;n&eacute;voles inscrits au comit&eacute; seront d&eacute;finis comme " .
					"disponibles.</p>" .
					"<p>Confirmez-vous la suppression du comit&eacute; ?</p>" .
					"<blockquote>" .
						lk( "Supprimer" , "gestion_comites" , FALSE , "mode=supprimer&ok=1&cid=".$_GET['cid'] , 'valider.png' , "Cliquez ici pour confirmer la suppression du comit&eacute; s&eacute;lectionn&eacute;." ) .
						lk( "Annuler" , "gestion_comites" , FALSE , "mode=&ok=0" , 'annuler.png' ) .
					"</blockquote>" ;
	}
	if( $_GET['ok'] == 1 )
	{
		journal( "Suppression du comite : IDComite[".$_GET['cid']."]-IDWeb[".$infos_cr['IDWeb']."]" );
		
		delete_sql( "Web" , "IDWeb = ".$infos_cr['IDWeb'] ) ;
		delete_sql( "Comite" , "IDComite = ".$_GET['cid'] ) ;
		delete_sql( "CouponRepas" , "IDWeb = ".$infos_cr['IDWeb'] , 5000 ) ;
		
		$on[0] = array( "IDComite" , 0 , FALSE ) ;
		$on[1] = array( "Fonction" , "B".chr(233)."n".chr(233)."vole" , TRUE ) ;
		update_sql( "Benevole" , $on , "IDComite = ".$_GET['cid'] ) ;
		
		$on[0] = array( "IDComiteSecondaire" , 0 , FALSE ) ;
		$on[1] = array( "Fonction" , "B".chr(233)."n".chr(233)."vole" , TRUE ) ;
		update_sql( "Benevole" , $on , "IDComiteSecondaire = ".$_GET['cid'] ) ;
		
		$texte .= "<h2>Suppression effectu&eacute;e</h2>" .
					"<p>Le comit&eacute; a &eacute;t&eacute; correctement effac&eacute; de la base de donn&eacute;es.</p>" ;
	}
}
elseif( $_GET['mode'] == 'voir' )
{
	$texte .= "<h2>Visualisation</h2>" .
				"<p>La liste suivante rassemble l'ensemble des membres du comit&eacute; actuellement s&eacute;lectionn&eacute;.</p>" .
				"<blockquote>" .
				'<table cellspacing="1" cellpading="5" width="80%" align="center" bgcolor="#999999">' .
					'<tr valign="center" height="35">' .
						'<td align="center"><font size="+1" color="#CCCCCC"><strong>Nom</strong></font></td>' .
						'<td align="center"><font size="+1" color="#CCCCCC"><strong>Pr&eacute;nom</strong></font></td>' .
						'<td align="center"><font size="+1" color="#CCCCCC"><strong>Informations</strong></font></td>' .
						'<td align="center"><font size="+1" color="#CCCCCC"><strong>Liens</strong></font></td>' .
					'</tr>' ;
	if( $_GET['cid'] == 0 )
	{
		$see = select_sql( "Benevole" , "IDComite = ".$_GET['cid'] ) ;
	}
	else
	{
		$see = select_sql( "Benevole" , "IDComite = ".$_GET['cid']." || IDComiteSecondaire = ".$_GET['cid'] ) ;
	}
	
	for( $i = 0 ; $i < $see['nbr'] ; $i++ )
	{
		$tmp = benevole_infos( $see[$i]['IDBenevole'] ) ;
		
		$texte .= 	'<tr valign="center">' .
						'<td align="center" bgcolor="#CCCCCC">' . $tmp['Nom'] . '</td>' .
						'<td align="center" bgcolor="#CCCCCC">' . $tmp['Prenom'] . '</td>' .
						'<td align="center" bgcolor="#CCCCCC">' . $tmp['GInfos'] . '</td>' .
						'<td align="center" bgcolor="#CCCCCC"><font size="-1">' . lk( 'Profil' , 'profil_benevoles' , FALSE , 'bid='.$tmp['IDBenevole'] ) . '<br>'.lk('G&eacute;rer','modifier_benevole',FALSE,'action=activite&bid='.$tmp['IDBenevole'].'#CC').'</font></td>' .
					'</tr>' ;
	}
	
	$texte .= '</table></blockquote>' ;
}

// Renvoi primaire

$titre	.=	"Liste des comit&eacute;s" ;

// Sélection de la liste des comités

$liste	 =	select_sql('Web W,Comite C','C.IDWeb = W.IDWeb','C.Code,C.Nom,C.Description,W.Nom,W.Prenom,W.IDWeb,C.IDComite','ORDER BY C.Code' );

// Préparation du tableau

$infos['titre'][0]	=	'Code' ;					$infos['taille'][0]	=	50 ;
$infos['titre'][1]	=	'Noms' ;					$infos['taille'][1]	=	200 ;
$infos['titre'][2]	=	'Descriptif' ;				$infos['taille'][2]	=	NULL ;
$infos['titre'][3]	=	'Responsable' ;				$infos['taille'][3]	=	100 ;
$infos['titre'][4]	=	NULL ;						$infos['taille'][4]	=	100 ;

for( $i = 0 ; $i < $liste['nbr'] ; $i++ )
{
	$contenu[$i][0]		=	$liste[$i][0] ;
	$contenu[$i][1]		=	$liste[$i][1] ;
	$contenu[$i][2]		=	$liste[$i][2] ;
	$contenu[$i][3]		=	'<font size="-1">'.lk( $liste[$i][3].' '.$liste[$i][4] , 'profil_benevoles' , TRUE , 'wid='.$liste[$i][5] ).'</font>' ;
	
	if( $liste[$i][6] != 0 )
	{
		$contenu[$i][4]	=	'<font size="-1">'.lk("Modifier","gestion_comites",FALSE, "mode=modifier&ok=0&select_c=".$i."&cid=".$liste[$i][6]."#CC" ).
		'<br>'.lk("Voir","gestion_comites",FALSE,"mode=voir&select_c=".$i."&cid=".$liste[$i][6]."#CC" ) . 
		'<br>'.lk("Supprimer","gestion_comites",FALSE, "mode=supprimer&ok=0&select_c=".$i."&cid=".$liste[$i][6]."#CC" ).'</font>' ;
	}
	else
	{
		$contenu[$i][4]	=	'<font size="-1">'.lk("Voir","gestion_comites",FALSE,"mode=voir&select_c=".$i."&cid=".$liste[$i][6]."#CC").'</font>' ;
	}
}

// Renvoi du tableau

$texte = "<h2>Liste brute</h2>" .
				"<p>Ce tableau rassemble la liste des comit&eacute; enregistr&eacute;s au sein du syst&egrave;me.</p>" . 
				liste( $contenu , $infos , 5 , 40  ) . $texte ;

?>
