<?php

/*	----------------------------------------------------------------
 * 	login.php
 * 	----------------------------------------------------------------
 * 	[Description]
 * 		Fichier de restauration d'un mot de passe perdu.
 *	----------------------------------------------------------------	*/

$formulaire = '<form method="post" action=""><blockquote>
	<p><strong>Votre pseudonyme :</strong></p><p><input type="text" name="login" size="25"></p>
	<p><strong>Votre adresse mail :</strong></p><p><input type="text" name="mail" size="25"></p>
	<p><br>' . html_button( 'Restaurer' , 'options.png' , "Cliquez ici pour lancer le processus de restauration de vos identifiants." ) .
			'</p></blockquote>
	</form>' ;
$titre = "Restauration" ;

if( isset( $_POST['mail'] ) || isset( $_POST['login']) )
{
	$mdp_rec = select_sql( "Web" , "Mail='".$_POST['mail']."' && Login='".$_POST['login']."'" ) ;
	journal("Login[".$_POST['login']."]-Mail[".$_POST['mail']."]") ;
	
	if( $mdp_rec['nbr'] != 1 )
	{
		e_erreur(3) ;
	}
	else
	{	
		$link		= "http://".$global['url']."?in=perdu_mdp&rid=".$mdp_rec[0]['IDWeb']."&rp=".$mdp_rec[0]['MDPEncode'] ;
		$message_r 	= "Bonjour\n\n" .
				"Quelqu'un, probablement vous, a demandé la restauration du mot de passe associé au compte suivant :\n\n" .
				"\t" . $mdp_rec['Nom'] . "\n" .
				"\t" . $mdp_rec['Prenom'] . "\n" .
				"\t" . $mdp_rec['Mail'] . "\n\n" .
				"Si vous n'êtes pas la personne indiquée ci-dessus, merci de bien vouloir transmettre ou supprimer ce message.\n" .
				"Si vous êtes bien à l'origine de ce message, vous pouvez restaurer vos identifiants en suivant ou copiant le lien ci-dessous dans votre navigateur :\n\n" .
				$link ;
		
		envoi_mail( $mdp_rec['Mail'] , "Restauration de vos identifiants" , $message_r , TRUE ) ;
		
		$texte = "<h2>Requ&ecirc;te accept&eacute;e</h2>" .
		"<p>Un courriel a &eacute;t&eacute; exp&eacute;di&eacute; &agrave; l'adresse stipul&eacute;e. " .
		"Vous y trouverez la suite des instructions permettant la restauration de votre mot de passe.</p>" ;
	}
}
elseif( !isset( $_GET["rid"]) )
{
	$texte = "<h2>Formulaire de restauration</h2>" .
				"<p>Ce formulaire vous permet de restaurer votre mot de passe &agrave; une valeur par d&eacute;faut. " .
				"Il vous est n&eacute;cessaire d'entrer l'adresse mail ayant servi lors de la cr&eacute;ation de votre " .
				"compte (ou y &eacute;tant associ&eacute;e) ainsi que votre pseudonyme. Un mail vous sera ensuite " .
				"exp&eacute;di&eacute; avec la suite des instructions.</p>" . $formulaire .
				"<h2>En cas d'&eacute;chec ...</h2>" .
				"<p>Si vous ne parvenez pas &agrave; vous rem&eacute;morer votre pseudonyme ou votre adresse courriel, " .
				"contactez l'administration du site en cliquant " . lk( 'ici' , 'g_contact' ) .".</p>" ;
}
else
{
	$np		= restaurer( $_GET['rid'] , $_GET['rp'] ) ;
	$uinfos = select_sql( 'Web' , 'IDWeb='.$_GET['rid'] , '*' , 'LIMIT 1' ) ;
	
	$texte 	= "<h2>Restitution du mot de passe</h2>" .
					"<p>Votre compte a &eacute;t&eacute; correctement restaur&eacute;.</p>" .
					"<p>Les nouveaux identifiants du compte sont les suivants :</p>" .
					"<blockquote>" .
						"<p><strong>Login :</strong> " . $uinfos[0]['Login'] . "</p>" .
						"<p><strong>Mot de passe :</strong> " . $np . "</p>" .
						"<p><strong>Propri&eacute;taire :</strong> " . $uinfos[0]['Nom'] . " " . $uinfos[0]['Prenom'] . " (" . $uinfos[0]['Mail'] . ")</p>" .
					"</blockquote>" .
					"<p>Vous pouvez modifier votre mot de passe dans les options du compte.</p>" .
				"<h2>Note</h2>" .
					"<p>La restauration du mot de passe est une op&eacute;ration qui doit rester aussi rare que possible. " .
					"Merci de bien vouloir noter vos nouveaux identifiants sur un support externe afin " .
					"d'en &eacute;viter une perte ult&eacute;rieure.</p>" .
				"<h2>Options</h2>" .
					lk( 'Connexion' , 'login' , FALSE , '' , 'connexion.png' , 'Cliquez ici pour vous connecter au syst&egrave;me.' ) .
					lk( 'Retour &agrave; l\'accueil' , 'home' , FALSE , '' , 'home.png' ) ;
				
	$help	= "<p>Attention &agrave; bien noter majuscules et minuscules du nouveau mot de passe. " .
			"Elles seront &agrave; prendre en compte lors de votre prochaine connection.</p>" ;
}

?>
