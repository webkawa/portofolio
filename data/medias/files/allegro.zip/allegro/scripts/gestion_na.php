<?php

niveau_securite(2) ;

// Traitement des actions

$bdp = '<a name="CC"></a>' ; 

if( !isset( $_GET['mode'] ) || $_GET['mode'] == 'creer' )
{
	if( $_GET['ok'] != 1 )
	{
		$bdp .= "<h2>Cr&eacute;ation d'un niveau</h2>" .
					"<p>Le formulaire ci-dessous vous permet d'ins&eacute;rer un nouveau niveau d'accr&eacute;ditation.</p>" .
					'<blockquote><form method="post" action="?in=gestion_na&ok=1#CC">' .
						'<table cellspacing="10">' .
							'<tr>' .
								'<td><p><strong>Nom :</strong></p>' .
								'<p><input type="text" name="nom"></p></td>' .
								'<td><p><strong>Code couleur </strong>(<a target="_blank" href="'.$folder['palette'].'">palette</a>)<strong> :</strong></p>' .
								'<p><strong>#</strong> <input type="text" maxlength="6"  size="10" name="couleur"></p></td>' .
								'<td></td>' .
							'</tr><tr>' .
								'<td colspan="2"><p><strong>Description :</strong></p>' .
								'<p><textarea rows="5" cols="60" name="description"></textarea></p></td>' .
							'</tr><tr>' .
								'<td><input type="submit" value="Cr&eacute;er"></td>' .
								'<td></td>' .
						'</table>' .
					'</form></blockquote>' ;
	}
	else
	{
		if( empty( $_POST['nom'] ) || empty( $_POST['couleur'] ) || empty( $_POST['description'] ) )		e_erreur(4) ;
		if( strlen( $_POST['couleur'] ) != 6 )																e_erreur(31) ;
		
		if( !$contenu['erreur'] )
		{
			$on[0] = array( 'Nom' , $_POST['nom'] , TRUE ) ;
			$on[1] = array( 'CodeCouleur' , $_POST['couleur'] , TRUE ) ;
			$on[2] = array( 'Description' , $_POST['description'] , TRUE ) ;
			
			insert_sql( "CouleurAccreditation" , $on ) ;
			journal( "Creation du NA : IDCouleurAccreditation[".select_max_sql("CouleurAccreditation","IDCouleurAccreditation")."]") ;
			
			$bdp .= "<h2>Insertion r&eacute;ussie</h2>" .
						"<p>Le nouveau niveau d'accr&eacute;ditation a &eacute;t&eacute; correctement cr&eacute;&eacute;.</p>" ;
		}	
	}
}
if( $_GET['mode'] == 'modifier' )
{
	$sna = select_sql( "CouleurAccreditation" , "IDCouleurAccreditation = ".$_GET['ccid'] ) ;

	if( $sna['nbr'] != 1 )
	{
		f_erreur( 25 , "gestion_na.php" , 2 , 'Selection invalide pour $ccid='.$_GET['ccid'] );
	}						
	
	if( $_GET['ok'] != 1 )
	{
		$bdp .= "<h2>Modification d'un niveau</h2>" .
					"<p>Le formulaire ci-dessous vous permet de modifier le niveau d'accr&eacute;ditation actuellement s&eacute;lectionn&eacute;.</p>" .
					'<blockquote><form method="post" action="?in=gestion_na&ok=1&mode=modifier&ccid='.$_GET['ccid'].'&select_c='.$_GET['select_c'].'#CC">' .
						'<table cellspacing="10">' .
							'<tr>' .
								'<td><p><strong>Nom :</strong></p>' .
								'<p><input type="text" name="nom" value="'.$sna['Nom'].'"></p></td>' .
								'<td><p><strong>Code couleur </strong>(<a target="_blank" href="'.$folder['palette'].'">palette</a>)<strong> :</strong></p>' .
								'<p><strong>#</strong> <input value="'.$sna['CodeCouleur'].'" type="text" maxlength="6"  size="10" name="couleur"></p></td>' .
								'<td></td>' .
							'</tr><tr>' .
								'<td colspan="2"><p><strong>Description :</strong></p>' .
								'<p><textarea rows="5" cols="60" name="description">'.$sna['Description'].'</textarea></p></td>' .
							'</tr><tr>' .
								'<td><input type="submit" value="Modifier"></td>' .
								'<td></td>' .
						'</table>' .
					'</form></blockquote>' ;
	}
	else
	{
		if( empty( $_POST['nom'] ) || empty( $_POST['couleur'] ) || empty( $_POST['description'] ) )		e_erreur(4) ;
		if( strlen( $_POST['couleur'] ) != 6 )																e_erreur(31) ;
		
		if( !$contenu['erreur'] )
		{
			$on[0] = array( 'Nom' , $_POST['nom'] , TRUE ) ;
			$on[1] = array( 'CodeCouleur' , $_POST['couleur'] , TRUE ) ;
			$on[2] = array( 'Description' , $_POST['description'] , TRUE ) ;
			
			update_sql( "CouleurAccreditation" , $on , "IDCouleurAccreditation = ".$_GET['ccid'] ) ;
			journal( "Modification du NA : IDCouleurAccreditation[".$_GET['ccid']."]") ;
			
			$bdp .= "<h2>Modification r&eacute;ussie</h2>" .
						"<p>Le nouveau niveau d'accr&eacute;ditation a &eacute;t&eacute; correctement modifi&eacute;.</p>" ;
		}	
	}
}
if( $_GET['mode'] == 'gerer' )
{
	$sna 		= select_sql( "CouleurAccreditation" , "IDCouleurAccreditation = ".$_GET['ccid'] ) ;
	$comite 	= select_sql( "Comite" , "1" , "*" , "ORDER BY Nom" );
	$fonction	= select_sql( "Benevole" , "1" , "DISTINCT Fonction" , "ORDER BY Fonction" );

	if( $sna['nbr'] != 1 )
	{
		f_erreur( 25 , "gestion_na.php" , 2 , 'Selection invalide pour $ccid='.$_GET['ccid'] );
	}		
	
	if( $_GET['ok'] != 1 )
	{
		
		
		$bdp .= "<h2>Application du niveau d'accr&eacute;ditation</h2>" .
					"<h3>Formulaire</h3>" .
					"<p>Faites usage du formulaire ci-dessous pour appliquer le niveau d'accr&eacute;ditation " .
					"actuellement s&eacute;lectionn&eacute; &agrave; un certain type de personnes.</p>" .
					'<blockquote><form method="post" action="?in=gestion_na&select_c='.$_GET['select_c'].'&mode=gerer&ok=1&ccid='.$_GET['ccid'].'">' .
						'<table cellspacing="10">' .
							'<tr>' .
								'<td><p><strong>Filtre 1 :</p>' .
								'<p><select name="filtre_1">' ;
								
				for( $i = 0 ; $i < $comite['nbr'] ; $i++ )
				{
					$bdp .= '<option value="c_'.$comite[$i]['IDComite'].'">[Comit&eacute;] '.$comite[$i]['Nom'].'</option>' ;
				}
				
				for( $i = 0 ; $i < $fonction['nbr'] ; $i++ )
				{
					$bdp .= '<option value="f_'.$fonction[$i]['Fonction'].'">[Fonction] '.$fonction[$i]['Fonction'].'</option>' ;
				}
				
				$bdp .= '<option value="blacklist">[Sp&eacute;cial] Membres de la liste noire</option>' .
						'<option value="mineurs">[Sp&eacute;cial] B&eacute;n&eacute;voles mineurs</option>' .
						'<option value="majeurs">[Sp&eacute;cial] B&eacute;n&eacute;voles majeurs</option>' .
						'<option value="mr">[Sp&eacute;cial] B&eacute;n&eacute;voles du centre d\'h&eacute;bergement</option>' .
						'<option value="site">[Sp&eacute;cial] B&eacute;n&eacute;voles du site</option>' ;
				
								$bdp .= '</select></p></td>' .
									'<td><p><strong>Association :</strong></p>' .
									'<p><select name="association">' .
										'<option value="et">Et</option>' .
										'<option value="ou">Ou</option>' .
									'</select></p></td>' .
								'</tr>' .
								'<tr>' .
									'<td><p><strong>Filtre 2 :</p>' .
								'<p><select name="filtre_2">' ;
								
				for( $i = 0 ; $i < $comite['nbr'] ; $i++ )
				{
					$bdp .= '<option value="c_'.$comite[$i]['IDComite'].'">[Comit&eacute;] '.$comite[$i]['Nom'].'</option>' ;
				}
				
				for( $i = 0 ; $i < $fonction['nbr'] ; $i++ )
				{
					$bdp .= '<option value="f_'.$fonction[$i]['Fonction'].'">[Fonction] '.$fonction[$i]['Fonction'].'</option>' ;
				}
				
				$bdp .= '<option value="blacklist">[Sp&eacute;cial] Membres de la liste noire</option>' .
						'<option value="mineurs">[Sp&eacute;cial] B&eacute;n&eacute;voles mineurs</option>' .
						'<option value="majeurs">[Sp&eacute;cial] B&eacute;n&eacute;voles majeurs</option>' .
						'<option value="mr">[Sp&eacute;cial] B&eacute;n&eacute;voles du centre d\'h&eacute;bergement</option>' .
						'<option value="site">[Sp&eacute;cial] B&eacute;n&eacute;voles du site</option>' ;
				
								$bdp .= '</select></p></td>' .
									'<td><p><strong>Option :</strong></p>' .
									'<p><input type="checkbox" name="ignorer"> Ignorer le filtre 2</input></p></td>' .
								'</tr>' .
								'<tr>' .
									'<td><input type="submit" value="Appliquer"></td>' .
							'</tr>' .
						'</table>' .
					'</form></blockquote>' ;
					
		$liste_b = select_sql( "Benevole" , "IDCouleurAccreditation = ".$_GET['ccid'] ) ;
					
		$bdp.= "<h3>Liste des inscrits</h3>" .
					"<p>La liste ci-dessous contient l'ensemble des b&eacute;n&eacute;voles actuellement " .
					"soumis &agrave; ce niveau d'accr&eacute;ditation.</p>" .
						'<blockquote>' ;
						
						for( $i = 0 ; $i < $liste_b['nbr'] ; $i++ )
						{
							$bdp .= "<p>".($i+1).". ".strtoupper($liste_b[$i]['Nom'])." ".$liste_b[$i]['Prenom']." (".lk("profil","profil_benevoles",TRUE,"uid=".$liste_b[$i][0]).")</p>" ;
						}
						if( $liste_b['nbr'] == 0 )
						{
							$bdp .= "<p>Ce niveau d'accr&eacute;ditation n'est appliqu&eacute; &agrave; aucun b&eacute;n&eacute;vole.</p>" ;
						}
						
						"</blockquote>" ;
	}
	else
	{
		function transcrire_filtre( $filtre )
		{
			$prefixe = substr( $filtre , 0 , 2 ) ;
			$suffixe = substr( $filtre , 2 , 64 ) ;
			
			if( $prefixe == 'c_' )
			{
				return "IDComite = '".$suffixe."' || IDComite = '".$suffixe."'" ;
			}
			if( $prefixe == 'f_' )
			{
				return "Fonction = '".$suffixe."'" ;
			}
			if( $filtre == 'blacklist' )
			{
				return '!Recommandable' ;
			}
			if( $filtre == 'mineurs' )
			{
				return "DateNaissance > '".date_sql( TEST_18 )."'" ;
			}
			if( $filtre == 'majeurs' )
			{
				return "DateNaissance < '".date_sql( TEST_18 )."'" ;
			}
			if( $filtre == 'mr' )
			{
				return 'Zone' ;
			}
			if( $filtre == 'site' )
			{
				return '!Zone' ;
			}
		}

		$filtre_1 	= transcrire_filtre( $_POST['filtre_1'] );
		$filtre_2	= transcrire_filtre( $_POST['filtre_2'] );
		
		if( $_POST['association'] == 'et' )
		{
			$association = '&&' ;
		}
		if( $_POST['association'] == 'ou' )
		{
			$association = '||' ;
		}
		
		if( $_GET['ignorer'] )
		{
			$association 	= NULL ;
			$filtre_2		= NULL ;
		}
		
		$where = $filtre_1." ".$association." ".$filtre_2 ;
		
		$on[0] = array( 'IDCouleurAccreditation' , $_GET['ccid'] , FALSE ) ;
		
		$query = update_sql( "Benevole" , $on , $where , "LIMIT 5000" ) ;
		journal( "Modification NA benevole(s) : CMD[".$query."]" );
		
		$bdp .= "<h2>Application r&eacute;ussie</h2>" .
					"<p>Le niveau d'accr&eacute;ditation actuellement s&eacute;lectionn&eacute; a &eacute;t&eacute; " .
					"correctement appliqu&eacute;.</p>" ;
	}
}
if( $_GET['mode'] == 'effacer' )
{
	if( denombrer_sql( "CouleurAccreditation" ) == 1 )
	{
		e_erreur(32) ;
	}
	
	$sna 		= select_sql( "CouleurAccreditation" , "IDCouleurAccreditation = ".$_GET['ccid'] ) ;

	if( $sna['nbr'] != 1 )
	{
		f_erreur( 25 , "gestion_na.php" , 2 , 'Selection invalide pour $ccid='.$_GET['ccid'] );
	}	
	
	if( $_GET['ok'] != 1 )
	{
		$bdp .= "<h2>Suppression du niveau d'accr&eacute;ditation</h2>" .
					"<p>Confirmez vous la suppression du niveau d'accr&eacute;ditation ? Si oui, faites usage " .
					"du formulaire ci-dessous pour indiquer quel niveau doit &ecirc;tre appliqu&eacute; aux " .
					"b&eacute;n&eacute;voles actuellement soumis au niveau s&eacute;lectionn&eacute;.</p>" ;
					
		$bdp .= '<blockquote>' .
					'<form method="post" action="?in=gestion_na&ccid='.$_GET['ccid'].'&ok=1&mode=effacer">' .
						'<table cellspacing="10">' .
							'<tr>' .
								'<td><select name="redirection">' ;
								
			$red = select_sql( "CouleurAccreditation" , "IDCouleurAccreditation != ".$_GET['ccid'] ) ;
			
			for( $i = 0 ; $i < $red['nbr'] ; $i++ )
			{
				$bdp .= '<option value="'.$red[$i][0].'">['.$red[$i]['Nom'].'] '.$red[$i]['Description'].'</option>' ;
			}
			
								$bdp .= '</select></td>' .
										'<td><input type="submit" value="Supprimer"></td>' .
							'</tr>' .
						'</table>' .
					'</form>' .
				'</blockquote>' ;
	}
	else
	{
		$on[0] = array( "IDCouleurAccreditation" , $_POST['redirection'] , FALSE ) ;
		
		update_sql( "Benevole" , $on , "IDCouleurAccreditation = ".$_GET['ccid'] , "LIMIT 5000" ) ;
		delete_sql( "CouleurAccreditation" , "IDCouleurAccreditation = ".$_GET['ccid'] ) ;
		
		journal( "Suppression NA : IDCouleurAccreditation[".$_GET['ccid']."]-Redirection[".$_POST['redirection']."]") ;
		
		$bdp .= "<h2>Suppression effectu&eacute;e</h2>" .
					"<p>Les op&eacute;rations de suppression et de redirection se sont correctement d&eacute;roul&eacute;es.</p>" ;
	}
}

// Affichage de la liste

$na = select_sql( "CouleurAccreditation" , "1" , "*" , "ORDER BY IDCouleurAccreditation" ) ;

$infos['titre'][0]	=	'Nombre' ;								$infos['taille'][0] = 50 ;
$infos['titre'][1]	=	'Nom' ;									$infos['taille'][1]	= 150 ;
$infos['titre'][2]	=	'Couleur' ;								$infos['taille'][2]	= 50 ;
$infos['titre'][3]	=	'Description' ;							$infos['taille'][3]	= NULL ;
$infos['titre'][4]	=	NULL ;									$infos['taille'][4]	= 150 ;

for( $i = 0 ; $i < $na['nbr'] ; $i++ )
{
	$tmp = denombrer_sql( "Benevole" , "IDCouleurAccreditation = ".$na[$i]['IDCouleurAccreditation'] ) ;
	
	$contenu[$i][0]	=	$tmp ;
	$contenu[$i][1] =	$na[$i]['Nom'] ;
	$contenu[$i][2]	=	'<table width="16" height="16" bgcolor="#'.$na[$i]['CodeCouleur'].'" border="1"></table>' ;
	$contenu[$i][3]	=	$na[$i]['Description'] ;
	
	if( $na[$i]['IDCouleurAccreditation'] != 0 )
	{
		$contenu[$i][4]	=	'<font size="-1">'.lk('Modifier','gestion_na',FALSE,'ccid='.$na[$i]['IDCouleurAccreditation'].'&mode=modifier&ok=0&select_c='.$i.'#CC' ).'<br>' .
			lk('G&eacute;rer','gestion_na',FALSE,'ccid='.$na[$i]['IDCouleurAccreditation'].'&mode=gerer&ok=0&select_c='.$i.'#CC' ).'<br>' .
			lk('Supprimer','gestion_na',FALSE,'ccid='.$na[$i]['IDCouleurAccreditation'].'&mode=effacer&ok=0&select_c='.$i.'#CC' ).'</font>' ;
	}
	else
	{
		$contenu[$i][4]	=	'<font size="-1">Prot&eacute;g&eacute;</font>' ;
	}
}

// Retour

$titre = "Niveaux d'accr&eacute;ditation" ;

$texte .= "<h2>Liste brute</h2>" .
			"<p>La liste ci-dessous r&eacute;sume l'ensemble des niveaux d'accr&eacute;ditation d&eacute;finis " .
			"pour l'ann&eacute;e &agrave; venir.</p>" ;
$texte .= liste( $contenu , $infos , 5 , 50 ) ;
$texte .= $bdp ;

?>