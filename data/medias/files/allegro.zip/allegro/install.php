<?php

function ok()
{
	echo '<font color="green"><strong>[ OK ]</strong></font><br>' ;
}
function stop()
{
	die( '<font color="red"><strong>[ ERREUR ]</strong></font></blockquote>' ) ;
}

echo 	'<font face="Courier New">' .
		'<p><strong><font size="+2">' .
			'Allegro 1.0 : INSTALLATION' .
		'</font></strong></p>' ;

if( $_GET['install'] == 'yes' )
{
	echo 
			'<blockquote>' ;
	
	// Message d'intro
	
	echo 'D&eacute;but de l\'installation ...<br>' ;
	
	// Connexion au serveur SQL
	
	echo 'Connexion au serveur SQL ...' ;
	
	if( !mysql_connect( $_POST['sql_serveur'] , $_POST['sql_login'] , $_POST['sql_password'] ) )		stop() ;
	else																								ok() ;
	
	echo 'S&eacute;lection de la base de donn&eacute;es ...' ;
	
	if( !mysql_select_db( $_POST['sql_bdd'] ) )															stop() ;
	else																								ok() ;
	
	// Connexion au serveur FTP
	
	echo 'Connexion au serveur FTP ...' ;
	
	if( !$tmp = ftp_connect( $_POST['ftp_serveur'] ) )													stop() ;
	else																								ok() ;
	
	echo 'Login au serveur FTP ...' ;
	
	if( !ftp_login( $tmp , $_POST['ftp_login'] , $_POST['ftp_password'] ) )								stop() ;
	else																								ok() ;
	
	// Test des fichiers système
	
	$sysfile_test = array( 'fonctions.php' , 'renvoi.php' , 'script.php' , 'session.php' ) ;
	
	echo 'Validation des fichiers syst&egrave;me ...</br>' ;
	
	for( $i = 0 ; isset( $sysfile_test[$i] ) ; $i++ )
	{
		echo '+ Test du fichier ['.$sysfile_test[$i].'] ...' ;
		if( !file_exists( $_POST['folder_systeme'].$sysfile_test[$i] ) )								stop() ;
		else																							ok() ;
	}
	
	// Test des fichiers scripts
	
	$scrfile_test = array( 	'blacklist.php' ,
							'deconnection.php' ,
							'effacer_benevole.php' ,
							'execution.php' ,
							'gestion_administrateurs.php' ,
							'gestion_comites.php' ,
							'gestion_coupons_repas.php' ,
							'gestion_cr.php' ,
							'gestion_gf.php' ,
							'gestion_moderateurs.php' ,
							'gestion_na.php' ,
							'gnu.php' ,
							'home.php' ,
							'id_cr.php' ,
							'impression_lp.php' ,
							'impression_v.php' ,
							'inserer_benevoles.php' ,
							'joindre_benevole.php' ,
							'journal.php' ,
							'journal_systeme.php' ,
							'liste_benevoles.php' ,
							'login.php' ,
							'mail.php' ,
							'modifier_benevole.php' ,
							'mon_comite.php' ,
							'notes.php' ,
							'perdu_mdp.php' ,
							'profil_benevoles.php' ,
							'profil.php' ,
							'rechercher_benevoles.php' ,
							'var_conf.php' ) ;
							
	echo 'Validation des fichiers script ...</br>' ;
	
	for( $i = 0 ; isset( $scrfile_test[$i] ) ; $i++ )
	{
		echo '+ Test du fichier ['.$scrfile_test[$i].'] ...' ;
		if( !file_exists( $_POST['folder_scripts'].$scrfile_test[$i] ) )			stop() ;
		else																		ok() ;
	}	
	
	// Test des valeurs globales
	
	$glb_values = array( $_POST['global_nom'] , $_POST['global_desc'] , $_POST['global_mail'] , $_POST['global_version'] , $_POST['global_update'] , $_POST['global_url'] , $_POST['global_annee'] ) ;
	
	echo 'Validation des valeurs globales ...' ;
	
	for( $i = 0 ; isset( $glb_values[$i] ) ; $i++ )
	{
		if( empty( $glb_values[$i] ) )												stop() ;
	}
																					ok() ;
																					
	// Test des valeurs diverses
	
	echo 'Validation des valeurs diverses ...<br>' ;
	
	echo '+ Nombre de r&eacute;sultats par liste ...' ;
	if( $_POST['misc_cliste'] < 1 || $_POST['misc_cliste'] > 200 )					stop() ;
	else																			ok() ;
	
	echo '+ Responsable informatique ...' ;
	if( empty( $_POST['misc_resp_info'] ) || empty( $_POST['misc_resp_info_num']) )	stop() ;
	else																			ok() ;
	
	echo '+ Mots de passe ...' ;
	if( $_POST['misc_mdp_taille_min'] < 1 || $_POST['misc_mdp_taille_def'] < 1 )	stop() ;
	else																			ok() ;
		
	echo '+ Taille des images ...' ;
	if( $_POST['misc_img_maxw'] < 1 || $_POST['misc_img_maxh'] < 1 )				stop() ;
	else																			ok() ;
	
	echo '+ Poids des images ...' ;
	if( $_POST['misc_img_maxs'] < 1 )												stop() ;
	else																			ok() ;
	
	// Compte ROOT
	
	echo 'Test du compte ROOT ...' ;
	if( empty( $_POST['pseudo'] ) || empty( $_POST['password'] ) )					stop() ;
	else																			ok() ;
	
	echo 'Test du mot de passe ROOT ...' ;
	if( strlen( $_POST['password'] ) < $_POST['misc_mdp_taille_min'] )				stop() ;
	else																			ok() ;
	
	echo 'Test des identifiants ROOT ...' ;	
	if( empty( $_POST['nom'] ) || empty( $_POST['prenom'] ) )						stop() ;
	else																			ok() ;
	
	// BDD
	
	echo 'Cr&eacute;ation des tables ...' ;
	
	echo '+ [Benevole] ...' ;
	
	$query = "CREATE TABLE `Benevole` (
`IDBenevole` INT( 8 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`IDComite` INT( 4 ) NOT NULL ,
`IDComiteSecondaire` INT( 4 ) NOT NULL ,
`IDCouleurAccreditation` INT( 4 ) NOT NULL ,
`Nom` VARCHAR( 32 ) NOT NULL ,
`Prenom` VARCHAR( 32 ) NOT NULL ,
`Sexe` BINARY NOT NULL ,
`DateNaissance` DATE NOT NULL ,
`Adresse` VARCHAR( 128 ) NOT NULL ,
`Ville` VARCHAR( 32 ) NOT NULL ,
`CodePostal` VARCHAR( 6 ) NOT NULL ,
`Province` VARCHAR( 32 ) NOT NULL ,
`TelephoneFixe` VARCHAR( 10 ) NOT NULL ,
`TelephoneCellulaire` VARCHAR( 10 ) NOT NULL ,
`Photo` VARCHAR( 128 ) NOT NULL ,
`Mail` VARCHAR( 64 ) NOT NULL ,
`Statut` BINARY NOT NULL ,
`Imprime` BINARY NOT NULL ,
`Recommandable` BINARY NOT NULL ,
`Heures` INT(2) NOT NULL ,
`Privileges` BINARY NOT NULL ,
`Zone` BINARY NOT NULL ,
`Fonction` VARCHAR( 128 ) NOT NULL
) ENGINE = MYISAM COMMENT = 'Liste des bénévoles';" ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ [Web] ...' ;
	
	$query = " CREATE TABLE `Web` (
`IDWeb` INT( 8 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`IDBenevole` INT( 8 ) NOT NULL ,
`Login` VARCHAR( 40 ) NOT NULL ,
`MDPEncode` VARCHAR( 40 ) NOT NULL ,
`Mail` VARCHAR( 64 ) NOT NULL ,
`Nom` VARCHAR( 32 ) NOT NULL ,
`Prenom` VARCHAR( 32 ) NOT NULL ,
`NiveauAutorisation` INT( 1 ) NOT NULL
) ENGINE = MYISAM CHARACTER SET latin1 COLLATE latin1_swedish_ci " ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ [Comite] ...' ;
	
	$query = "CREATE TABLE `Comite` (
`IDComite` INT( 4 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`IDWeb` INT( 8 ) NOT NULL ,
`Code` VARCHAR( 4 ) NOT NULL ,
`Nom` VARCHAR( 64 ) NOT NULL ,
`Description` TEXT NOT NULL
) ENGINE = MYISAM ;" ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ [CouponRepas] ...' ;
	
	$query = "CREATE TABLE `CouponRepas` (
`IDCouponRepas` INT( 16 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`IDWeb` INT( 8 ) NOT NULL ,
`Nom` VARCHAR( 32 ) NOT NULL ,
`Prenom` VARCHAR( 32 ) NOT NULL ,
`DateUsage` DATE NOT NULL
) ENGINE = MYISAM ;" ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ [GroupeFolklorique] ...' ;
	
	$query = "CREATE TABLE `GroupeFolklorique` (
`IDGroupeFolklorique` INT( 4 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`Nom` VARCHAR( 64 ) NOT NULL ,
`Pays` VARCHAR( 32 ) NOT NULL
) ENGINE = MYISAM ;" ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ [Artiste] ...' ;
	
	$query = " CREATE TABLE `Artiste` (
`IDArtiste` INT( 8 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`IDGroupeFolklorique` INT( 4 ) NOT NULL ,
`Nom` VARCHAR( 64 ) NOT NULL ,
`Prenom` VARCHAR( 64 ) NOT NULL
) ENGINE = MYISAM CHARACTER SET latin1 COLLATE latin1_swedish_ci " ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ [CouleurAccreditation] ...' ;
	
	$query = "CREATE TABLE `CouleurAccreditation` (
`IDCouleurAccreditation` INT( 4 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`Nom` VARCHAR( 32 ) NOT NULL ,
`CodeCouleur` VARCHAR( 6 ) NOT NULL ,
`Description` TEXT NOT NULL
) ENGINE = MYISAM ;" ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ [Journal] ...' ;
	
	$query = "CREATE TABLE `Journal` (
`IDIndex` INT( 16 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`IDWeb` INT( 8 ) NOT NULL ,
`Date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
`Script` VARCHAR( 64 ) NOT NULL ,
`Retour` VARCHAR( 256 ) NOT NULL ,
`Commentaires` TEXT NOT NULL
) ENGINE = MYISAM ;" ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo 'Insertion des entr&eacute;es-clef ...<br>' ;
	
	echo '+ Administrateur ROOT ...' ;
	
	$query = "INSERT INTO `Web` (
`IDWeb` ,
`IDBenevole` ,
`Login` ,
`MDPEncode` ,
`Mail` ,
`Nom` ,
`Prenom` ,
`NiveauAutorisation`
)
VALUES (
'1' , '0', '".$_POST['pseudo']."', '".sha1($_POST['password'])."', '".$_POST['global_mail']."', '".$_POST['nom']."', '".$_POST['prenom']."', '4'
);" ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ Comit&eacute; vide ...' ;
	
	$query = "INSERT INTO `Comite` (
`IDComite` ,
`IDWeb` ,
`Code` ,
`Nom` ,
`Description`
)
VALUES (
'0', '0' , '0.00', 'Non-assigné', 'Ce comit".chr(233)." rassemble les b".chr(233)."n".chr(233)."voles n''".chr(233)."tant inscrit à aucun comit".chr(233)." (disponibles).'
);" ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ Update ...' ;
	
	$query = "UPDATE `Comite` SET `IDComite` = '0' WHERE `Comite`.`IDComite` = 1 LIMIT 1 ;" ;
	
	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ Couleur par d&eacute;faut ...' ;
	
	$query = "INSERT INTO `CouleurAccreditation` (
`IDCouleurAccreditation` ,
`Nom` ,
`CodeCouleur` ,
`Description`
)
VALUES (
'', 'Non-assigné', 'FFFFFF', 'Cette couleur regroupe les b".chr(233)."n".chr(233)."voles n\'".chr(233)."tant soumis a aucun niveau d\'accr".chr(233)."ditation particulier.'
);" ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ Liste noire ...' ;
	
	$query = "INSERT INTO `CouleurAccreditation` (
`IDCouleurAccreditation` ,
`Nom` ,
`CodeCouleur` ,
`Description`
)
VALUES (
'', 'Liste noire', '000000', 'Cette couleur regroupe les b".chr(233)."n".chr(233)."voles plac".chr(233)."s sur liste noire.'
);" ;

	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ Update ...' ;
	
	$query = "UPDATE `CouleurAccreditation` SET `IDCouleurAccreditation` = '0' WHERE `CouleurAccreditation`.`IDCouleurAccreditation` = 1 LIMIT 1 ;" ;
	
	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo '+ Update ...' ;
	
	$query = "UPDATE `CouleurAccreditation` SET `IDCouleurAccreditation` = '1' WHERE `CouleurAccreditation`.`IDCouleurAccreditation` = 2 LIMIT 1 ;" ;
	
	if( !mysql_query( $query ) )													stop() ;
	else																			ok() ;
	
	echo 'D&eacute;finition du fichier de configuration ...' ;
	
	if( substr( $_POST['global_url'] , 0 , 7 ) == 'http://' )				$_POST['global_url'] = substr( $_POST['global_url'] , 7 , 100 ) ;
	
	$conf_content = '<?php

	// > Variables par défaut
	//   [!] NE PAS MODIFIER SANS CERTITUDE 
	
	$contenu[\'erreur\']		=	FALSE ;								// Invalidation de l\'erreur
	for( $i = 1 ; $i < 512 ; $i++ )
	{
		$erreur[$i][\'etat\'] 	= FALSE ;
		$erreur[$i][\'titre\']	= NULL ;
		$erreur[$i][\'message\']	= NULL ;
	}
	if( empty( $_GET[\'in\'] ) || !isset( $_GET[\'in\'] ) )				// Page par défaut
	{
		$_GET[\'in\']			=	\'home\' ;
	}
	session_start() ;
	if( empty( $_SESSION[\'UID\'] ) )
	{
		$_SESSION[\'UID\']		= NULL ;
		$_SESSION[\'NiveauA\']	= 0 ;
	}
	error_reporting( 0 ) ;										// Désactivation des rapports d\'erreur
	$help					= "Vous trouverez ici des conseils pour les op&eacute;rations les plus d&eacute;licates." ;
	
	// > Variables globales
	
	$global[\'nom\']			=	\''.$_POST['global_nom'].'\' ;							// Nom du système
	$global[\'desc\']			=	\''.$_POST['global_desc'].'\' ;
	$global[\'mail\']			=	\''.$_POST['global_mail'].'\' ;				// Adresse mail de l\'administrateur
	$global[\'version\']		=	\''.$_POST['global_version'].'\' ;								// Version du système
	$global[\'update\']		=	\''.$_POST['global_update'].'\' ;						// Date de dernière mise à jour
	$global[\'url\']			=	\''.$_POST['global_url'].'\' ;	// URL du site
	$global[\'annee\']		=	2008 ;								// Année du prochain mondial

	// > Chemins vers répertoires
	// 	 NB. Chemins relatifs à partir du dossier racine contenant index.php
	
	$folder[\'systeme\']		=	\''.$_POST['folder_systeme'].'\' ;						// Système
	$folder[\'photos\']		=	\''.$_POST['folder_photos'].'\' ;						// Photographies d\'identité 
	$folder[\'scripts\']		=	\''.$_POST['folder_scripts'].'\' ;						// Scripts en usage
	$folder[\'pdf\']			=	\''.$_POST['folder_pdf'].'\' ;							// Scripts de génération PDF
	$folder[\'pdf_lib\']		=	\''.$_POST['folder_pdf_lib'].'\' ;					// Librairies de génération PDF
	$folder[\'palette\']		=	\''.$_POST['folder_palette'].'\' ;					// Palette de couleurs
	$folder[\'help\']			=	\''.$_POST['folder_help'].'\' ;					// Documentation
	$folder[\'picts\']		=	\''.$_POST['folder_picts'].'\' ;					// Eléments graphiques
	
	// > Identifiants SQL
	
	$sql[\'serveur\']			=	\''.$_POST['sql_serveur'].'\' ;				// Adresse du serveur
	$sql[\'login\']			=	\''.$_POST['sql_login'].'\' ;							// Login
	$sql[\'password\']		=	\''.$_POST['sql_password'].'\' ;							// Mot de passe
	$sql[\'bdd\']				=	\''.$_POST['sql_bdd'].'\' ;						// Nom de la base
	
	// > Identifiants FTP
	
	$ftp[\'serveur\']			=	\''.$_POST['ftp_serveur'].'\' ;				// Adresse du serveur
	$ftp[\'login\']			=	\''.$_POST['ftp_login'].'\' ;							// Login
	$ftp[\'password\']		=	\''.$_POST['ftp_password'].'\' ;							// Mot de passe
	$ftp[\'root\']			=	\''.$_POST['ftp_root'].'\' ;				// Adresse locale du dossier racine
	
	// > Variables diverses
	$misc[\'cliste\']			=	'.$_POST['misc_cliste'].' ;								// Nombre de résultats affichés par page (listes)
	$misc[\'resp_info\']		=	"'.$_POST['misc_resp_info'].'" ;					// Nom du responsable informatique du mondial
	$misc[\'resp_info_num\']	=	"'.$_POST['misc_resp_info_num'].'" ;					// Coordonnées téléphoniques du responsable informatique du mondial
	$misc[\'taille_mdp_min\']	=	'.$_POST['misc_mdp_taille_min'].' ;									// Taille minimum d\'un mot de passe
	$misc[\'taille_mdp_def\'] =	'.$_POST['misc_mdp_taille_def'].' ;									// Taille par défaut des mots de passe restaurés
	$misc[\'photo_defaut\']	=	"pipman.jpg" ;						// Photo par défaut des bénévoles
	$misc[\'message_nul\']	=	"non-d&eacute;fini(e)" ;			// Message de variable sèche
	$misc[\'message_listev\']	=	"Pas d\'entr&eacute;e dans la liste." ;	// Message de liste sèche
	$misc[\'img_maxw\']		=	'.$_POST['misc_img_maxw'].' ;								// Largeur maximum des photos en PX
	$misc[\'img_maxh\']		=	'.$_POST['misc_img_maxh'].' ;								// Hauteur maximum des photos en PX
	$misc[\'img_maxs\']		=	'.$_POST['misc_img_maxs'].' ;								// Poids maximum des photos en KO
	
	// > Liste des scripts
	//   NB. Une valeur de 0 correspond à un visiteur, 1 utilisateur, 2 modérateur & 3 administrateur
	
	$menu[0][0]				=	array(\'Accueil\',\'home\') ;
	$menu[0][1]				=	array(\'Liste des b&eacute;n&eacute;voles\',\'liste_benevoles\') ;
	$menu[0][2]				=	array(\'Rechercher un b&eacute;n&eacute;vole\',\'rechercher_benevoles\') ;
	$menu[0][3]				=	array(\'Contacts\',\'mail\') ;
	$menu[0][4]				=	array(\'Login\',\'login\') ;
	
	$menu[1][0]				=	array(\'Ins&eacute;rer un b&eacute;n&eacute;vole\',\'inserer_benevoles\') ;
	$menu[1][1]				=	array(\'Mon comit&eacute;\',\'mon_comite\') ;
	$menu[1][2]				=	array(\'Mes coupons-repas\',\'gestion_cr\') ;
	$menu[1][3]				=	array(\'Journal personnel\',\'journal\') ;
	$menu[1][4]				=	array(\'Mon profil\',\'profil\') ;
	
	$menu[2][0]				=	array(\'Gestion des coupons-repas\',\'gestion_coupons_repas\') ;
	$menu[2][1]				=	array(\'Gestion des comit&eacute;s\',\'gestion_comites\') ;
	$menu[2][2]				=	array(\'Gestion des groupes folkloriques\',\'gestion_gf\') ;
	$menu[2][3]				=	array(\'Impression de vignettes\',\'impression_v\') ;
	$menu[2][4]				=	array(\'Impression de laisser-passer\',\'impression_lp\') ;
	$menu[2][5]				=	array("Gestion des niveaux d\'accr&eacute;ditation",\'gestion_na\') ;
	$menu[2][6]				=	array(\'Liste noire\',\'blacklist\') ;
	
	$menu[3][0]				=	array(\'Gestion des mod&eacute;rateurs\',\'gestion_moderateurs\') ;
	$menu[3][1]				=	array("Ex&eacute;cution directe d\'une commande",\'execution\') ;
	$menu[3][2]				=	array(\'Liste des variables de configuration\',\'var_conf\') ;
	$menu[3][3]				=	array(\'Consulter le journal de bord\',\'journal_systeme\') ;
	
	$menu[4][0]				=	array(\'Gestion des administrateurs\',\'gestion_administrateurs\') ;

	// > Liste des message d\'erreur
	
	$erreur[1][\'titre\']		=	"Login invalide" ;
	$erreur[1][\'message\']	=	"<p>Votre tentative de login a &eacute;chou&eacute;. " .
			"Il peut s\'agir d\'une erreur lors de la saisie de vos identifiants." .
			"Veuillez v&eacute;rifier l\'&eacute;tat de votre touche \"Majuscule\" et tentez &agrave; nouveau de vous connecter au syst&egrave;me.</p>" .
			\'<p>Veuillez entrer vos identifiants pour vous connecter au syst&egrave;me.</p>
			<form method="post" action=""><blockquote>
				<p><strong>Votre login :</strong></p><p><input type="text" name="login"></p>
				<p><strong>Votre mot de passe :</strong></p><p><input type="password" name="password"></p>
				<p><div align="center"><input type="submit" value="Connexion"></div></p></blockquote>
			</form>\' .
			\'<p>Si vous pensez avoir &eacute;gar&eacute; votre mot de passe, cliquez <a href="?in=perdu_mdp">ici</a>.</p>\' ;
	
	$erreur[2][\'titre\']		=	"Autorisation requise" ;
	$erreur[2][\'message\']	=	"<p>L\'acc&egrave;s &agrave; cette page est restreint.</p>" .
			"<p>Veuillez v&eacute;rifier votre statut utilisateur (login).</p>" ;
	
	$erreur[3][\'titre\']		=	"Identifiants incorrects" ;
	$erreur[3][\'message\']	=	"<p>Votre tentative de restauration du mot de passe a &eacute;chou&eacute;.</p>" .
			"<p>Il peut s\'agir d\'une erreur lors de la saisie de vos identifiants. Si le probl&egrave;me se " .
			"perp&eacute;tue, il est possible que votre compte ait &eacute;t&eacute; supprim&eacute;. Auquel " .
			"cas, contactez l\'&eacute;quipe du mondial.</p>" .
			\'<form method="post" action=""><blockquote>
			<p><strong>Votre adresse mail :</strong></p><p><input type="text" name="mail" size="25"></p>
			<p><strong>Votre pseudonyme :</strong></p><p><input type="text" name="login" size="25"></p>
			<p><br><input type="submit" value="Envoi"></p></blockquote>
			</form>\' ;
			
	$erreur[4][\'titre\']		=	"Information manquante" ;
	$erreur[4][\'message\']	=	"<p>Un des champs de texte du dernier formulaire que vous avez rempli est " .
			"rest&eacute; vide ou incomplet. Merci de bien vouloir r&eacute;hit&eacute;rer votre derni&egrave;re requ&ecirc;te.</p>" ;
				
	$erreur[5][\'titre\']		=	"Confirmation invalide" ;
	$erreur[5][\'message\']	=	"<p>Le champ de confirmation entr&eacute; lors de votre derni&egrave;re requ&ecirc;te " .
			"est diff&eacute;rent de son original. Merci de bien vouloir v&eacute;rifier la similitude des informations " .
			"entr&eacute;es et de r&eacute;hit&eacute;rer votre demande.</p>" ;
			
	$erreur[6][\'titre\']		=	"Mot de passe invalide" ;
	$erreur[6][\'message\']	=	"<p>Le mot de passe que vous venez d\'entrer fait moins de ".$misc[\'taille_mdp_min\']." " .
			"caract&egrave;res obligatoires. Merci de bien vouloir en s&eacute;lectionner un autre.</p>" ;
	
	$erreur[7][\'titre\']		=	"Pas de r&eacute;sultat" ;
	$erreur[7][\'message\']	=	"<p>La requ&ecirc;te que vous venez de formuler n\'a renvoy&eacute; aucun " .
			"r&eacute;sultat valide. Merci de v&eacute;rifier les filtres pesant sur votre derni&egrave;re recherche.</p>" ;
			
	$erreur[8][\'titre\']		=	"Erreur d\'adressage" ;
	$erreur[8][\'message\']	=	"<p>L\'adresse (URL) requise semble invalide.</p>" .
			"<p>Si vous &ecirc;tes arriv&eacute; sur cette page via un lien interne au site, merci de bien vouloir " .
			"signaler le probl&egrave;me aux responsables du syst&egrave;me.</p>" ;
			
	$erreur[9][\'titre\']		=	"Profil introuvable" ;
	$erreur[9][\'message\']	=	"<p>Le profil que vous demandez est introuvable sur le serveur.</p>" ;
		
	$erreur[10][\'titre\']	=	"Code comit&eacute; incorrect" ;
	$erreur[10][\'message\']	=	"<p>Le code sp&eacute;cifi&eacute; est vide ou incorrect " .
			"(quatre caract&egrave;res maximum).</p>" ;
			
	$erreur[11][\'titre\']	=	"Code comit&eacute; invalide" ;
	$erreur[11][\'message\']	=	"<p>Le code sp&eacute;cifi&eacute; existe d&eacute;j&agrave; dans la liste. Veuillez " .
			"choisir une valeur unique.</p>" ;
			
	$erreur[12][\'titre\']	=	"Nom du comit&eacute; incorrect" ;
	$erreur[12][\'message\']	=	"<p>Le nom du comit&eacute; est vide ou existe d&eacute;j&agrave;. " .
			"Merci de v&eacute;rifier la valeur indiqu&eacute;e.</p>" ; 
			
	$erreur[13][\'titre\']	=	"Description du comit&eacute; vide" ;
	$erreur[13][\'message\']	=	"<p>La description du comit&eacute; est demeur&eacute;e vide ou est trop longue (plus " .
			"de 2000 caract&egrave;res). Merci de v&eacute;rifier la valeur indiqu&eacute;e.</p>" ;
		
	$erreur[14][\'titre\']	=	"Rappel du formulaire" ;
	$erreur[14][\'message\']	=	"<p>Une erreur s\'est produite lors du travail sur le comit&eacute;. " .
			"Vous pouvez reprendre votre travail &agrave; partir du formulaire ci-dessous.</p>" .
			\'<blockquote><form method="post" action="?in=\'.$_GET[\'in\'].\'&ok=1&mode=\'.$_GET[\'mode\'].\'&select_c=\'.$_GET[\'select_c\'].\'&cid=\'.$_GET[\'cid\'].\'#CC">\' .
					\'<table cellpading="10" width="100%">\' .
						\'<tr><td size="50">\' .
							\'<p><strong>Code :</strong></p><p><input value="\'.$_POST[\'code\'].\'" type="text" name="code" size="8" maxlength="4"></p>\' .
						\'</td>\' .
						\'<td>\' .
							\'<p><strong>Nom :</strong></p><p><input value="\'.$_POST[\'nom\'].\'" type="text" name="nom" size="40" maxlength="64"></p>\' .
						\'</td></tr>\' .
						\'<tr><td colspan="2">\' .
							\'<p><strong>Description :</strong></p><p><textarea name="description" rows="5" cols="80">\'.$_POST[\'description\'].\'</textarea></p>\' .
						\'</td></tr>\' .
						\'<tr><td>\' .
							\'<p><input type="submit" value="Cr&eacute;er"></p>\' .
						\'</td><td></td></tr>\' .
					\'</table></form></blockquote>\' ;
		
	$erreur[15][\'titre\']	=	"Erreur d\'identifiant" ;
	$erreur[15][\'message\']	=	"<p>Un des champs identitaires (nom, pr&eacute;nom) est demeur&eacute; vide. Merci de v&eacute;rifier.</p>" ;
	
	$erreur[16][\'titre\']	=	"Mail invalide" ;
	$erreur[16][\'message\']	=	"<p>L\'adresse mail sp&eacute;cifi&eacute;e est vide ou invalide. Merci de v&eacute;rifier la valeur indiqu&eacute;e.</p>" ;
	
	$erreur[17][\'titre\']	=	"Statut invalide" ;
	$erreur[17][\'message\']	=	"<p>L\'acc&egrave;s &agrave; cette page est restreint aux responsables de comit&eacute; " .
			"titulaires d\'un login utilisateur. Merci de votre compr&eacute;hension.</p>" ;	
			
	$erreur[18][\'titre\']	=	"Date de naissance invalide";
	$erreur[18][\'message\']	=	"<p>La date de naissance que vous venez d\'entrer est vide ou invalide. Merci de v&eacute;rifier.</p>";
	
	$erreur[19][\'titre\']	=	"Qualit&eacute; invalide";
	$erreur[19][\'message\']	=	"<p>La qualit&eacute; n\'a pas &eacute;t&eacute; sp&eacute;cifi&eacute;e.</p>";
	
	$erreur[20][\'titre\']	=	"Adresse invalide";
	$erreur[20][\'message\']	=	"<p>L\'adresse que vous venez d\'entrer est vide ou invalide </p>";
	
	$erreur[21][\'titre\']	=	"Num&eacute;ro de t&eacute;l&eacute;phone invalide";
	$erreur[21][\'message\']	=	"<p>Le num&eacute;ro que vous venez d\'entrer est vide ou invalide. Merci de v&eacute;rifier.</p>";	

	$erreur[22][\'titre\']	=	"Champ fonction invalide";
	$erreur[22][\'message\']	=	"<p>Vous n\'avez pas rentr&eacute; de fonction pour ce b&eacute;n&eacute;vole</p>";
	
	$erreur[23][\'titre\']	=	"Champ cellulaire invalide";
	$erreur[23][\'message\']	=	"<p>La num&eacutute; que vous venez d\'entrer est vide ou invalide, merci de corriger </p>";

	$erreur[24][\'titre\']	=	"Code postal incorrect" ;
	$erreur[24][\'message\']	=	"<p>Le code postal que vous avez entr&eacute; est incorrect. Merci de v&eacute;rifier.</p>" ;
	
	$erreur[25][\'titre\']	=	"Date invalide" ;
	$erreur[25][\'message\']	=	"<p>La date indiqu&eacute;e est incorrecte. Veuillez v&eacute;rifier.</p>" ;
	
	$erreur[26][\'titre\']	=	"Date p&eacute;rim&eacute;e" ;
	$erreur[26][\'message\']	=	"<p>La date indiqu&eacute;e est d&eacute;pass&eacute;e. Veuillez v&eacute;rifier.</p>" ;
	
	$erreur[27][\'titre\']	=	"Nombre de coupons invalide" ;
	$erreur[27][\'message\']	=	"<p>Le nombre de coupons que vous avez indiqu&eacute; est invalide. Veuillez v&eacute;rifier.</p>" ;
	
	$erreur[28][\'titre\']	=	"Suppression excessive" ;
	$erreur[28][\'message\']	=	"<p>Le nombre de coupons que vous souhaitez effacer à la date indiqu&eacute;e est excessif. Veuillez v&eacute;rifier.</p>" ;
	
	$erreur[29][\'titre\']	=	"Exclusion impossible" ;
	$erreur[29][\'message\']	=	"<p>En tant que responsable de comit&eacute;, il vous est impossible de vous exclure de votre propre comit&eacute; !</p>" ;
	
	$erreur[30][\'titre\']	=	"Inclusion impossible" ;
	$erreur[30][\'message\']	=	"<p>En tant que responsable de comit&eacute;, il vous est impossible de vous inclure dans votre propre comit&eacute; !</p>" ;
			
	$erreur[31][\'titre\']	=	"Code couleur incorrect" ;
	$erreur[31][\'message\']	=	"<p>Le code couleur indiqu&eacute; est incorrect. Veuillez v&eacute;rifier.</p>" ;
			
	$erreur[32][\'titre\']	=	"Suppression impossible" ;
	$erreur[32][\'message\']	=	"<p>Cette entr&eacute;e est la derni&egrave;re de la liste, rendant impossible son effacement. " .
			"Merci d\'ins&eacute;rer une ou plusieurs entr&eacute;es suppl&eacute;mentaires et r&eacute;hit&eacute;rer l\'op&eacute;ration.</p>" ;
			
	$erreur[33][\'titre\']	=	"B&eacute;n&eacute;vole existant" ;
	$erreur[33][\'message\']	=	"<p>Un b&eacute;n&eacute;vole d&eacute;j&agrave; existant a &eacute;t&eacute; trouv&eacute; " .
			"sous nom et pr&eacute;nom identique &agrave; ceux entr&eacute;s.</p><p>Vous &ecirc;tes invit&eacute; &agrave; v&eacute;rifier " .
			"les listes d&eacute;j&agrave; existantes avant de continuer. Si vous d&eacute;sirez forcer l\'insertion du nouveau " .
			"b&eacute;n&eacute;vole, veuillez cocher la case \'F\' situ&eacute;e &agrave; droite du champ \'Pr&eacute;nom\', dans le formulaire " .
			"d\'inscription.</p>" ;
			
	$erreur[34][\'titre\']	=	"Ville invalide" ;
	$erreur[34][\'message\']	=	"<p>La ville que vous avez entr&eacute; est vide ou invalide.</p>" ;
			
	$erreur[35][\'titre\']	=	"Code postal invalide" ;
	$erreur[35][\'message\']	=	"<p>Le code postal que vous avez entr&eacute; est vide ou invalide. Merci de v&eacute;rifier.</p>" ;
			
	$erreur[36][\'titre\']	=	"Province vide" ;
	$erreur[36][\'message\']	=	"<p>La province que vous avez entr&eacute; est vide.</p>" ;
			
	$erreur[37][\'titre\']	=	"Fonction invalide" ;
	$erreur[37][\'message\']	=	"<p>La fonction entr&eacute;e pour ce b&eacute;n&eacute;vole est invalide.</p>" ;
			
	$erreur[38][\'titre\']	=	"Inscription impossible" ;
	$erreur[38][\'message\']	=	"<p>La case \'Recommandable\' est d&eacute;coch&eacute;e.</p><p>Si il ne s\'agissait pas d\'une erreur, nous " .
			"vous rappelons que vous &ecirc;tes guarant(e) de la fiabilit&eacute; des b&eacute;n&eacute;voles dont vous r&eacute;alisez " .
			"l\'inscription. Si cel&agrave; venait &agrave; se r&eacute;v&eacute;ler impossible, merci de bien vouloir annuler votre travail." ;
			
	$erreur[39][\'titre\']	=	"Volume de l\'image excessif" ;
	$erreur[39][\'message\']	=	"<p>L\'image upload&eacute;e p&egrave;se trop lourd (limite : ".$misc[\'img_maxs\']."ko). Il est conseill&eacute; " .
			"de convertir l\'image en noir et blanc.</p>" ;
			
	$erreur[40][\'titre\']	=	"Format incorrect" ;
	$erreur[40][\'message\']	=	"<p>Le format de l\'image est incorrect (formats admis : JPG/PNG uniquement).</p>" ;
			
	$erreur[41][\'titre\']	=	"Dimensions incorrectes" ;
	$erreur[41][\'message\']	=	"<p>Les dimensions de l\'images sont trop &eacute;lev&eacute;es (maximum : 160px largeur, 240px hauteur).</p>" ;
			
	$erreur[42][\'titre\']	=	"Message invalide" ;
	$erreur[42][\'message\']	=	"<p>Merci de bien vouloir entrer un sujet et un message pour votre mail.</p>" ;
			
	$erreur[43][\'titre\']	=	"Volume horaire invalide" ;
	$erreur[43][\'message\']	=	"<p>Le volume horaire indiqu&eacute; pour ce b&eacute;n&eacute;vole est invalide.</p>" ;
			
	$erreur[44][\'titre\']	=	"Pseudonyme existant" ;
	$erreur[44][\'message\']	=	"<p>Le pseudonyme indiqu&eacute; existe d&eacute;j&agrave; sur la base de donn&eacute;es. Merci d\'en choisir un autre.</p>"	;
	
	$erreur[45][\'titre\']	=	"Inclusion impossible" ;
	$erreur[45][\'message\']	=	"<p>Ce b&eacute;n&eacute;vole est actuellement sur liste noire, rendant impossible son inclusion au comit&eacute;.</p>" ;
	
	$erreur[46][\'titre\']	=	"Bannissement impossible" ;
	$erreur[46][\'message\']	=	"<p>Ce b&eacute;n&eacute;vole est actuellement consid&eacute;r&eacute; comme un responsable de comit&eacute;, rendant " .
			"impossible sa mise sur liste noire.</p>" ;
			
	$erreur[47][\'titre\']	=	"Changement de couleur impossible" ;
	$erreur[47][\'message\']	=	"<p>Ce b&eacute;n&eacute;vole est actuellement sur liste noire ; le changement de son niveau d\'accr&eacute;ditation est impossible.</p>" ;
	
	$erreur[404][\'titre\']	=	"Page introuvable" ;
	$erreur[404][\'message\']	=	"<p>La page que vous avez demand&eacute; est introuvable sur le serveur. 
			Il peut s\'agir d\'une erreur d\'adressage ou d\'une mise &agrave; jour du syst&ecirc;me. 
			Merci de mettre &agrave; jour vos favoris en cons&eacute;quence.</p>" ;

?>
' ;

	ok() ;
	
	echo 'Cr&eacute;ation du fichier de configuration ...' ;
	
	if( !$f=fopen('config.php','w') )													stop() ;
	else																				ok() ;
	
	echo 'R&eacute;daction du fichier ...' ;
	
	if( !fwrite( $f , $conf_content ) )													stop() ;
	else																				ok() ;
	
	echo 'Fermeture de la connexion au serveur SQL ...' ;
	
	mysql_close() ;
	
	ok() ;
	
	echo 'Fermeture de la connexion au serveur FTP ...' ;
	
	ftp_close($tmp) ;
	
	ok() ;
	
	echo 'Fin de l\'installation.' ;
	
	echo '</blockquote>' .
			'<p>Allegro est correctement install&eacute; ! Rendez-vous sur le syst&egrave;me &agrave; <a href="'.$_POST['global_url'].'">cette adresse</a> !' ;
}
else
{
	$way = $_SERVER['DOCUMENT_ROOT'].$_SERVER['REQUEST_URI'] ;
	
	for( $i = 1 ; substr( $way , -($i+1) , 1 ) != '/' ; $i++ ) ;
	
	$way = substr( $way , 0 , strlen( $way ) - $i ) ;
	
	echo 
	
		'<p>Vous vous appr&eacute;tez &agrave; installer Allegro 1.0<br>' .
		'Remplissez <em>tous</em> les champs ci-dessous et cliquez sur "Envoyer".<br>' .
		'<strong>Attention :</strong> les fichiers tiers d\'Allegro doivent &ecirc;tre en ligne aux adresses indiqu&eacute;es sous peine d\'interruption de l\'installation.</p>' .
		
		'<form method="post" action="?install=yes">' .
		
		'<!--- COMPTE ROOT --->' .
		
		'<p><font size="+1"><strong>Compte administrateur principal</strong></p>' .

		'<blockquote>' .
			'<p><strong>Pseudonyme :</strong><br>' .
			'<input type="text" name="pseudo" value="" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Mot de passe :</strong><br>' .
			'<input type="text" name="password" value="" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Nom :</strong><br>' .
			'<input type="text" name="nom" value="" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Pr&eacute;nom :</strong><br>' .
			'<input type="text" name="prenom" value="" size="40"></p>' .
		'</blockquote>' .
		
		'<!--- $global[] --->' .
		
		'<p><font size="+1"><strong>Variables globales</strong></p>' .

		'<blockquote>' .
			'<p><strong>Nom du syst&egrave;me :</strong><br>' .
			'<input type="text" name="global_nom" value="Allegro" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Description du syst&egrave;me :</strong><br>' .
			'<input type="text" name="global_desc" value="Administration du Mondial des Cultures" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Adresse mail de l\'administrateur principal :</strong><br>' .
			'<input type="text" name="global_mail" value="admin@mondialdescultures.com" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Version courante :</strong><br>' .
			'<input type="text" name="global_version" value="1.0" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Derni&egrave;re mise &agrave; jour :</strong><br>' .
			'<input type="text" name="global_update" value="'.date("Y").'-'.date('m').'-'.date('d').'" size="40"><br>' .
			'<font size="-1">Date SQL au format YYYY-MM-DD</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>URL principale du syst&egrave;me :</strong><br>' .
			'<input type="text" name="global_url" value="" size="40"><br>' .
			'<font size="-1">Adresse compl&egrave;te pointant vers le dossier racine du syst&egrave;me, type : [www.monsite.com/allegro/]. Doit se terminer par /.</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Ann&eacute;e du prochain festival :</strong><br>' .
			'<input type="text" name="global_annee" value="'.(date("Y")+1).'" size="40"></p>' .
		'</blockquote>' .
		
		'<!--- $folder[] --->' .
		
		'<p><font size="+1"><strong>Chemin des r&eacute;pertoires</strong></p>' .
		
		'<blockquote>' .
			'<p><strong>Dossier syst&egrave;me :</strong><br>' .
			'<input type="text" name="folder_systeme" value="systeme/" size="40"><br>' .
			'<font size="-1">Doit se terminer par /.</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Dossier des portraits :</strong><br>' .
			'<input type="text" name="folder_photos" value="uploads/" size="40"><br>' .
			'<font size="-1">Doit se terminer par /.</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Dossier des scripts :</strong><br>' .
			'<input type="text" name="folder_scripts" value="scripts/" size="40"><br>' .
			'<font size="-1">Doit se terminer par /.</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Dossier des scripts PDF :</strong><br>' .
			'<input type="text" name="folder_pdf" value="pdf/" size="40"><br>' .
			'<font size="-1">Doit se terminer par /.</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Dossier de la librairie PDF :</strong><br>' .
			'<input type="text" name="folder_pdf_lib" value="pdf/librairie/" size="40"><br>' .
			'<font size="-1">Doit se terminer par /.</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Dossier de la palette :</strong><br>' .
			'<input type="text" name="folder_palette" value="extras/palette/" size="40"><br>' .
			'<font size="-1">Doit se terminer par /.</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Dossier de l\'aide :</strong><br>' .
			'<input type="text" name="folder_help" value="extras/pdf/" size="40"><br>' .
			'<font size="-1">Doit se terminer par /.</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Dossier des images :</strong><br>' .
			'<input type="text" name="folder_picts" value="extras/picts/" size="40"><br>' .
			'<font size="-1">Doit se terminer par /.</font></p>' .
		'</blockquote>' .
		
		'<!--- $sql[] --->' .
		
'<p><font size="+1"><strong>Variables SQL</strong></p>' .
		
		'<blockquote>' .
			'<p><strong>Adresse du serveur SQL :</strong><br>' .
			'<input type="text" name="sql_serveur" value="mysql6.monserveur.com" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Login de connexion au serveur SQL :</strong><br>' .
			'<input type="text" name="sql_login" value="mon_pseudo" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Mot de passe de connexion au serveur SQL :</strong><br>' .
			'<input type="text" name="sql_password" value="mon_mdp" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Nom de la base de donn&eacute;es :</strong><br>' .
			'<input type="text" name="sql_bdd" value="ma_bdd" size="40"></p>' .
		'</blockquote>' .
		
		'<!--- $ftp[] --->' .

'<p><font size="+1"><strong>Variables FTP</strong></p>' .
		
		'<blockquote>' .
			'<p><strong>Adresse du serveur FTP :</strong><br>' .
			'<input type="text" name="ftp_serveur" value="ftp3.monserveur.com" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Login de connexion au serveur FTP :</strong><br>' .
			'<input type="text" name="ftp_login" value="mon_pseudo" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Mot de passe de connexion au serveur FTP :</strong><br>' .
			'<input type="text" name="ftp_password" value="mon_mdp" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Adresse du dossier racine sur le serveur :</strong><br>' .
			'<input type="text" name="ftp_root" value="'.$way.'" size="40"></p>' .
		'</blockquote>' .
		
		'<!--- $misc[] --->' .
		
'<p><font size="+1"><strong>Variables diverses</strong></p>' .
		
		'<blockquote>' .
			'<p><strong>Nombre de r&eacute;sultats par d&eacute;faut et par page pour les listes :</strong><br>' .
			'<input type="text" name="misc_cliste" value="10" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Nom du responsable informatique :</strong><br>' .
			'<input type="text" name="misc_resp_info" value="" size="40"><br>' .
			'<font size="-1">Type : [Pr&eacute;nom NOM]</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Num&eacute;ro de t&eacute;l&eacute;phone du responsable info :</strong><br>' .
			'<input type="text" name="misc_resp_info_num" value="" size="40"><br>' .
			'<font size="-1">Num&eacute;ro complet, par exemple [(819)123-4567]</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Taille minimale des mots de passe :</strong><br>' .
			'<input type="text" name="misc_mdp_taille_min" value="4" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Taille par d&eacute;faut des mots de passe :</strong><br>' .
			'<input type="text" name="misc_mdp_taille_def" value="8" size="40"></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Largeur maximum des images :</strong><br>' .
			'<input type="text" name="misc_img_maxw" value="160" size="40"><br>' .
			'<font size="-1">En pixels.</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Hauteur maximum des images :</strong><br>' .
			'<input type="text" name="misc_img_maxh" value="240" size="40"><br>' .
			'<font size="-1">En pixels.</font></p>' .
		'</blockquote>' .
		'<blockquote>' .
			'<p><strong>Poids maximum des images :</strong></p>' .
			'<p><input type="text" name="misc_img_maxs" value="1000" size="40"><br>' .
			'<font size="-1">En octets.</font></p>' .
		'</blockquote>' .
		
		'<input type="submit" value="Installer !">' .
		
		'</form>' ;
		
}

?>
