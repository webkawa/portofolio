<?php

/*	----------------------------------------------------------------
 * 	index.php
 * 	----------------------------------------------------------------
 * 	[Description]
 * 		Fichier principal.
 * 	[Notice]
 * 		Ce fichier doit être placé à la racine du site.
 *	----------------------------------------------------------------	*/

	// > Inclusion des variables de configuration & définition du chemin vers le dossier système
	include	'config.php' ;
	
	// > Processus de traitement
	include $folder['systeme'].'fonctions.php' ;
	include $folder['systeme'].'session.php' ;
	include $folder['systeme'].'script.php' ;
	include $folder['systeme'].'renvoi.php' ;

?>