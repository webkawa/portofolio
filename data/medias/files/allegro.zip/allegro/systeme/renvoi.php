<?php

/*	----------------------------------------------------------------
 * 	renvoi.php
 * 	----------------------------------------------------------------
 * 	[Description]
 * 		Fichier de génération et d'affichage du code HTML.
 * 	[Notice]
 * 		Ce fichier doit être placé dans le dossier système.
 * 	[Variables de contenu]
 * 		$contenu['principal']				> Contenu texte au centre de la page (mis en forme)
 * 		$contenu['titre']					> Titre de la page
 * 		$contenu['menu']					> Contenu du menu latéral gauche
 * 		$contenu['aide']					> Contenu de la bulle d'aide
 * 		$contenu['nom_utilisateur']			> Nom de l'utilisateur courant
 * 		$contenu['prenom_utilisateur']		> Prénom de l'utilisateur courant
 * 		$contenu['fonction_utilisateur']	> Niveau de l'utilisateur courant
 *	----------------------------------------------------------------	*/

	// > Définition du contenu interne

if( !$contenu['erreur']	)											// Définition simple
{
	$contenu['titre']				=	$titre ;
	$contenu['principal']			=	$texte ;
	$contenu['aide']				=	$help ;
}
else																// Traitement des erreurs
{
	$contenu['titre']		= 'Erreur' ;
	$contenu['principal'] 	= "<p>Une ou plusieurs erreurs viennent de se produire. " .
			"Il s'agit probablement d'un probl&egrave;me li&eacute; &agrave; votre derni&egrave;re requ&ecirc;te.</p>" .
			"<p>Veuillez prendre connaissance du rapport d'erreur ci-dessous ; si le probl&ecirc;me se poursuit malgr&eacute; tout, merci de prendre contact avec les administrateurs du syst&ecirc;me.</p>" .
			"<h2>Rapport d'erreur</h2>" ;
	$contenu['aide']		= "<p>Si vous ne comprenez pas l'intitul&eacute; du message d'erreur ci-dessus, merci de bien vouloir contacter ".$misc['resp_info']." au ".$misc['resp_info_num']."." ;
	
	for( $i = 1 ; $i < 512 ; $i++ )
	{
		if( $erreur[$i]['etat'] )
		{
			$tmp 		 			 = erreur( $i ) ;
			$contenu['principal']	.= '<h3>'.$i.'. '.$tmp['titre'].'</h3><p>'.$tmp['principal'].'</p>' ;
		}
	}
	
	$contenu['principal']	.= "<h3>Options</h3>" .
			"<p>Pour revenir au d&eacute;part de la page pr&eacute;c&eacute;dente, cliquez " . lk('ici',$_GET['in'],FALSE,'uid='.$_GET['uid'].'&bid='.$_GET['bid']) . ".</p>";
}

	// > Définition des informations de session

$contenu['nom_utilisateur']			=	$session_infos['Nom'] ;			// Nom						
$contenu['prenom_utilisateur']		=	$session_infos['Prenom'] ;		// Prénom
$contenu['fonction_utilisateur']	=	$session_infos['Fonction'] ;	// Fonction
$contenu['statut_utilisateur']		=	$session_infos['Statut'] ;		// Etat
$contenu['opt_utilisateur']			=	$session_infos['Options'] ;		// Options

	// > Définition du menu

for( $i = 0 ; $i <= $_SESSION['NiveauA'] ; $i++ )
{
	if( $i == 0 )				$contenu['menu'] .= '<p class="Titre_Menu">Visiteur</p>' ;
	if( $i == 1 )				$contenu['menu'] .= '<p class="Titre_Menu">Utilisateur</p>' ;
	if( $i == 2 )				$contenu['menu'] .= '<p class="Titre_Menu">Mod&eacute;rateur</p>' ;
	if( $i == 3 )				$contenu['menu'] .= '<p class="Titre_Menu">Administrateur</p>' ;
	if( $i == 4 )				$contenu['menu'] .= '<p class="Titre_Menu">Root</p>' ;
	
	$contenu['menu'] .= '<p class="Element_Menu">' ;
	for( $j = 0 ; $menu[$i][$j] ; $j++ )
	{
		$contenu['menu'] .= lk( $menu[$i][$j][0] , $menu[$i][$j][1] ).'<br>' ;
	}
	$contenu['menu'] .= '</p>' ;
}

	// > Définition du bloc HTML

$contenu['html'] = '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link href="style.css" rel="stylesheet" type="text/css">
	<title>['.$global['nom'].']!['.$global['desc'].']</title>
</head>
<body>
	<div id="Header">
		<div id="Banniere">
			<div id="Version">
				<span>'.$global['version'].'</span>
			</div>
		</div>
	</div>
	<div id="Center">
		<div id="Contenu">
			<h1>'.$contenu['titre'].'</h1>
			'.$contenu['principal'].'
		</div>
	</div>
	<div id="Footer">Allegro '.$global['version'].' est un logiciel d&eacute;pos&eacute; sous licence GFDL.<br>Niveau de s&eacute;curit&eacute; actuel : '.$session_infos['Fonction'].'</div>
	</div>
	<div id="Colonne-Gauche">
		<div id="Menu">
			'.$contenu['menu'].'
		</div>
		<div id="Help">
			<p class="Titre_Menu">Aide</p>
			<p class="Element_Menu">'.$contenu['aide'].'</p>
		</div>
	</div>
	<div id="Login">
				<p class="Statut">'.$contenu['statut_utilisateur'].'</p>
				<p class="Log-Infos">'.$contenu['nom_utilisateur'].'<br>'.$contenu['prenom_utilisateur'].'<br>'.$contenu['fonction_utilisateur'].'</p>
				<p class="Log-Infos">'.$contenu['opt_utilisateur'].'</p>
	</div>	
</body>
</html> ' ;

	// > Renvoi
	
	echo $contenu['html'] ;
	
	// Indexation du résultat dans le journal
	
	if( $contenu['erreur'] )
	{
		$resultat = "Erreur(s) traitees : " ;
		for( $i = 1 ; $i < 512 ; $i++ )
		{
			if( $erreur[$i]['etat'] )
			{
				$resultat.= '['.$i.']' ;
			}
		}
	}
	else
	{
		$resultat = "OK" ;
	}
	fl_journal( $resultat ) ;

?>
