<?php

/*	----------------------------------------------------------------
 * 	session.php
 * 	----------------------------------------------------------------
 * 	[Description]
 * 		Fichier de gestion des informations session.
 *	----------------------------------------------------------------	*/

	session_infos() ;
	
	if( $_SESSION['UID'] == NULL )
	{
		$help = '<p>Vous vous trouvez actuellement en mode non-connect&eacute;. Cliquez '.lk('ici','login').' pour vous connecter au syst&egrave;me.</p>' ;
	}
	
	nl_journal() ;

?>
