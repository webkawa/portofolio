<?php

/*	----------------------------------------------------------------
 * 	fonctions.php
 * 	----------------------------------------------------------------
 * 	[Description]
 * 		Fichier de définition des fonctions courantes.
 * 	[Listing]
 * 		+ - Gestion des comptes
 * 		|	login()								> Tentative de login au système
 * 		|	unlogin()							> Déconnection du système
 * 		|	session_infos()						> Recherche des informations sur l'utilisateur en cours
 * 		|	niveau_securite()					> Validation du niveau d'autorisation utilisateur
 * 		|	restaurer()							> Restauration d'un compte
 * 		|	creer_compte()						> Création d'un nouveau compte
 * 		+ - Gestion des erreurs
 * 		|	erreur()							> Affichage d'une erreur simple
 * 		|	e_erreur()							> Prise en compte d'une erreur simple
 * 		|	f_erreur()							> Affichage d'une erreur fatale
 * 		|	is_e()								> Recherche d'une erreur utilisateur
 * 		+ - SQL Brut
 * 		|	connection_sql()					> Connection au serveur SQL par défaut
 * 		|	deconnection_sql()					> Déconnection du serveur SQL précédemment contacté
 * 		|	select_sql()						> Exécution d'une requête SELECT dans la base SQL
 * 		|	insert_sql()						> Exécution d'une requête INSERT dans la base SQL
 * 		|	update_sql()						> Exécution d'une requête UPDATE dans la base SQL
 * 		|	delete_sql()						> Exécution d'une requête DELETE dans la base SQL
 * 		|	select_free_sql()					> Exécution d'une requête sélective libre sur la base SQL
 * 		|	select_max_sql()					> Recherche d'un maximum dans la base SQL
 * 		|	denombrer_sql()						> Décompte des entrées dans une base SQL
 * 		|	date_sql()							> Récupération de la date au format SQL
 * 		+ - HTML
 * 		|	lk()								> Génération d'un lien pré-formaté
 * 		|	lk_pdf()							> Génération d'un lien vers une liste PDF
 * 		|	liste()								> Génération d'une liste pré-formatée
 * 		|	html_photo()						> Génération d'une balise image pour les photographies bénévoles
 * 		|	html_date()							> Traitement d'une date
 * 		|	html_yesno()						> Traitement d'un bouléen
 * 		|	html_button()						> Renvoi d'un bouton de formulaire mis en forme
 * 		|	type_compte() 						> Traduction litérale du niveau d'autorisation
 * 		|	ok()								> Renvoi d'un bouton de validation
 * 		+ - Indexation des actions
 * 		|	nl_journal()						> Ouverture d'une entrée au journal
 * 		|	fl_journal()						> Fermeture d'une entrée au journal
 * 		|	journal()							> Ajout d'un commentaire au journal
 * 		+ - Fonctions SQL récurrentes
 * 		|	benevole_infos()					> Recherche des informations sur un bénévole
 * 		|	voir_confidentiel()					> Vérification pour diffusion des identifiants personnels
 * 		|	web2benevole()						> Conversion d'un IDWeb en IDBenevole
 * 		|	benevole2web()						> Conversion d'un IDBenevole en IDWeb
 * 		|	inclure_benevole()					> Inclusion d'un bénévole dans le comité courant
 * 		|	exclure_benevole()					> Exclusion du bénévole hors du comité courant
 * 		+ - Autres fonctions récurrentes
 * 		|	envoi_mail()						> Envoi d'un mail pré-formaté
 * 		|	vide()								> Validation des valeurs vacantes
 * 		|	contenu_liste()						> Récupération du contenu de la dernière liste
 * 		|	appel_liste()						> Détection d'une liste en cours
 * 		|	generer_mdp()						> Génération d'un mot de passe aléatoire
 * 		|	valider_mail()						> Validation synthaxique d'une adresse mail
 * 		|	depassee()							> Validation d'une date future
 *	----------------------------------------------------------------	*/

	// > Gestion des comptes

	function login( $login , $mdp )
	{
		/*	[Description]
		 *		Cette fonction tente d'identifier un utilisateur enregistré.
		 *	[Note]
		 *		La fonction renvoi FALSE en cas d'échec, ou un ID utilisateur en cas de succès
		 *	[Arguments]
		 *		$login				> Login de l'utilisateur
		 *		$mdp				> Mot de passe de l'utilisateur
		 *	[Retours]
		 *		$retour				> Résultat de la requête								*/
		 
		 // Recherche de l'utilisateur	 
		 	$retour = select_sql( 'Web' , "Login = '".$login."' && MDPEncode = '".sha1( $mdp )."'" , '*' , 'LIMIT 1' );	
		 
		 // Validation
		 	if( $retour['nbr'] != 1 )
		 	{
		 		return FALSE ;
		 	}
		 	
		 // Définition des variables de session
		 	$_SESSION['UID'] 		= $retour['IDWeb'] ;
		 	$_SESSION['NiveauA']	= $retour['NiveauAutorisation'] ;

		 // Renvoi de l'ID utilisateur
		 	return $retour['IDWeb'] ;
	}
	function unlogin()
	{
		/*	[Description]
		 *		Cette fonction déconnecte un utilisateur enregistré.			*/
		 
		global $session_infos ;
		
		session_destroy() ;
		session_start() ;
		
		$_SESSION['UID']			= 0 ;
		$_SESSION['NiveauA']		= 0 ;
		$_SESSION['RequetePDF']		= NULL ;
		
		session_infos() ;
	}
	function session_infos()
	{
		/*	[Description]
		 *		Cette fonction recherche et renvoie les informations sur l'utilisateur en cours.
		 *	[Note]
		 *		Si l'utilisateur est un visiteur, des informations par défaut sont renvoyées.
		 *	[Retours]
		 *		$retour				> Résultat de la requête SQL								*/
		
		global $global ;
		global $session_infos ;
		
		// Informations par défaut
		if( $_SESSION['NiveauA'] == 0 )
		{
			$retour['IDWeb']				= -1 ;
			$retour['Login']				= 'User' ;
			$retour['MDPEncode']			= NULL ;
			$retour['Mail']					= 'none@'.$global['url'] ;
			$retour['Nom']					= '-' ;
			$retour['Prenom']				= '-' ;
			$retour['NiveauAutorisation']	= 0 ; 
			$retour['Statut']				= 'D&eacute;connect&eacute; ...' ;
			$retour['Options']				= '<br>'.lk('Connexion','login') ;
			$retour['IDComite']				= -1 ;
		}
		
		// Recherche
		else
		{
			$tmp = select_sql( 'Web' , 'IDWeb='.$_SESSION['UID'] , '*' );
			$retour = $tmp[0] ;
			
			if( $tmp['nbr'] != 1 )				f_erreur( 36 , 'fonctions.php' , 4 , 'Erreur de securite' ) ;
			
			if( $retour['NiveauAutorisation'] == 1 )
			{
				$tmp = select_sql( 'Comite' , 'IDWeb='.$retour['IDWeb'] , '*' , 'LIMIT 1' ) ;
				$retour['IDComite'] = $tmp[0]['IDComite'] ;
				$retour['CodeComite'] = $tmp[0]['Code'] ;
				$retour['NomComite'] = $tmp[0]['Nom'] ;
			}
			else
			{
				$retour['IDComite'] = -1 ;
			}
			
			if( $retour['IDBenevole'] != 0 )
			{
				$retour['Benevole'] 			= benevole_infos( $retour['IDBenevole'] ) ;
				$retour['Benevole']['Profil']	= lk( $retour['Benevole']['Prenom']." ".$retour['Benevole']['Nom'] , 'profil_benevoles' , TRUE , 'uid='.$retour['IDBenevole'] ) ;
			}
			else
			{
				$retour['Benevole'] 			= FALSE ;
				$retour['Benevole']['Profil']	= "pas de fiche b&eacute;n&eacute;vole associ&eacute;e" ;
			}
			
			$retour['Statut'] = 'Connect&eacute; ...' ;
			$retour['Options'] = lk('Options','profil').'<br>'.lk('D&eacute;connection','deconnection') ;
		}
		
		// Gestion de la fonction
		
		$retour['Fonction']	=	type_compte( $retour['NiveauAutorisation'] ) ;
		
		// Application
		
		$session_infos = $retour ;
		
		// Renvoi
		
		return $retour ;
	}
	function restaurer( $uid , $upass )
	{
		/*	[Description]
		 *		Cette fonction restaure le mot de passe d'un compte pour une valeur par défaut.
		 *	[Arguments]
		 *		$uid				> ID du compte
		 *		$upass				> Ancien mot de passe encodé du compte
		 *	[Retours]
		 *		$password			> Nouveau mot de passe non-encodé							*/
		
		$securite = denombrer_sql( "Web" , "IDWeb='".$uid."' && MDPEncode='".$upass."'" );
		
		if( $securite != 1 )
		{
			f_erreur( 14 , 'fonctions.php' , 1 , "Erreur de securite" );
		}
		
		$n_mdp = generer_mdp() ;
		
		$on[0] = array( "MDPEncode" , sha1( $n_mdp ) , TRUE ) ;
		
		update_sql( "Web" , $on , "`Web`.`IDWeb` = ".$uid." && `Web`.`MDPEncode` = '".$upass."'" ) ;
		
		return $n_mdp ;
	}
	function creer_compte( $niveau , $nom , $prenom , $mail , $associate = FALSE )
	{
		/*	[Description]
		 *		Cette fonction crée un nouveau compte dans la base de données.
		 *	[Arguments]
		 *		$niveau				> Niveau d'autorisation chiffré du compte
		 *		$nom				> Nom associé au compte
		 *		$prenom				> Prénom associé au compte
		 *		$mail				> Adresse de messagerie associée au compte
		 *		$associate			> Compte bénévole lié
		 *	[Retours]
		 *		$resultat			> ID du compte créé										*/
		
		global $global ;
		
		// Gestion des chefs de comité & modérateurs
		
		if( $associate )
		{
			if( !validation_sql( "Benevole" , "IDBenevole" , $associate ) )
			{
				f_erreur( 21 , "fonctions.php" , 4 , "Erreur in creer_compte()" ) ;
			}
		}
		else $associate = 0 ;
		
		// Génération du nom et du mot de passe
		
		$pseudo 	= substr( $prenom , 0 , 1 ).'.'.$nom ;
		$password	= generer_mdp() ;
		
		// Insertion
		
		$on[0] = array( 'IDBenevole' , $associate , FALSE ) ;
		$on[1] = array( 'Login' , $pseudo , TRUE ) ;
		$on[2] = array( 'MDPEncode' , sha1( $password ) , TRUE ) ;
		$on[3] = array( 'Mail' , $mail , TRUE ) ;
		$on[4] = array( 'Nom' , $nom , TRUE ) ;
		$on[5] = array( 'Prenom' , $prenom , TRUE ) ;
		$on[6] = array( 'NiveauAutorisation' , $niveau , FALSE ) ;
		
		insert_sql( "Web" , $on ) ;
		
		// Envoi du mail
		
		$message	 =	"Bonjour\n\n" .
							"Suite à votre engagement dans le cadre du Mondial des Cultures de Drummondville " .
							"en tant que responsable de comité, vous êtes désormais titulaire d'un compte " .
							"sur le système de gestion des bénévoles.\n\n" .
							"Celui-ci est accessible à l'adresse suivante :\n" .
							$global['url']."\n\n" .
							"Les identifiants vous permettant de vous connecter au système sont les suivants :\n\n" .
							"\tPseudonyme : ".$pseudo."\n" .
							"\tMot de passe : ".$password."\n" .
							"\tNiveau : ".type_compte($niveau,STD)."\n\n" .
							"La modification de vos identifiants est possible via les options de votre compte." ;
		
		envoi_mail( $mail , "Vos identifiants" , $message , TRUE ) ;
		
		// Retour
		
		return select_max_sql( "Web" , "IDWeb" ) ;
	}

	// > Gestion des erreurs
	
	function erreur( $id_erreur )
	{
		/*	[Description]
		 *		Cette fonction remplace les variables de contenu par un message d'erreur défini en variable de configuration.
		 *	[Arguments]
		 *		$id_erreur			> Identifiant de l'erreur (voir : config.php)
		 *	[Retours]
		 *		$retour[]			> Variable de contenu									*/
		 
		global $erreur ; 
		
		if( empty( $erreur[$id_erreur]['message'] ) || empty( $erreur[$id_erreur]['titre'] ) )
		{
			f_erreur( 1 , 'fonctions.php' , 4 , 'Erreur in [erreur('.$id_erreur.')] : ID non-d&eacute;fini' ) ;
		}
		else
		{
			$retour['titre']		=	$erreur[$id_erreur]['titre'] ;
			$retour['principal']	=	$erreur[$id_erreur]['message'] ;
																			return $retour ;
		}
	}
	function e_erreur( $id )
	{
		/*	[Description]
		 *		Cette fonction enregistre une erreur dans le tableau correspondant.
		 *	[Arguments]
		 *		$id				> Identifiant de l'erreur (voir : config.php)			
		 *	[Notes]
		 *		La fonction retourne FALSE.							*/

		 global $erreur ;
		 global $contenu ;
		 
		 $erreur[$id]['etat'] 		= TRUE ;
		 $contenu['erreur']			= TRUE ;
		 
		 return FALSE ;
	}	
	function f_erreur( $id , $file , $niveau , $commentaire )
	{
		/*	[Description]
		 *		Cette fonction interrompt l'exécution du script pour afficher une erreur fatale.
		 *	[Arguments]
		 *		$id					> Numéro de l'erreur
		 *		$file				> Fichier ayant retourné l'erreur
		 *		$niveau				> Niveau de l'erreur
		 *		$commentaire		> Commentaire sur l'erreur
		 *	[Listing par $niveau]
		 *		1					> Erreur mineure (panne temporaire sans conséquences)
		 *		2					> Erreur moyenne (panne temporaire, conséquences possibles)
		 *		3					> Erreur majeure (panne temporaire, conséquences certaines)
		 *		4					> Erreur grave (panne permanente, nécessité d'intervention du webmaster)
		 *	[Listing par $id]
		 *		1					> Erreur inconnue
		 *		2					> Erreur lors de la connection au serveur SQL
		 *		3					> Erreur lors de la sélection de la BDD						
		 *		4					> Erreur lors de la tentative de login
		 *		5					> Erreur lors de la tentative de lecture d'informations dans la BDD
		 *		6					> Erreur lors de l'exécution du script (pas de contenu)  
		 *		7					> Erreur lors de l'ouverture de l'entrée journal (obsolète)
		 *		8					> Erreur lors de la recherche du maximum				
		 *		9					> Erreur lors de la fermeture de l'entrée journal (obsolète)	
		 *		10					> Erreur lors de l'insertion d'un commentaire (obsolète)		
		 *		11					> Erreur lors de l'exécution d'une commande SQL libre		
		 *		12					> Erreur lors de l'envoi d'un mail				
		 *		13					> Erreur lors de l'insertion				
		 *		14					> Erreur lors de la restauration du mot de passe (sécurité) 
		 *		15					> Erreur lors de la restauration du mot de passe (SQL) (obsolète) 		
		 *		16					> Erreur lors de la mise à jour des identifiants du compte personnel (obsolète)
		 *		17					> Erreur lors du décompte du nombre d'entrées dans la base SQL (obsolète) 
		 *		18					> Erreur lors de la suppression du comité				
		 *		19					> Erreur lors du décodage d'une date 					
		 *		20					> Fichier de génération PDF introuvable		
		 *		21					> Bénévole déjà associé à un compte courant					
		 *		22					> Erreur d'argument	lors de la création d'un compte		
		 *		23					> Erreur lors de la recherche des bénévoles élisibles			
		 *		24					> Erreur lors de l'insertion du nouveau comité			
		 *		25					> Sélection pour modification/suppression/aperçu incorrecte (générique)  
		 *		26					> Erreur lors de l'update						
		 *		27					> Erreur lors de la mise à jour du profil bénévole		
		 *		28					> Erreur lors de la suppression					
		 *		29					> Bénévole invalide pour l'exclusion					
		 *		30					> Bénévole invalide pour inclusion						
		 *		31					> Lot de coupons-repas invalide
		 *		32					> Fiche bénévole invalide pour création/modification de compte		
		 *		33					> Comité inexistant (suppression courante)				
		 *		34					> Erreur lors de l'upload d'une photo			
		 *		35					> Impossible de se connecter au serveur FTP				
		 *		36					> Compte invalide										*/
		 	
		$return = 'BOARRRRR ERREUR FATALE !!!!<br>BLOU SCRINE OFE DESSE !!!!<br>Encore de ta faute, glandeur ! travaille plus vite ! je m\'appel Bob<br> : '.$id.' - '.$file.' - '.$niveau.' - '.$commentaire ;
		fl_journal( "Erreur fatale : ID[".$id."]-Fichier[".$file."]-Niveau[".$niveau."]-Commentaire[".$commentaire."]") ;
		die( $return ) ;
	}
	function niveau_securite( $lvl , $mode = LIGHT )
	{
		/*	[Description]
		 *		Cette fonction vérifie le niveau de l'utilisateur pré-loggué.
		 *	[Arguments]
		 *		$lvl				> Niveau de sécurité requis			
		 *		$mode				> Mode de gestion (LIGHT/STRICT)			*/
		 
		if( $lvl > $_SESSION['NiveauA'] && $mode == LIGHT )
		{
		 	e_erreur(2);
		}
		if( $lvl != $_SESSION['NiveauA'] && $mode == STRICT && $lvl == 1 )
		{
			e_erreur(17) ;
		}
		if( $lvl != $_SESSION['NiveauA'] && $mode == STRICT )
		{
			e_erreur(2) ;
		}
	}
	function is_e()
	{
		global $contenu ;
		
		if( $contenu['erreur'] )								return TRUE ;
		else													return FALSE ;
	}
	
	// > SQL
	
	function connection_sql()
	{
		/*	[Description]
		 *		Cette fonction ouvre une connection standard avec le serveur SQL.
		 *	[Retours]
		 *		$connection_id[]			> Identifiant de la connection						*/
		 
		global $sql ; 
		
		if( !$connection_id = mysql_connect( $sql['serveur'] , $sql['login'] , $sql['password'] ) )
		{
			f_erreur( 2 , 'fonctions.php' , 1 , 'Connection au serveur SQL impossible - Erreur : '.mysql_error() ) ;
		}
		if( !mysql_select_db( $sql['bdd'] ) )
		{
			f_erreur( 3 , 'fonctions.php' , 4 , 'Connection à la BDD ['.$sql['bdd'].'] impossible' ) ;
		}
																	
																		return $connection_id ;
	}
	function deconnection_sql( $cid )
	{
		/*	[Description]
		 *		Cette fonction ferme la connection avec le serveur SQL.
		 *	[Retours]
		 *		$connection_id[]			> Identifiant de la connection						*/
		
		mysql_close( $cid ) ;
	}
	function select_sql( $bdd , $filtres = '1' , $resultats = '*' , $add = '' , $mem_pdf = FALSE )
	{
		/*	[Description]
		 *		Cette fonction effectue une recherche sur la BDD et renvoie les résultats sous forme préformatée.
		 *	[Arguments]
		 *		$bdd						> Nom de la BDD
		 *		$filtres					> Filtres à appliquer à la recherche (texte suivant le mot-clef WHERE)
		 *		$resultats					> Liste des attribus à renvoyer
		 *		$add						> Supplément à rajouter en fin de commande
		 *		$mem_pdf					> Mise en mémoire pour usage PDF
		 *	[Retours]
		 *		$result[][]					> Résultats triés (dimension 1 : n° de ligne / dimension 2 : nom de l'attribut)					
		 *		$result['nbr']				> Nombre de lignes renvoyées
		 *		$result['requete']			> Requête SQL brute soumise													*/
		
		$result = FALSE ;
		 
		$cid = connection_sql() ;
		 
		$requete 	= 'SELECT '.$resultats.' FROM '.$bdd.' WHERE '.$filtres.' '.$add ;
		if( !$res = mysql_query( $requete ) )
		{
			f_erreur( 5 , 'fonctions.php' , 2 , 'Erreur SQL in ['.$requete.']' ) ;
		}
		for( $i = 0 ; $tmp = mysql_fetch_array( $res , MYSQL_BOTH ) ; $i++ )
		{
			if( $i == 0 )
			{
				$result = $tmp ;
			}
			$result[$i] = $tmp ;
		}
		$result['nbr'] 		= $i ;
		$result['requete']	= $requete ;
		
		deconnection_sql($cid) ;
		
		if( $mem_pdf )							$_SESSION['RequetePDF'] = $result ;
		
		return $result ;
	}
	function insert_sql( $bdd , $in )
	{
		/*	[Description]
		 *		Cette fonction effectue une insertion sur la BDD et renvoie les résultats sous forme préformatée.
		 *	[Arguments]
		 *		$bdd						> Nom de la BDD
		 *		$in[][]						> Valeurs à insérer (dimension 1 : numéro / dimension 2 : attribut-valeur-char/int)
		 *	[Retours]
		 *		$resultat					> Commande SQL soumise				
		 *	[Notes]
		 *		La fonction retourne une erreur fatale en cas d'échec lors de l'insertion. */
		
		$debut 	= 	"INSERT INTO `".$bdd."` (" ;
		$fin	=	"VALUES (" ;
		
		for( $i = 0 ; $in[$i][0] != '' ; $i++ )
		{
			$debut 	.= 	"`".$in[$i][0]."`" ;
			
			if( !$in[$i][2] )						$fin	.= 	$in[$i][1] ;
			else									$fin	.=	"'".$in[$i][1]."'" ;
			
			if( isset( $in[$i+1] ) )
			{
				$debut	.=	" , " ;
				$fin	.=	" , " ;
			}
		}
		
		$debut	.=	") " ;
		$fin	.=	");" ;
		
		$requete = $debut . $fin ;
			
		$tmp = connection_sql() ;
		
		if( !mysql_query( $requete) )
		{
			f_erreur( 13 , "fonctions.php" , 4 , 'Erreur SQL in ['.$requete.']' ) ;
		}
		
		deconnection_sql( $tmp ) ;
		
		return $requete ;
	}
	function update_sql( $bdd , $in , $filtres = '1' , $add = 'LIMIT 1' )
	{
		/*	[Description]
		 *		Cette fonction effectue une opération de mise à jour sur sur le serveur.
		 *	[Arguments]
		 *		$bdd						> Base de données visée par l'update
		 *		$in[][]						> Valeurs à modifier (dimension 1 : numéro / dimension 2 : attribut-valeur-char/int)
		 *		$filtres					> Filtres à appliquer sur la mise à jour
		 *		$add						> Supplément à rajouter en fin de commande 
		 *	[Retours]
		 *		$query						> Commande envoyée au serveur					
		 *	[Notes]
		 *		L'argument $in[][2] doit être initialisé à TRUE en cas de chaîne de caractère.			*/
		 
		$requete = "UPDATE `".$bdd."` SET " ;
		
		for( $i = 0 ; isset( $in[$i] ) ; $i++ )
		{
			$requete .= "`".$in[$i][0]."` = " ;
			
			if( $in[$i][2] )					$requete .= "'".$in[$i][1]."'" ;
			else								$requete .= $in[$i][1] ;
			
			if( isset( $in[$i+1] ) )
			{
				$requete .= " , " ;
			}
		}
		
		$requete .= " WHERE ".$filtres." ".$add ;
		
		$tmp = connection_sql() ;
	
		if( !mysql_query( $requete ) )
		{
			f_erreur( 26 , "fonctions.php" , 4 , "Erreur SQL in [".$requete."]" ) ;
		}
	
		deconnection_sql( $tmp ) ;
		
		return $requete ;
	}
	function delete_sql( $bdd , $filtres , $limit = 1 )
	{
		/*	[Description]
		 *		Cette fonction permet la suppression d'une entrée de la base de donnée.
		 *	[Arguments]
		 *		$bdd						> Base de données concernée
		 *		$filtres					> Filtres à appliquer sur la suppression
		 *		$limit						> Nombre maximum de suppressions
		 *	[Retours]
		 *		$requete					> Requête envoyée au serveur						*/
		 
		$requete = "DELETE FROM `".$bdd."` WHERE ".$filtres." LIMIT ".$limit ;
		
		$tmp = connection_sql() ;
		
		if( !mysql_query( $requete ) )
		{
			f_erreur( 28 , "fonctions.php" , 1 , "Erreur SQL in [".$requete."]" ) ;
		}
		
		deconnection_sql($tmp) ;
		
		return $requete ;
	}
	function select_free_sql( $commande )
	{
		/*	[Description]
		 *		Cette fonction permet de raccourcir les opérations permettant une commande "SELECT" SQL.
		 *	[Arguments]
		 *		$commande					> Commande SQL de type SELECT
		 *	[Retours]
		 *		$result[][]					> Résultats obtenus après tri par mysql_fetch_array()		*/
		 
		$tmp = connection_sql() ;
		
		if( !$resultat = mysql_query( $commande ) )
		{
			f_erreur( 11 , 'fonctions.php' , 4 , 'Erreur SQL in ['.$commande.']' ) ;
		}
		
		deconnection_sql( $tmp ) ;
		
		return mysql_fetch_array( $resultat , MYSQL_BOTH ) ;
	}
	function select_max_sql( $bdd , $champ , $filtres = '1' , $add = '' )
	{
		/*	[Description]
		 *		Cette fonction recherche un maximum dans une BDD.
		 *	[Arguments]
		 *		$bdd						> Nom de la BDD
		 *		$champ						> Attribut appelé
		 *		$filtres					> Filtres à appliquer au tri
		 *		$add						> Suffixes de fin de ligne de commande
		 *	[Retours]
		 *		$max						> Valeur maximale détectée						*/
		 
		$tmp = connection_sql();
		
		$requete = "SELECT max(".$champ.") AS max FROM ".$bdd." WHERE ".$filtres." ".$add ;
		
		if( !$resultat = mysql_query( $requete ) )
		{
			f_erreur( 8 , 'fonctions.php' , 2 , 'Erreur SQL in ['.$requete.']' ) ;
		}
		$retour = mysql_fetch_array( $resultat ) ;
		
		deconnection_sql( $tmp );
		
		return $retour['max'] ;
	}
	function denombrer_sql( $bdd , $filtres = "1" )
	{
		/*	[Description]
		 *		Cette fonction dénombre les entrées dans l'une des bases de données du système.
		 *	[Arguments]
		 *		$bdd						> Nom de la BDD
		 *		$filtres					> Filtres à appliquer sur le décompte
		 *	[Retours]
		 *		$result						> Nombre d'entrées						*/
		 
		$resultat = select_sql( $bdd , $filtres ) ;

		return $resultat['nbr'] ;
	}
	function date_sql( $special = STD )
	{
		/*	[Description]
		 *		Cette fonction retourne la date courante sous deux formes.
		 *	[Arguments]
		 *		$special					> Attribut particulier à appliquer sur la date
		 *	[Retours]
		 *		$result['sql']				> Date au format SQL						
		 *		$result['txt']				> Date au format littéral					*/
		 
		if( $special == STD )
		{
			$result['sql'] = date( "Y-m-d" ) ;
			$result['txt'] = html_date( $result['sql'] ) ;
		}
		if( $special == TEST_18 )
		{
			$annee 	= date( "Y" ) - 18 ;
			$mois	= date( "m" ) ;
			$jour	= date( "d" ) ;
			
			$result['sql'] = $annee."-".$mois."-".$jour ;
			$result['txt'] = html_date( $result['sql'] ) ;
		}
		
		return $result ;
	}
	function validation_sql( $bdd , $attribut , $valeur = 1 )
	{
		/*	[Description]
		 *		Cette fonction recherche une valeur unique pour un attribut donné au sein d'une base de données.
		 *	[Arguments]
		 *		$bdd						> Nom de la BDD
		 *		$attribut					> Attribut concerné par la recherche
		 *		$valeur						> Valeur à rechercher pour l'attribut
		 *	[Retours]
		 *		$resultat					> Réponse de la recherche (bouléen)							
		 *	[Notes]
		 *		La fonction prend en compte l'éventualité d'un argument vide.			*/
		
		if( ( is_string( $valeur ) || empty( $valeur ) ) && substr( $valeur , 0 , 1 ) != "'" )					$valeur = "'".$valeur."'" ;
		
		$tmp = select_sql( $bdd , $attribut."=".$valeur ) ;
		
		if( $tmp['nbr'] != 0 )											return TRUE ;
																		return FALSE ;
	}

	// > HTML
	
	function lk( $texte , $destination , $blank = FALSE , $args = '' , $img = FALSE , $comment = FALSE )
	{
		/*	[Description]
		 *		Cette fonction génère un lien pré-formaté
		 *	[Arguments]
		 *		$texte						> Texte renvoyé
		 *		$destination				> Nom du script destination
		 *		$blank						> Ouverture dans une nouvelle page
		 *		$args						> Arguments supplémentaires en URL
		 *	[Retours]
		 *		$link[]						> Code HTML du lien retourné						
		 *	[Notes]
		 *		La fonction renvoie NULL en cas d'argument texte ou destination vide. 		*/
		 
		global $global ;
		global $folder ;
		 
		if( empty( $texte ) || empty( $destination ) )					return NULL ;
		 
		if( $blank )						$temp = 'target="_blank"' ;
		 
		$link = '<a href="http://'.$global['url'].'?in='.$destination.'&'.$args.'" '.$temp.'>'.$texte.'</a>' ;
		 
		if( $img )
		{
		 	$link = '<p>' .
		 				'<blockquote>' .
		 					'<table cellspacing="0">' .
		 						'<tr valign="middle">' .
		 							'<td width="80">' .
		 								'<p><a href="http://'.$global['url'].'?in='.$destination.'&'.$args.'" '.$temp.'><img border="0" src="'.$folder['picts'].$img.'"></a></p>' .
		 							'</td>' .
		 							'<td>' .
		 								'<p><font size="+1"><strong>'.$link.'</strong></font></p>' ;
		 								
		 	if( $comment )
		 	{
		 		$link .=				'<p><font size="-1">'.$comment.'</font></p>' ;
		 	}				
		 								
		 	$link .=				'</td>' .
		 						'</tr>' .
		 					'</table>' .
		 				'</blockquote>' .
		 			'</p>' ;
		}
		 
		return $link ;
	}
	function lk_pdf( $pdf_file , $middle = FALSE , $add = "" )
	{
		/*	[Description]
		 *		Cette fonction génère un lien pré-formaté
		 *	[Arguments]
		 *		$pdf_file					> Nom restreint du fichier PDF
		 *		$middle						> Centrer le lien
		 *		$add						> Variables d'URL complémentaires
		 *	[Retours]
		 *		$html						> Lien au format HTML vers le fichier PDF			*/
		 
		global $folder ;
		 
		$lk = lk( '<img src="'.$folder['picts'].'iconepdf.png" border="0">' , $_GET['in'] , TRUE , "pdf=".$pdf_file."&".$add ) ;
		
		if( $middle )
		{
			$retour = '<blockquote><div align="center">'.$lk.'</div></blockquote>' ;
		}
		else
		{
			$retour = $lk ;
		}
		 
		return $retour ;
	}
	function liste( $contenu , $infos , $nbr_colonnes , $taille_ligne = 50 , $page = 1 , $cliste = -1 )
	{
		/*	[Description]
		 *		Cette fonction génère une liste pré-formatée.
		 *	[Arguments]
		 *		$contenu					> Contenu complet (non-coupé) du tableau
		 *		$infos						> Informations sur le tableau
		 *		$nbr_colonnes				> Nombre de colonnes au tableau
		 *		$taille_ligne				> Hauteur d'une ligne
		 *		$page						> Page par défaut
		 *		$cliste						> Nombre de résultats affichés par page
		 *	[Retours]
		 *		$html						> Tableau formaté								
		 *	[Notes]
		 *		Le tableau garde en mémoire le contenu passé lors de son premier appel pour un réaffichage
		 *		ultérieur.								*/
		 
		global $misc ; 
		
		// Test du contenu
		
		if( !isset( $contenu[0] ) )
		{
			return '<blockquote><p><em>'.$misc['message_listev'].'</em></p></blockquote>' ;
		}
		
		// Définition de la page en cours
		
		if( !appel_liste() )
		{
			$afficher_page	= $page ;
			$_SESSION['SaveList'][$_GET['in']] = $contenu ;
			$_SESSION['SaveHead'][$_GET['in']] = $infos ;
		}
		if( isset( $_GET['page_c'] ) )
		{
			$afficher_page	= $_GET['page_c'] ;
			$contenu = $_SESSION['SaveList'][$_GET['in']] ;
			$infos = $_SESSION['SaveHead'][$_GET['in']] ;
		}
		if( isset( $_POST['page_c'] ) )
		{
			$afficher_page	= $_POST['page_c'] ;
			$contenu = $_SESSION['SaveList'][$_GET['in']] ;
			$infos = $_SESSION['SaveHead'][$_GET['in']] ;
		}
		
		// Prise en compte du nombre de résultats
		
		if( $cliste == -1 )				$cliste = $misc['cliste'] ;
		
		// Décompte du nombre d'entrées
		
		for( $nbr_entrees = 0 ; isset( $contenu[$nbr_entrees] ) ; $nbr_entrees++ ) ;
		
		// Prise en compte de la sélection
		
		if( isset( $_GET['select_c'] ) )				$selection = $_GET['select_c'] ;
		else											$selection = -1 ; ;
		
		if( $selection != -1 )
		{
			$afficher_page = ceil( ( $selection + 1 ) / $cliste ) ;
		}
		
		// Recherche du nombre de pages
		
		$nbr_pages 		= ceil( $nbr_entrees / $cliste ) ;
		
		// Validation de la page demandée
		
		if( $afficher_page < 0 || $afficher_page > $nbr_pages )
		{
			e_erreur(8) ;
		}
		
		// Recherche des entrées à envoyer
		
		$debut_renvois	= ( $afficher_page - 1 ) * $cliste ;
		$fin_renvois	= $afficher_page * $cliste ;
		
		if( $fin_renvois > $nbr_entrees )
		{
			$fin_renvois = $nbr_entrees ;
		}
		
		// Définition des liens
		
		if( $afficher_page == 1 )				$lk_back = "" ;
		else									$lk_back = lk( '<font color="#DDDDDD"><strong><<<</strong></font>' , $_GET['in'] , FALSE , "page_c=".($afficher_page-1)."&select_c=".$selection ) ;
		if( $afficher_page == $nbr_pages )		$lk_next = "" ;
		else									$lk_next = lk( '<font color="#DDDDDD"><strong>>>></strong></font>' , $_GET['in'] , FALSE , "page_c=".($afficher_page+1) ) ;

		// Définition du formulaire
		
		$formulaire = '<form method="post" action="?in='.$_GET['in'].'">' .
						'<select name="page_c">' ;
						
		for( $i = 0 ; $i < $nbr_pages ; $i++ )
		{
			if( $afficher_page == ($i+1) )					$add = "selected" ;
			else											$add = "" ;
			
			$formulaire	.=	'<option value="'.($i+1).'" '.$add.'>Page '.($i+1).' / '.$nbr_pages.'</option>';
		}
		
		$formulaire.= '</select><input type="submit" value="Afficher">' .
						'</form>' ;

		// Définition du tableau
		
		if( $selection != -1 )
		{
			$bottom = lk( '<strong><font color="#DDDDDD">D&eacute;s&eacute;lectionner</font></strong>' , $_GET['in'] , FALSE , "page_c=".$afficher_page , 'deselectionner.png' , '<font color="#DDDDDD">Cliquez ici pour retourner &agrave; la liste compl&egrave;te.</font>' ) ;
		}
		else
		{
			$bottom = 	'<table border="0">' .
							'<tr height="20"><p>' .
								'<td width="100">' . $lk_back . '</td>' .
								'<td width="250">' . $formulaire . '</td>' .
								'<td width="100">' . $lk_next . '</td>' .
							'</tr>' .
						'</table>' ;
		}

		// Définition de la première ligne
		
		$html	.=	'<p><br>' .
						'<table bgcolor="#999999" width="100%" border="0" cellpadding="3" cellspacing="1">' .
							'<tr bgcolor="#999999" height="40" align="center" valign="center">' ;
		
		for( $i = 0 ; $i < $nbr_colonnes ; $i++ )
		{
			if( isset( $infos['taille'][$i] ) )				$tmp = 'width="'.$infos['taille'][$i].'"' ;
			else											$tmp = '' ;
			
			$html .= '<th '.$tmp.'><font color="#DDDDDD">'.$infos['titre'][$i].'</font></th>' ;
		}
		
		$html	.= '</tr>' ;
		
		// Définition des lignes suivantes
		
		for( $l = $debut_renvois ; $l < $fin_renvois ; $l++ )
		{
			if( $l == $selection )
			{
				$tmp_bg 	= "#96e046" ;
			}
			else $tmp_bg	= "#CCCCCC" ;
			
			$html .= '<tr height="'.$taille_ligne.'" bgcolor="'.$tmp_bg.'" align="center" valign="center">' ;
			
			for( $c = 0 ; $c < $nbr_colonnes ; $c++ )
			{
				$html .= '<td>'.$contenu[$l][$c].'</td>' ;
			}
			
			$html .= '</tr>' ;
		}
		
		// Définition du bas de tableau
		
		$html .= '<tr bgcolor="#999999" height="30" align="center" valign="center">' .
					'<td colspan="'.$nbr_colonnes.'"><font color="#DDDDDD">' .
						$bottom .
					'</font></td>' .
				'</table><br></p>' ;
				
		// Renvoi
		
		return $html ;
	}
	function html_photo( $bid )
	{
		/*	[Description]
		 *		Cette fonction retourne le code HTML permettant l'affichage de la photographie bénévole.
		 *	[Arguments]
		 *		$bid						> ID de l'utilisateur souhaité
		 *	[Retours]
		 *		$html						> Balise image de l'utilisateur
		 *	[Note]
		 *		La fonction renvoie l'adresse du fichier par défaut en cas de photographie introuvable.	*/
		 
		global $misc ;
		global $folder ;

		$tmp = select_sql( "Benevole" , "IDBenevole = ".$bid , "Photo,Statut"  ) ;
		
		$chemin = $tmp['Photo'] ;
		$defaut = $folder['photos'].$misc['photo_defaut'] ;
		
		if( !file_exists( $chemin ) || empty( $tmp['Photo']) || ( !$tmp['Statut'] && !voir_confidentiel($bid) ) )		
		{
			return '<img src="'.$defaut.'" border="2">' ;
		}
		else														return '<img src="'.$chemin.'" border="2">' ;
	}
	function html_date( $date , $pdf_mode = FALSE )
	{
		/*	[Description]
		 *		Cette fonction effectue la conversion d'une date au format "date" SQL vers une forme litérale.
		 *	[Arguments]
		 *		$date						> Date à convertir
		 *		$pdf_mode					> Type de données à retourner (si vrai, accents ASCII)
		 *	[Retours]
		 *		$html						> Date litérale
		 *	[Note]
		 *		La fonction teste le contenu de la date via la fonction vide()					*/
		 
		$tmp = vide( $date ) ;
		
		if( $tmp != $date && !$pdf_mode )														return $tmp ;
		if( $tmp != $date && $pdf_mode )														return NULL ;
		if( substr($date,4,1) != '-' || substr($date,7,1) != '-' )								return $date ;
		
		$annee	= substr( $date , 0 , 4 ) ;
		$mois	= substr( $date , 5 , 2 ) ;
		$jour	= substr( $date , 8 , 2 ) ;
		
		if( !checkdate( $mois , $jour , $annee ) )
		{
			f_erreur( 19 , "fonctions.php" , 4 , "Erreur in date(".$date.")" ) ;
		}
		
		if( !$pdf_mode )
		{
			if( $mois == 1 )			$mois = "Janvier" ;
			if( $mois == 2 )			$mois = "F&eacute;vrier" ;
			if( $mois == 3 )			$mois = "Mars" ;
			if( $mois == 4 )			$mois = "Avril" ;
			if( $mois == 5 )			$mois = "Mai" ;
			if( $mois == 6 )			$mois = "Juin" ;
			if( $mois == 7 )			$mois = "Juillet" ;
			if( $mois == 8 )			$mois = "Ao&ucirc;t" ;
			if( $mois == 9 )			$mois = "Septembre" ;
			if( $mois == 10 )			$mois = "Octobre" ;	
			if( $mois == 11 )			$mois = "Novembre" ;
			if( $mois == 12 )			$mois = "D&eacute;cembre" ;
		}
		else
		{
			if( $mois == 1 )			$mois = "JANVIER" ;
			if( $mois == 2 )			$mois = "FEVRIER" ;
			if( $mois == 3 )			$mois = "MARS" ;
			if( $mois == 4 )			$mois = "AVRIL" ;
			if( $mois == 5 )			$mois = "MAI" ;
			if( $mois == 6 )			$mois = "JUIN" ;
			if( $mois == 7 )			$mois = "JUILLET" ;
			if( $mois == 8 )			$mois = "AOUT" ;
			if( $mois == 9 )			$mois = "SEPTEMBRE" ;
			if( $mois == 10 )			$mois = "OCTOBRE" ;	
			if( $mois == 11 )			$mois = "NOVEMBRE" ;
			if( $mois == 12 )			$mois = "DECEMBRE" ;
		}
		
														return $jour." ".$mois." ".$annee ;
	}
	function html_yesno( $boolean )
	{
		/*	[Description]
		 *		Cette fonction effectue la conversion d'un entier bouléen vers une forme litérale.
		 *	[Arguments]
		 *		$boolean					> Bouléen à convertir
		 *	[Retours]
		 *		$html						> Forme littérale						*/
		 
		if( $boolean )						return "oui" ;
											return "non" ;
	}
	function html_button( $texte , $img , $comment = FALSE )
	{
		global $folder ;
		
		$return = 
				'<table cellspacing="10">' .
					'<tr valign="middle">' .
						'<td>' .
							'<input type="image" src="'.$folder['picts'].$img.'"  border="0" name="submit" alt="Cliquez ici pour ['.$texte.']">' .
						'</td>' .
						'<td>' .
							'<p><font size="+1" color="#444444"><strong>'.$texte.'</strong></font></p>' ;
					
		if( $comment )
		{
			$return .=		'<p><font size="-1"> '.$comment.'</font></p>' ;
		}
							
							
		$return .=		'</td>' .
					'</tr>' .
				'</table>' ;
				
		return $return ;
	}
	function type_compte( $lvl , $mode = HTML )
	{
		/*	[Description]
		 *		Cette fonction retourne le niveau d'autorisation d'un compte sous sa forme litérale.
		 *	[Arguments]
		 *		$lvl				> Niveau numérique
		 *		$mode				> Mode de renvoi (HTML/Standart)
		 *	[Retours]
		 *		$html				> Forme litérale							*/
		
		if( $mode == HTML )
		{
			if( $lvl == 1 )										return 'Utilisateur' ;
			if( $lvl == 2 )										return 'Mod&eacute;rateur' ;
			if( $lvl == 3 )										return 'Administrateur' ;
			if( $lvl == 4 )										return 'root' ;
			else												return 'Visiteur' ;
		}
		if( $mode == STD )
		{
			if( $lvl == 1 )										return 'Utilisateur' ;
			if( $lvl == 2 )										return 'Modérateur' ;
			if( $lvl == 3 )										return 'Administrateur' ;
			if( $lvl == 4 )										return 'root' ;
			else												return 'Visiteur' ;
		}
	}
	function ok()
	{
		return '<div align="center"><strong>'.lk('OK',$_GET['in'],FALSE).'</strong></div>' ;
	}

	// > Indexation des actions
	
	function nl_journal()
	{
		/*	[Description]
		 *		Cette fonction ouvre une entrée dans le journal système.
		 *	[Retours]
		 *		$id							> ID de l'entrée insérée						
		 *	[Note]
		 *		La fonction renvoie FALSE si l'utilisateur courant est de statut visiteur.		*/
		
		if( $_SESSION['NiveauA'] == 0 )
		{
			$_SESSION['IDJournal'] = -1 ;
			return FALSE ;
		}
		
		$on[0] = array( "IDWeb" , $_SESSION['UID'] , FALSE ) ;
		$on[1] = array( "Script" , $_GET['in'] , TRUE ) ;
		
		insert_sql( "Journal" , $on );
		
				$_SESSION['IDJournal'] = select_max_sql( "Journal" , "IDIndex" ) ;
		return 	$_SESSION['IDJournal'] ;
	}
	function fl_journal( $resultat )
	{
		/*	[Description]
		 *		Cette fonction clos l'entrée courante dans le journal système.
		 *	[Arguments]
		 *		$resultat					> Résultat à indiquer				
		 *	[Note]
		 *		La fonction renvoie FALSE si l'utilisateur courant est de statut visiteur.		*/
		
		if( $_SESSION['IDJournal'] == -1 )								return FALSE ;
		
		$resultat	= stripslashes( $resultat ) ;
		
		$search 	= array ("@'@");
		$replace 	= array ("\'");
		$resultat 	= preg_replace($search, $replace, $resultat);
		
		$on[0] = array( "Retour" , $resultat , TRUE ) ;
		
		update_sql( "Journal" , $on , "IDIndex = ".$_SESSION['IDJournal'] ) ;
		
		return TRUE ;
	}
	function journal( $insert )
	{
		/*	[Description]
		 *		Cette fonction ajoute un commentaire dans l'entrée courante du journal système.
		 *	[Arguments]
		 *		$insert					> Commentaire à ajouter							
		 *	[Note]
		 *		La fonction renvoie FALSE si l'utilisateur courant est de statut visiteur.		*/
		
		if( $_SESSION['IDJournal'] == -1 )								return FALSE ;
		
		$insert		= stripslashes( $insert ) ;
		
		$search 	= array ("@'@");
		$replace 	= array ("\'");
		$insert 	= preg_replace($search, $replace, $insert);
		
		$infos 			= select_sql( 'Journal' , 'IDIndex = '.$_SESSION['IDJournal'] );
		$commentaire 	= $infos["Commentaires"].chr(13).'#'.$insert ;
				
		$on[0] = array( "Commentaires" , $commentaire , TRUE ) ;
		
		update_sql( "Journal" , $on , "IDIndex = ".$_SESSION['IDJournal'] ) ;
		
		return TRUE ;
	}
	
	// > Fonctions SQL récurrentes
	
	function benevole_infos( $bid )
	{
		/*	[Description]
		 *		Cette fonction collecte les informations sur un bénévole dans la base de données.
		 *	[Arguments]
		 *		$bid							> ID du bénévole
		 *	[Retours]
		 *		$resultat[]						> Informations sur le bénévole						
		 *	[Note]
		 *		La fonction renvoie FALSE si le bénévole n'existe pas.		*/

		global $session_infos ;
		global $folder ;
		 
		if( empty( $bid ) )								return FALSE ; 
		
		$infos 		= select_sql( "Benevole" , "IDBenevole = ".$bid );
		
		if( $infos['nbr'] != 1 )						return FALSE ;
		
		$comite 	= select_sql( "Comite" , "IDComite = ".$infos[0]["IDComite"] ) ;
		$comite_s	= select_sql( "Comite" , "IDComite = ".$infos[0]["IDComiteSecondaire"] ) ;
		
		if( $infos['IDComite'] != 0 )
		{
			$rcomite	= select_sql( "Benevole" , "IDBenevole = ".web2benevole($comite[0]['IDWeb']) ) ;
		}
		
		if( $infos['IDComiteSecondaire'] != 0 )
		{
			$rcomite_s	= select_sql( "Benevole" , "IDBenevole = ".web2benevole($comite_s[0]['IDWeb']) ) ;	
		}

		$web		= select_sql( "Web" , "IDBenevole = ".$bid ) ;
		$ac			= select_sql( "CouleurAccreditation" , "IDCouleurAccreditation = ".$infos['IDCouleurAccreditation'] ) ;
		
		// Remplissage des valeurs vacantes
		
		$infos[0]['TelephoneCellulaire']	=	vide( $infos[0]['TelephoneCellulaire'] ) ;
		$infos[0]['TelephoneFixe'] 			=	vide( $infos[0]['TelephoneFixe'] ) ;
		$infos[0]['DateNaissance']			=	vide( $infos[0]['DateNaissance'] ) ;
		$infos[0]['Adresse']				=	vide( $infos[0]['Adresse'] ) ;
		$infos[0]['CodePostal']				=	vide( $infos[0]['CodePostal'] ) ;
		$infos[0]['Province']				=	vide( $infos[0]['Province'] ) ; 
		$infos[0]['Mail']					=	vide( $infos[0]['Mail'] ) ;
		
		if( $infos[0]['Sexe'] )				$infos[0]['Sexe'] = "madame" ;
		else								$infos[0]['Sexe'] = "monsieur" ;
		
		if( $infos[0]['Zone'] )				$infos[0]['ZoneL'] = "centre d'h&eacute;bergement" ;
		else								$infos[0]['ZoneL'] = "site" ;
		
		// Attribution
		
		$retour = $infos[0] ;
		$retour['Comite']	=	$comite[0] ;
		$retour['ComiteS']	=	$comite_s[0] ;
		$retour['RComite']	=	$rcomite[0] ;
		$retour['RComiteS']	=	$rcomite_s[0] ;
		$retour['Web']		=	$web[0] ;
		$retour['CA']		=	$ac[0] ;
		
		if( $retour['Web']['NiveauAutorisation'] == 1 )
		{
			$retour['Notes']['Responsable'] = TRUE ;
		}
		else
		{
			$retour['Notes']['Responsable'] = FALSE ;
		}
		
		// Définition de la barre d'informations graphiques
		
		$retour['GInfos'] = '' ;
		
		if( $retour['Sexe'] == 'madame' )							$retour['GInfos'] .= '<img src="'.$folder['picts'].'femme.png" title="Ce b&eacute;n&eacute;vole est une femme">' ;
		if( $retour['Sexe'] == 'monsieur' )							$retour['GInfos'] .= '<img src="'.$folder['picts'].'homme.png" title="Ce b&eacute;n&eacute;vole est un homme">' ;
		if( $retour['Web']['NiveauAutorisation'] == 1 )				$retour['GInfos'] .= '<img src="'.$folder['picts'].'user.png" title="Ce b&eacute;n&eacute;vole est responsable de comit&eacute;" border="0">' ;
		if( $retour['Web']['NiveauAutorisation'] == 2 )				$retour['GInfos'] .= '<img src="'.$folder['picts'].'modo.png" title="Ce b&eacute;n&eacute;vole est membre du staff" border="0">' ;
		if( $retour['Web']['NiveauAutorisation'] == 3 )				$retour['GInfos'] .= '<img src="'.$folder['picts'].'admin.png" title="Ce b&eacute;n&eacute;vole est administrateur du syst&egrave;me" border="0">' ;
		if( valider_mail( $retour['Mail'] ) )						$retour['GInfos'] .= '<img src="'.$folder['picts'].'mail_small.png" title="Ce b&eacute;n&eacute;vole dispose d\'une adresse de messagerie" border="0">' ;
		if( !$retour['Recommandable'] && voir_confidentiel( $bid ))	$retour['GInfos'] .= '<img src="'.$folder['picts'].'mort_small.png" title="Ce b&eacute;n&eacute;vole est plac&eacute; sur liste noire" border="0">' ;
		if( $retour['Photo'] != '' && $retour['Statut'] )			$retour['GInfos'] .= '<img src="'.$folder['picts'].'photo_small.png" title="Ce b&eacute;n&eacute;vole dispose d\'une photographie" border="0">' ;
		
		return $retour ;
	}
	function voir_confidentiel( $bid )
	{
		/*	[Description]
		 *		Cette fonction teste l'identité de l'utilisateur courant par rapport à un bénévole donné,
		 *		afin de déterminer si il est possible d'en divulguer les informations confidentielles.
		 *	[Arguments]
		 *		$bid							> ID du bénévole
		 *	[Retours]
		 *		$possibilite					> Réponse (booléen)					*/
		 
		global $session_infos ;
		
		$tmp = select_sql( "Benevole" , "IDBenevole = ".$bid , "IDComite" ) ;
		
		if( $session_infos['NiveauAutorisation'] > 1 )						return TRUE ;
		if( $session_infos['NiveauAutorisation'] == 0 )						return FALSE ;
		if( $session_infos['IDComite'] == $tmp[0][0] )						return TRUE ;
																			return FALSE ;
	}
	function web2benevole( $wid )
	{
		/*	[Description]
		 *		Cette fonction recherche un ID bénévole correspondant à un compte utilisateur.
		 *	[Arguments]
		 *		$wid							> ID du compte utilisateur
		 *	[Retours]
		 *		$bid							> ID du compte bénévole		
		 *	[Notes]
		 *		La fonction retourne -1 en cas d'erreur.								*/
		 
		if( !is_numeric( $wid ) )					return -1 ;
		 
		$tmp = select_sql( "Web" , "IDWeb = ".$wid ) ;

		if( $tmp['nbr'] != 1 )						return -1 ;
		else										return $tmp[0]['IDBenevole'] ;
	}
	function benevole2web( $bid )
	{
		/*	[Description]
		 *		Cette fonction recherche un ID utilisateur correspondant à un compte bénévole.
		 *	[Arguments]
		 *		$wid							> ID du compte bénévole
		 *	[Retours]
		 *		$bid							> ID du compte utilisateur		
		 *	[Notes]
		 *		La fonction retourne FALSE en cas de réponse négative								*/

		if( !is_numeric( $bid ) )					return -1 ;

		$tmp = select_sql( "Web" , "IDBenevole = ".$bid ) ;
		
		if( $tmp['nbr'] == 0 )						return FALSE ;
		else										return $tmp[0]['IDWeb'] ;
	}
	function inclure_benevole( $bid )
	{
		/*	[Description]
		 *		Cette fonction inclue un bénévole dans le comité courant.
		 *	[Arguments]
		 *		$bid							> ID du compte bénévole
		 *	[Retours]
		 *		$liste							> Liste inscrite (P:Principale - S:Secondaire) 
		 *	[Notes]
		 *		La fonction retourne FALSE en cas d'échec.										*/
		 
		$benevole = benevole_infos( $bid ) ;
		$rcomite  = session_infos() ;
		
		if( $benevole['Web']['NiveauAutorisation'] == 1 )
		{
			f_erreur( 30 , "fonctions.php" , 4 , "Inclusion impossible (responsable)" ) ;
		}
		elseif( $benevole['IDComite'] == 0 )
		{
			$on[0] = array( 'IDComite' , $rcomite['IDComite'] , FALSE ) ;
			update_sql( "Benevole" , $on , "IDBenevole = ".$bid ) ;
			return P ;
		}
		elseif( $benevole['IDComite'] != $rcomite['IDComite'] )
		{
			$on[0] = array( 'IDComiteSecondaire' , $rcomite['IDComite'] , FALSE ) ;
			update_sql( "Benevole" , $on , "IDBenevole = ".$bid ) ;
			return S ;
		}
		else
		{
			return FALSE ;
		}
	}
	function exclure_benevole( $bid , $comite = PRINCIPAL )
	{
		/*	[Description]
		 *		Cette fonction exclue un bénévole de son comité courant.
		 *	[Arguments]
		 *		$bid							> ID du compte bénévole
		 *		$comite							> Comite à effacer (PRINCIPAL ou SECONDAIRE)
		 *	[Retours]
		 *		$requete						> Requête principale effectuée sur la base de données
		 *	[Notes]
		 *		La fonction retourne FALSE en cas d'échec.										*/
		 
		global $session_infos ;
		
		$benevole = benevole_infos( $bid ) ;
		
		if( $comite == PRINCIPAL )
		{
			$on[0] = array( 'IDComite' , $benevole['IDComiteSecondaire'] , FALSE );
			$on[1] = array( 'IDComiteSecondaire' , 0 , FALSE );
		}
		elseif( $comite == SECONDAIRE )
		{
			$on[0] = array( 'IDComiteSecondaire' , 0 , FALSE ) ;
		}
		else 
		{
			return FALSE ;
		}
		
		delete_sql( "CouponRepas" , "IDWeb = ".$session_infos['IDWeb']." && Nom = '".$benevole['Nom']."' && Prenom = '".$benevole['Prenom']."'" , 2000 ) ;
		
		return update_sql( "Benevole" , $on , "IDBenevole = ".$bid ) ;
	}

	// > Fonctions diverses récurrentes
	
	function envoi_mail( $adresse , $sujet , $contenu , $no_reply = TRUE )
	{
		/*	[Description]
		 *		Cette fonction envoie un mail préformaté.
		 *	[Arguments]
		 *		$adresse						> Adresse du destinataire
		 *		$sujet							> Sujet du message
		 *		$contenu						> Contenu du message				
		 *	[Retours]
		 *		$message						> Message définitif envoyé				*/
		
		global $global ;
		global $misc ;
		
		$sujet = "[".$global['nom']."-".$global['version']."] ".$sujet ;
		
		$contenu = $contenu . "\n\nCordialement\n\n" . $misc['resp_info'] . "\n" .
				"Responsable informatique\n" .
				"Mondial des cultures de Drummondville" ;
		
		if( $no_reply )
		{
			$contenu = $contenu . "\n\nPS : ce message est automatisé, toute réponse est inutile." ;
		}
		if( !mail( $adresse , $sujet , $contenu ) )
		{
			f_erreur( 12 , "fonctions.php" , 4 , "Erreur in [mail()]") ;
		}
	}
	function vide( $variable , $mode = STD )
	{
		/*	[Description]
		 *		Cette fonction teste le contenu d'une variable pour éviter les affichages vides.
		 *	[Arguments]
		 *		$variable						> Variable à tester			
		 *	[Retours]
		 *		$variable						> Valeur à conserver				*/
		 
		global $misc ;
		
		if( $mode == STD )
		{
			if( empty( $variable ) )				return $misc['message_nul'] ;
			if( !$variable )						return $misc['message_nul'] ;
			if( $variable == "0000-00-00" )			return $misc['message_nul'] ;
		}
		if( $mode == MINIMAL )
		{
			if( empty( $variable ) )				return '-' ;
			if( !$variable )						return '-' ;
			if( $variable == "0000-00-00" )			return '-' ;
		}
		
													return $variable ;
	}
	function contenu_liste()
	{
		/*	[Description]
		 *		Cette fonction renvoie le contenu de la liste en cours.
		 *	[Retours]
		 *		$result['contenu']				> Contenu du tableau						
		 *		$result['infos']				> En-tête (informations) du tableau			*/
		 
		$result['contenu'] = $_SESSION['SaveList'] ;
		$result['infos'] = $_SESSION['SaveHead'] ;
		
		return $result ;
	}
	function appel_liste()
	{
		/*	[Description]
		 *		Cette fonction détecte un changement de page liste.
		 *	[Retours]
		 *		$resultat						> Réponse (booléen)						*/
		 
		if( isset( $_POST['page_c'] ) || isset( $_GET['page_c'] ) || isset( $_GET['select_c'] ) )
		{
			return TRUE ;
		}
			return FALSE ;
	}
	function generer_mdp()
	{
		/*	[Description]
		 *		Cette fonction génère un mot de passe aléatoire.
		 *	[Retours]
		 *		$password			> Mot de passe généré							*/
		
		global $misc ;
		
		for( $i = 0 ; $i < $misc['taille_mdp_def'] ; $i++ )
		{
			$tmp = rand( 1 , 3 ) ;
			
			if( $tmp == 1 )						$password.= chr(rand(48,57)) ;
			if( $tmp == 2 )						$password.= chr(rand(65,90)) ;
			if( $tmp == 3 )						$password.= chr(rand(97,122)) ;		
		}
		
		return $password ;
	}
	function valider_mail( $mail )
	{
		/*	[Description]
		 *		Cette fonction teste la validité synthaxique d'une adresse mail.
		 *	[Arguments]
		 *		$mail							> Adresse à tester			
		 *	[Retours]
		 *		$resultat						> Résultat du test (bouléen)				*/
		
 		$syntaxe='#^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,5}$#';
		
		if( preg_match ( $syntaxe , $mail ) )						return true;
		else														return false;
	}
	function depassee( $jour , $mois , $annee )
	{
		/*	[Description]
		 *		Cette fonction teste une date pour déterminer si celle-ci est passée ou future.
		 *	[Arguments]
		 *		$jour				> Jour
		 *		$mois				> Mois
		 *		$annee				> Année
		 *	[Retours]
		 *		$reponse			> Réponse du test (FALSE : future, TRUE : passée)			
		 *	[Notes]
		 *		La fonction retourne NULL en cas de date invalide.					*/
		 
		if( !checkdate( $mois , $jour , $annee ) )					return NULL ;
		
		if( $annee < date("Y") )									return TRUE ;
		if( $annee > date("Y") )									return FALSE ;
		else
		{
			if( $mois > date("m") )									return FALSE ;
			else
			{
				if( $jour > date("d") )								return FALSE ;
			}
		}
																	return TRUE ;
	}
	function upload( $bid , $name = FALSE )
	{
		/*	[Description]
		 *		Cette fonction permet l'upload d'une photo sur le serveur.
		 *	[Arguments]
		 *		$bid							> ID du bénévole associé à la photo	
		 *		$name							> Nom à donner au fichier
		 *	[Retours]
		 *		$resultat						> Adresse relative du fichier inscrit
		 *	[Notes]
		 *		La fonction retourne FALSE en cas d'utilisateur inexistant ou de photo invalide.
		 *		La fonction peut renvoie des erreurs utilisateurs en cas de propriétés incorrectes.
		 *		La fonction renvoie une erreur fatale en cas d'échec lors de l'upload.
		 *		La variable $_FILE['photo'] doit être définie.								*/
		 
		global $ftp ;
		global $folder ;
		global $misc ;

		if( $_FILES['photo']['tmp_name'] == '' )								return FALSE ;

		// Connexion
		
		$cid = 	ftp_connect( $ftp['serveur'] ) ;
		
		if( !ftp_login( $cid , $ftp['login'] , $ftp['password'] ) )
		{
			f_erreur( 35 , 'fonctions.php' , 4 , 'Erreur lors du login au serveur FTP' ) ;
		}

		// Suppression de l'image ultérieure
		
		$b_infos = select_sql( "Benevole" , "IDBenevole = ".$bid ) ;
		
		if( $b_infos['nbr'] != 1 )											return FALSE ;
		if( $b_infos['Photo'] ) 
		{
			if( !ftp_delete( $cid , $ftp['root'].$b_infos['Photo'] ) )		return FALSE ;
		}
		
		// Fermeture
		
		ftp_close( $cid ) ; 
		
		// Définition des raccourcis
		
		if( !$name ) 							$name = 'b'.time() ;
		
		$f_tmp_name	=	$_FILES['photo']['tmp_name'] ;
		$f_name		=	$_FILES['photo']['name'] ;
		$f_end_name	=	$folder['photos'].$name ;

		$tmp		=	getimagesize( $f_tmp_name ) ;

		$f_size		=	filesize( $f_tmp_name) ;
		$f_width	=	$tmp[0] ;
		$f_heigth	=	$tmp[1] ;
		$f_type		=	$tmp[2] ;
		
		if( $f_type == 2 )					$f_end_name .= '.jpg' ;
		if( $f_type == 3 )					$f_end_name .= '.png' ;
				
		// Tests de routine
		
		if( $f_type != 2 && $f_type != 3 )							return ERREUR_TYPE ;
		if( $f_size > ( $misc['img_maxs'] * 1000 ) )				return ERREUR_POIDS ;
		if( $f_width > $misc['img_maxw'] )							return ERREUR_LARGEUR ;
		if( $f_heigth > $misc['img_maxh'] )							return ERREUR_HAUTEUR ;
		
		// Upload
		
		if( !move_uploaded_file( $f_tmp_name , $f_end_name ) )
		{
			f_erreur( 34 , 'fonctions.php' , 4 , 'Erreur lors de l\'upload' ) ;
		}
		
		// CHMOD
		
		chmod( $f_end_name , 0755 ) ;
		
		// Retour
		
		return $f_end_name ; 
	}
	function naeloob( $x )
	{
		if( $x )	return FALSE ;
					return TRUE ;
	}

?>
