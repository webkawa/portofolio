<?php

/*	----------------------------------------------------------------
 * 	renvoi.php
 * 	----------------------------------------------------------------
 * 	[Description]
 * 		Fichier de test et d'inclusion du fichier script.
 *	----------------------------------------------------------------	*/

	$script = $folder['scripts'].$_GET['in'].'.php' ;

	// Vérification de l'erreur 404
	if( !file_exists( $script ) )
	{
		e_erreur( 404 ) ;
	}
	
	// Inclusion
	include $script ;
	
	// Inclusion du fichier PDF
	if( isset( $_GET['pdf'] ) )
	{	
		$rpdf = $folder['pdf'].$_GET['pdf'].".php" ;
		
		if( !file_exists( $rpdf ) )		f_erreur( 20 , 'script.php' , 4 , 'Appel PDF invalide pour $pdf='.$_GET['pdf'] ) ;
		else							
		{
			journal("PDF[".$rpdf."]") ;
			
			include $folder['pdf_lib'].'phpToPDF.php' ;
			include $rpdf ;
		}
	}
	
	// Validation du contenu
	if( (empty( $texte ) || empty( $titre )) && !$contenu['erreur'] )
	{
		f_erreur( 6 , 'script.php' , 4 , 'Erreur de contenu pour $in='.$_GET['in'] ) ;
	}

?>
