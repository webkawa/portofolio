import java.awt.*;
import java.io.*;
import javax.swing.*; 

class Programme
{
	public static void main( String args[] ) throws IOException
	{
		// > Variables de base
		
		ATLAS ia = new ATLAS() ;
		Echiquier colis = new Echiquier() ;
		Coup_P retour = new Coup_P() ;

		int x , y ;
		
		for( x = 0 ; x < 8 ; x++ )
		{
			for( y = 0 ; y < 8 ; y++ )
			{
				colis.tableaupiece[x][y].setcouleurandtype(false,0) ;
			}
		}
		//a chaque numero correspont un type de piece : ex:pion=1, 2=tour, 3=fou, 4=cavalier et 5=roi, 6=reine
		
		colis.tableaupiece[6][2].setcouleurandtype( false , 1 ) ;
		colis.tableaupiece[5][1].setcouleurandtype( false , 4 ) ;
		colis.tableaupiece[4][4].setcouleurandtype( false , 1 ) ;
		colis.tableaupiece[2][5].setcouleurandtype( true , 1 ) ;
		colis.tableaupiece[3][5].setcouleurandtype( true , 2 ) ;
		colis.tableaupiece[2][6].setcouleurandtype( true , 5 ) ;
		colis.tableaupiece[5][5].setcouleurandtype( false , 2 ) ;
		colis.tableaupiece[1][2].setcouleurandtype( false , 5 ) ;
		colis.tableaupiece[7][5].setcouleurandtype( true , 2 ) ;
		colis.tableaupiece[3][2].setcouleurandtype( false , 1 ) ;
		// colis.tableaupiece[3][0].setcouleurandtype( true , 6 ) ;
		
		/*
		colis.tableaupiece[2][1].setcouleurandtype( true , 6 ) ;
		colis.tableaupiece[2][5].setcouleurandtype( true , 5 ) ;
		colis.tableaupiece[3][5].setcouleurandtype( true , 1 ) ;
		colis.tableaupiece[5][4].setcouleurandtype( false , 4 ) ;
		colis.tableaupiece[7][4].setcouleurandtype( false , 5 ) ;
		colis.tableaupiece[7][5].setcouleurandtype( false , 6 ) ;
		*/
		
		/* colis.tableaupiece[0][7].setcouleurandtype(false,5) ;
		colis.tableaupiece[0][3].setcouleurandtype(true,5) ;
		colis.tableaupiece[1][4].setcouleurandtype(true,1) ; */
		
		// > Definition de l'?chiquier voulu
		
		
		
		// > Appel
		
		retour = ia.Invoquer(colis,false) ;
		
		System.out.println( "[CD : " + retour.colonne_d + "][LD : " + retour.ligne_d + "][CA : " + retour.colonne_a + "][LA : " + retour.ligne_a + "]" ) ;
	}
}

//									===== Atlas & Entites liees =====

class ATLAS
{
	MORPHEE					morphee = new MORPHEE() ;
	HERMES					hermes = new HERMES(1) ;
	DEDALE					dedale = new DEDALE( morphee ) ;
	private int 			x ;
	Coup_P					coup_critique = new Coup_P() ;
	Situation_P				situation_initiale = new Situation_P( morphee ) ;

	public ATLAS()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> Seule instruction plac�e dans le programme externe.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de l'entit� Atlas.
		 *	----------------------------------------------------------------------	*/

		hermes.Afficher("Initialisation d'Atlas") ;
		hermes.Saut_Ligne() ;
		hermes.Afficher("Validation des variables de configuration ...") ;
		for( x = 0 ; x < morphee.Get_Var(0) ; x++ )
		{
			if( morphee.Get_Var(x) != 0 )
			{
				hermes.Afficher( "[" + x + "] " + morphee.Get_VarDesc(x) + " : " + morphee.Get_Var(x) ) ;
			}
		}
		hermes.Saut_Ligne() ;
		hermes.Afficher("Fin de la validation") ;
	}
	public Coup_P Invoquer( Echiquier colis , boolean camp_maitre )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Echiquier		colis 			: derni�re situation renvoy�e par Prom�th�e
		 *				> boolean 		camp_maitre		: couleur jou�e par Atlas
		 *	[Retours]	> Coup_P		coup_critique	: coup jou� par Atlas
		 *	[Notes]		> Ex�cution de la m�thode tr�s longue
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'appeler Atlas et de lui faire g�n�rer un coup.
		 *	----------------------------------------------------------------------	*/
		
		hermes.Logo() ;
		hermes.Afficher("Lancemetotalnt du processus de recherche") ;						
		hermes.Afficher("Transcription du colis") ;
		situation_initiale	=	hermes.Transcrire_Colis( colis , camp_maitre , morphee ) ;				
		hermes.Afficher("Lancement du cycle d'etude") ;
		coup_critique = dedale.Gestion_Globale(situation_initiale) ;
		hermes.Afficher("Situation initiale definie") ;
		
		return coup_critique ;
	}
}

class HERMES
{
	int						id_process = 0 ;
	int						prefixage = 0 ;
	boolean					debug_mode = false ;		// Variable magique
	boolean					dev_mode = false ;			// Variable magique
	int						total , current ;
	
	public HERMES( int id )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> int	id	: signature num�rique locale
		 *	[Retours]	> N/A
		 *	[Notes]		> Signature unique par entit� invoqu�e
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de l'entit� Herm�s.
		 *	----------------------------------------------------------------------	*/
		
		id_process = id ;
	}
	public void Afficher( String message )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> String	message	: message � renvoyer en console
		 *	[Retours]	> N/A
		 *	[Notes]		> [dev_mode] doit �tre d�fini � TRUE
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'afficher un message sign� et mis en forme dans la console.
		 *	----------------------------------------------------------------------	*/
		
		int					i = 0 ;
		
		if( dev_mode )
		{
			System.out.print( "\n[" + id_process + "]\t: " ) ;
			while( i < prefixage )
			{
				System.out.print("  ") ;
				i++ ;
			}
			System.out.print( message ) ;
		}
		else Wait() ;
	}
	public void Saut_Ligne()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> [dev_mode] doit �tre d�fini � TRUE
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet de r�aliser un saut de plusieurs lignes clairement visible dans la console.
		 *	----------------------------------------------------------------------	*/
		
		int i ;
		
		if( dev_mode )
		{
												System.out.print("\n\n") ;
												System.out.print("\t  ") ;
			for( i = 0 ; i < 50 ; i++ )			System.out.print("-") ;
												System.out.print("\n") ;
		}
	}
	public void Console( String message )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> String	message	: message � renvoyer en console
		 *	[Retours]	> N/A
		 *	[Notes]		> [dev_mode]&&[debug_mode] doivent �tre d�finis � TRUE
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'afficher un message sign�, mis en forme et identifiable comme d�buggeur dans la console.
		 *	----------------------------------------------------------------------	*/
		
		if( debug_mode && dev_mode )
		{
			System.out.print( "\nCONSOLE > " + message ) ;
		}
	}
	public void Echo()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> Outil de d�velloppement. Non-utilis� en version finale.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'afficher la cha�ne de caract�re "[ E C H O ]" dans la console.
		 *	----------------------------------------------------------------------	*/
		
		Console( "[ E C H O ]" );
	}
	public void Logo()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> [dev_mode] doit �tre d�fini � TRUE
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'afficher un message signalant l'initialisation de l'IA.
		 *	----------------------------------------------------------------------	*/
		
		int i ;
		if( dev_mode )
		{
			for( i = 0 ; i < 100 ; i++ )				System.out.println() ;
			System.out.println("\t  ===================================================================") ;
			System.out.println("\t  ") ;
			System.out.println("\t                > A T L A S   B E T A   V E R S I O N <" ) ;
			System.out.println("\t  ") ;
			System.out.println("\t  ===================================================================") ;
			System.out.println("") ;
		}
		else
		{
			System.out.println("Execution d'Atlas. Veuillez patienter ...") ;
		}
	}
	public void Wait()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> [dev_mode] doit �tre d�fini � FALSE
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'afficher un caract�re particulier en cas de mode d�veloppement d�sactiv�.
		 *	----------------------------------------------------------------------	*/
		
		if( !dev_mode ) System.out.print("") ;
	}
	public void Wait_Long( Situation_P repere )
	{	
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Situation_P	repere : rep�re de progression
		 *	[Retours]	> N/A
		 *	[Notes]		> [dev_mode] doit �tre d�fini � FALSE
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction renvoie une estimation de la progression des calculs.
		 *	----------------------------------------------------------------------	*/
		
		int i ;
		double temp ;
		
		if( repere.degree == 0 && repere.camp == 0 && repere.id == 0 )
		{
			for( i = 0 ; repere.liste_coups[i].defini ; i++ ) ;
			total = i ;
		}
		if( repere.degree == 0 && repere.camp == 1 )
		{
			current = repere.id ;
		}
		if( !dev_mode )	
		{
			if( repere.degree == 0 && repere.camp == 1 )
			{
				temp = Math.round( ( 100 / total ) * current ) ;
				System.out.print("\t[" + temp + "%]\t" ) ;
			}
			else
			{
				System.out.print("\t\t") ;
			}
			System.out.print("| SP > [" + repere.degree + "|" + repere.camp + "|" + repere.id + "]\n" ) ;
		}
	}
	public void Ajout( String ajout )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> String	ajout	: message � ajouter en fin de ligne.
		 *	[Retours]	> N/A
		 *	[Notes]		> [dev_mode] doit �tre d�fini � TRUE
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'ajouter un message � la fin de la ligne en cours.
		 *	----------------------------------------------------------------------	*/
		
		if( dev_mode )				System.out.print( ajout ) ;
	}
	public void Infos( Situation_P base , String nom )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Situation_P	base	: �chiquier � repr�senter
		 *				> String		nom		: d�signation de l'�chiquier
		 *	[Retours]	> N/A
		 *	[Notes]		> [dev_mode] doit �tre d�fini � TRUE
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'afficher l'�tat d'un �chiquier dans la console (informations compl�tes).
		 *	----------------------------------------------------------------------	*/
		
		int x , y ;
		
		Saut_Ligne() ;
		Modifier_Prefixage( true ) ;
		Modifier_Prefixage( true ) ;
		Afficher("Detail de l'echiquier [" + nom + "] : ") ;
		Afficher("") ;
		Afficher("") ;
		Afficher("   C Types:     C Couleurs:  C Coups:     C Etudes:    C ATK: ") ;
		Afficher("   |            |            |            |            |") ;
		Afficher(" L-+-");
		for( x = 0 ; x < 8 ; x++ )				Ajout(""+x) ;
		Ajout(" L-+-") ;
		for( x = 0 ; x < 8 ; x++ )				Ajout(""+x) ;
		Ajout(" L-+-") ;
		for( x = 0 ; x < 8 ; x++ )				Ajout(""+x) ;
		Ajout(" L-+-") ;
		for( x = 0 ; x < 8 ; x++ )				Ajout(""+x) ;
		Ajout(" L-+-") ;
		for( x = 0 ; x < 8 ; x++ )				Ajout(""+x) ;
		Afficher("   |            |            |            |            |") ;
		for( x = 0 ; x < 8 ; x++ )
		{
			Afficher("   ") ;
			Ajout( x + " ") ;
			for( y = 0 ; y < 8 ; y++ )			Ajout(""+base.base_brute.gettype_piece(x,y)) ;
			Ajout("   ") ;
			Ajout( x + " ") ;
			for( y = 0 ; y < 8 ; y++ )
			{
				if( base.base_brute.gettype_piece(x,y) != 0 )
				{
					Ajout(""+Boolean2Int(base.base_brute.getcouleur_piece(x,y))) ;
				}
				else Ajout(".") ;
			}
			Ajout("   ") ;
			Ajout( x + " ") ;
			for( y = 0 ; y < 8 ; y++ )			Ajout(""+Boolean2Int(base.base_brute.getpossibilite(x,y))) ;
			Ajout("   ") ;
			Ajout( x + " ") ;
			for( y = 0 ; y < 8 ; y++ )			Ajout(""+Boolean2Int(base.echiquier[x][y].Est_Etudiee() )) ;
			Ajout("   ") ;
			Ajout( x + " ") ;
			for( y = 0 ; y < 8 ; y++ )			Ajout(""+Boolean2Int(base.base_brute.getattaquabilite(x,y))) ;
		}
		Afficher("");
		Afficher("");
		Afficher("");
		Afficher("Caracteristiques >\tPrimaires:\tSecondaires:\tDerivees:") ;
		Afficher("\t\t\t\t> AT["+base.AT+"]\t> LI["+base.LI+"]\t> PA["+base.PA+"]") ;
		Afficher("\t\t\t\t> DE["+base.DE+"]\t> OP["+base.OP+"]\t> RS["+base.RS+"]") ;
		Afficher("\t\t\t\t> RI["+base.RI+"]\t> CO["+base.CO+"]\t> PT["+base.PT+"]") ;
		Afficher("\t\t\t\t> DI["+base.DI+"]\t> PR["+base.PR+"]") ;
		Afficher("\t\t\t\t\t\t> EQ["+base.EQ+"]\t0.0:Indefini/Nul") ;
		Modifier_Prefixage( false ) ;
		Modifier_Prefixage( false ) ;
		Saut_Ligne();
		Afficher("Fin de l'affichage") ;
	}
	public void Detail_Pieces( Situation_P base )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Situation_P	base	: �chiquier � parcourir
		 *	[Retours]	> N/A
		 *	[Notes]		> [dev_mode] doit �tre d�fini � TRUE
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'afficher les facteurs de chacune des pi�ces d'un �chiquier donn�.
		 *	----------------------------------------------------------------------	*/
		
		int c , l ;
		
		Saut_Ligne();
		Modifier_Prefixage(true) ;
		Modifier_Prefixage(true) ;
		Afficher(" C-L \tType:\tCouleur:\tFP,C:\tFC,C:\tFM,C:\tFS,C:") ;
		Afficher("");
		for( c = 0 ; c < 8 ; c++ )
		{
			for( l = 0 ; l < 8 ; l++ )
			{
				if( base.Get_Type(c, l) != 0 )
				{
					Afficher("["+c+"-"+l+"]\t"+Renvoyer_Type( base.Get_Type(c,l) )+"\t"
							+Renvoyer_CM(base.base_brute.getcouleur_piece(c,l))+"\t\t "
							+base.echiquier[c][l].FP+","+base.echiquier[c][l].FP_c+"\t "
							+base.echiquier[c][l].FC+","+base.echiquier[c][l].FC_c+"\t "
							+base.echiquier[c][l].FM+","+base.echiquier[c][l].FM_c+"\t "
							+base.echiquier[c][l].FS+","+base.echiquier[c][l].FS_c) ;
				}
			}
		}
		Modifier_Prefixage(false) ;
		Modifier_Prefixage(false) ;
		Saut_Ligne();
	}
	public void Detail_PackStat( Pack_Stat base )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Pack_Stat		base : pack de statistiques � explorer.
		 *	[Retours]	> N/A
		 *	[Notes]		> [dev_mode] doit �tre d�fini � TRUE
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'afficher l'int�gralit� du contenu d'un pack de statistiques.
		 *	----------------------------------------------------------------------	*/
		
		Saut_Ligne() ;
		Afficher("Pack-Stat Watch :") ;
		Modifier_Prefixage(true) ;
		Afficher("Origine du pack  : [Degree:" + base.degree_origine + "][Camp:" + base.camp_origine + "][ID:" + base.id_origine +"]" ) ;
		Afficher("Car. primaires   : [AT:" + base.AT + "][DE:" + base.DE + "][RI:" + base.RI + "][DI:" + base.DI + "]" ) ;
		Afficher("Car. secondaires : [LI:" + base.LI + "][OP:" + base.OP + "][CO:" + base.CO + "][PR:" + base.PR + "][EQ:" + base.EQ + "]" ) ;
		Afficher("Car. derivees    : [PA:" + base.PA + "][RS:" + base.RS + "][PT:" + base.PT + "]" ) ;
		Afficher("Coeff. d'interet : " + base.coefficient_interet ) ;
		Modifier_Prefixage(false) ;
		Saut_Ligne() ;
		Afficher("Fin de l'affichage") ;
	}
	public Situation_P Transcrire_Colis( Echiquier colis , boolean maitre , MORPHEE configuration )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Echiquier		colis			: �chiquier initial brut � traduire
		 *				> boolean		maitre			: camp maitre de l'�chiquier � traduire
		 *				> MORPHEE		configuration	: variables de configuration
		 *	[Retours]	> Situation_P	s_i				: �chiquier initial traduit en situation potentielle
		 *	[Notes]		> usage unique
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet de traduire la situation initiale soumise � Atlas en une situation potentielle.
		 *	----------------------------------------------------------------------	*/
		
		Situation_P			s_i = new Situation_P( configuration ) ;
		
		Afficher("Reception du colis") ;
		Afficher("Definition de la situation initiale ...") ;
		s_i.Remplir_Echiquier( colis ) ;
		Valider(); 
		Afficher("Definition du camp maitre initial ...") ;
		s_i.Definir_CampMaitre( maitre ) ;
		Valider();
		Afficher("Fin de la definition") ;
		
		return s_i ;	
	}
	public void Valider()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> [dev_mode] doit �tre d�fini � TRUE
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction ajoute en fin de ligne la cha�ne de caract�res " [  OK  ] ".
		 *	----------------------------------------------------------------------	*/
		
		if( dev_mode )							System.out.print(" [  OK  ]") ;
	}
	public String Renvoyer_CM( boolean brut )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> boolean	brut	: couleur concern�e brute
		 *	[Retours]	> String	return 	: couleur litt�rale
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet de convertir un camp sous sa forme de bool�en vers une cha�ne de caract�res
		 *	----------------------------------------------------------------------	*/
		
		if( brut == true )			return "1.Blanc" ;
		else						return "0.Noir" ;
	}
	public String Renvoyer_Type( int i )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> int		type	: identifiant du type.
		 *	[Retours]	> String	return	: correspondance sous forme de cha�ne de caract�re.
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'obtenir sous forme litt�rale le type d'une pi�ce � partir de son num�ro.
		 *	----------------------------------------------------------------------	*/
		
		if( i == 1 )				return "Pion" ;
		if( i == 2 )				return "Tour" ;
		if( i == 3 )				return "Cav." ;
		if( i == 4 )				return "Fou." ;
		if( i == 5 )				return "Roi." ;
		if( i == 6 )				return "Dame" ;
									return "Vide" ;
	}
	public String Renvoyer_Facteurs( Piece_P base )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Piece_P	base	: pi�ce a d�tailler.
		 *	[Retours]	> String	return	: liste des facteurs mis en forme.
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'obtenir une liste mise en forme des diff�rents facteurs d'une pi�ce potentielle.
		 *	----------------------------------------------------------------------	*/
		
		return	"FC[" + base.FC + " " + base.FC_c + "] - " +
				"FS[" + base.FS + " " + base.FS_c + "] - " +
				"FP[" + base.FP + " " + base.FP_c + "] - " +
				"FM[" + base.FM + " " + base.FM_c + "]" ;
	}
	public boolean Int2Boolean( int brut )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> int		brut 	: entier � convertir.
		 *	[Retours]	> boolean	return	: entier converti.
		 *	[Notes]		> Pour brut nul, renvoie FALSE ; renvoie TRUE sinon.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet de convertir un entier en bool�an de mani�re similaire � celle usit�e en PHP.
		 *	----------------------------------------------------------------------	*/
		
		if( brut == 0 )				return false ;
		else						return true ;
	}
	public int Boolean2Int( boolean brut )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> boolean		brut 		: bool�en � convertir.
		 *	[Retours]	> int			return		: bool�en converti.
		 *	[Notes]		> Pour brut FALSE, renvoie 0 ; renvoie 1 sinon.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet de convertir un bool�en en entier de mani�re similaire � celle usit�e en PHP.
		 *	----------------------------------------------------------------------	*/
		
		if( brut )				return 1 ;
		else					return 0 ;
	}
	public void Modifier_Prefixage( boolean sens )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> boolean	sens : sens d'alt�ration
		 *	[Retours]	> N/A
		 *	[Notes]		> TRUE rajoute un espace, FALSE en enl�ve.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet de modifier le pr�fixage du renvoi console de l'entit� en cours.
		 *	----------------------------------------------------------------------	*/
		
		if( sens )				prefixage++ ;
		if( !sens )				prefixage-- ;
	}
	public boolean Inverser_Boolean( boolean base )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> boolean	base 	: sens d'alt�ration
		 *	[Retours]	> boolean	return	: r�sultat invers�
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'inverser la valeur d'un boul�en.
		 *	----------------------------------------------------------------------	*/
		
		if( base )					return false ;
		else						return true ;
	}

}

class MORPHEE
{
	int						nbr_variables = 256 ;
	int[]					variables = new int[nbr_variables] ;
	String[]				desc_variables = new String[nbr_variables] ;
	
	public MORPHEE()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> [!] Contient toutes les variables de configuration d'Atlas.
		 *				> Est initialis� dans chacunes de sous-entit�s d'Atlas.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de l'entit� Morph�e.
		 *	----------------------------------------------------------------------	*/
		
		int i ;
		
		variables[0] = nbr_variables ;
		for( i = 1 ; i < nbr_variables ; i++ )			variables[i] = 0 ;
		
		variables[1]  = 2048 ;
		variables[2]  = 4 ;
		variables[3]  = 1024 * 64 ; // 32768 ;
		
		variables[4]  = 1 ;
		variables[5]  = 5 ;
		variables[6]  = 3 ;
		variables[7]  = 3 ;
		variables[8]  = 15 ;
		variables[9]  = 10 ;
		
		variables[10] = 5 ;
		
		variables[11] = 1 ;
		variables[12] = 8 ;
		variables[13] = 4 ;
		variables[14] = 2 ;
		variables[15] = 1 ;
		variables[16] = 0 ;
		variables[17] = 0 ;
		variables[18] = 0 ;
		variables[19] = 0 ;
		variables[20] = 0 ;
		variables[21] = 0 ;
		
		variables[22] = 5 ;
		variables[23] = 4 ;
		variables[24] = 2 ;
		variables[25] = 4 ;
		variables[26] = 3 ;
		variables[27] = 1 ;
		
		variables[28] = 4 ;
		
		variables[29] = 115 ;
		variables[30] = 3 ;
		
		desc_variables[0]  = "Nombre maximum de variables de configuration" ;
		desc_variables[1]  = "Nombre de coups possibles maximums par situation" ;
		desc_variables[2]  = "Degre maximal d'etude (DME) - max.5" ;
		desc_variables[3]  = "ID maximum d'un echiquier potentiel" ;
		desc_variables[4]  = "Valeur d'un pion" ;
		desc_variables[5]  = "Valeur d'une tour" ;
		desc_variables[6]  = "Valeur d'un cavalier" ;
		desc_variables[7]  = "Valeur d'un fou" ;
		desc_variables[8]  = "Valeur du roi (arbitraire)" ;
		desc_variables[9]  = "Valeur de la dame" ;
		desc_variables[10] = "Multiplicateur d'echec" ;
		desc_variables[11] = "Coefficient d'optimisation de niveau 0" ;
		desc_variables[12] = "Coefficient d'optimisation de niveau 1" ;
		desc_variables[13] = "Coefficient d'optimisation de niveau 2" ;
		desc_variables[14] = "Coefficient d'optimisation de niveau 3" ;
		desc_variables[15] = "Coefficient d'optimisation de niveau 4" ;
		desc_variables[16] = "Coefficient d'optimisation de niveau 5" ;
		desc_variables[17] = "Coefficient d'optimisation de niveau 6" ;
		desc_variables[18] = "Coefficient d'optimisation de niveau 7" ;
		desc_variables[19] = "Coefficient d'optimisation de niveau 8" ;
		desc_variables[20] = "Coefficient d'optimisation de niveau 9" ;
		desc_variables[21] = "Coefficient d'optimisation de niveau 10" ;
		desc_variables[22] = "Coefficient d'arbitrage [PA]" ;
		desc_variables[23] = "Coefficient d'arbitrage [RS]" ;
		desc_variables[24] = "Coefficient d'arbitrage [PT]" ;
		desc_variables[25] = "Coefficient d'arbitrage [OP]" ;
		desc_variables[26] = "Coefficient d'arbitrage [PR]" ;
		desc_variables[27] = "Coefficient d'arbitrage [EQ]" ;
		desc_variables[28] = "Niveau maximal d'etude (NME) - max.10" ;
		desc_variables[29] = "Alterant" ;
		desc_variables[30] = "Modificateur de fourchette" ;
	}
	public int Get_Var( int i )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> int	i 		: ID de la variable
		 *	[Retours]	> int	return	: valeur retourn�e de la variable
		 *	[Notes]		> Retourne z�ro en cas de variable invalide.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'obtenir la valeur d'une variable � partir de son num�ro d'identifiant.
		 *	----------------------------------------------------------------------	*/	
		
		return variables[i] ;
	}
	public String Get_VarDesc( int i )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> int		i 		: ID de la variable
		 *	[Retours]	> String	return	: description de la variable
		 *	[Notes]		> Retourne UNDEFINED en cas de variable ind�finie.
		 *				> Retourne UNKNOWN en cas de variable non-d�crite.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'obtenir la description d'une variable � partir de son num�ro d'identifiant.
		 *	----------------------------------------------------------------------	*/	
		
		return desc_variables[i] ;
	}
}

class DEDALE
{
	HERMES					hermes = new HERMES(2) ;
	MORPHEE					configuration = new MORPHEE() ;
	ACHILLE					achille = new ACHILLE( configuration ) ;
	THESEE					thesee = new THESEE( configuration ) ;
	Pack_Stat[][][]			stats = new Pack_Stat[configuration.Get_Var(2)][2][configuration.Get_Var(3)] ;			// DEGRE / CAMP /
	
	public DEDALE( MORPHEE configuration_transmise )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> MORPHEE	configuration_transmise	: configuration globale.
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de l'entit� D�dale.
		 *	----------------------------------------------------------------------	*/	
		
		int x , y ;
		configuration = configuration_transmise ;
				
		hermes.Afficher("Initialisation de l'element premier statistique ...") ;
		for( x = 0 ; x < configuration.Get_Var(2) ; x++ )
		{
			for( y = 0 ; y < 2 ; y++ )
			{
				stats[x][y][0] = new Pack_Stat( x , y , 0 ) ;
			}
		}
		stats[0][0][1] = new Pack_Stat( 0 , 0 , 1) ;
		hermes.Valider() ;
		
		hermes.Saut_Ligne() ;
	}
	public Coup_P Gestion_Globale( Situation_P s_i )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Situation_P	s_i		: situation initiale
		 *	[Retours]	> Coup_P		return	: coup critique
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction entame les �tudes successives par la soumission de la situation initiale et renvoie le r�sultat de la synth�se de ses �tudes.
		 *	----------------------------------------------------------------------	*/	
		
		hermes.Afficher("Etude de la situation initiale ...") ;
		s_i = Cycle_Etude( s_i ) ;
		hermes.Valider() ;
		hermes.Afficher("Engagement du processus d'etude") ;
		Gerer_Etude( s_i ) ;
		hermes.Afficher("Fin du processus d'etude") ;
		
		return Synthese( s_i ) ;
	}
	public Situation_P Cycle_Etude( Situation_P situation )
	{	
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Situation_P	situation	: situation � �tudier
		 *	[Retours]	> Situation_P	situation	: situation �tudi�e
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction m�ne l'�tude d'une situation individuelle en �ditant ses caract�ristiques.
		 *	----------------------------------------------------------------------	*/	
		
		hermes.Afficher("Initialisation du cycle d'etude") ;
		hermes.Afficher("Etude en cours : [Degree:" + situation.degree + "][Camp:" + hermes.Renvoyer_CM( hermes.Int2Boolean( situation.camp )) + "][ID:" + situation.id + "]" ) ;
		hermes.Infos(situation,"Grille en etude") ;
		hermes.Saut_Ligne() ;
		hermes.Afficher("ETUDE PRIMAIRE") ;
		situation = achille.Etudier( situation ) ;
		hermes.Afficher("Fin de l'etude primaire") ;
		hermes.Afficher("Affichage des resultats individuels") ;
		hermes.Detail_Pieces(situation) ;
		hermes.Afficher("Affichage de la grille apres etude primaire") ;
		hermes.Infos(situation,"Grille apres etude primaire") ;
		hermes.Saut_Ligne() ;
		hermes.Afficher("ETUDE SECONDAIRE") ;
		situation = thesee.Etudier( situation ) ;
		hermes.Afficher("Fin de l'etude secondaire") ;
		hermes.Afficher("Affichage de la grille apres etude secondaire") ;
		hermes.Infos(situation,"Grille apres etude secondaire") ;
		hermes.Afficher("Fin du cycle d'etude") ;
		
		return situation ;
	}
	public void Gerer_Etude( Situation_P pere )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Situation_P	pere	: situation � g�rer
		 *	[Retours]	> N/A
		 *	[Notes]		> [!] Edite les packages de statistiques au fur et � mesure de sa progression.
		 *				> [!] Fonction r�cursive. M�ne l'�tude des situations filles apr�s arbitrage des coefficients d'optimisation.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction g�re l'�tude d'une situation donn�e, l'enregistrement des r�sultats et l'�tude des situations filles.
		 *	----------------------------------------------------------------------	*/	
		
		int					i , j , k , id_min , id_max ;
		int					df, cf , lvlf ;
		int					c , l , colonne , ligne ;
		double				mem ;
		Situation_P			fils ;
		Situation_P			suivante ;
		double				AT_max = 0 , DE_max = 0 , RI_max = 0 , DI_max = 0 ;
		double				LI_max = 0 , OP_max = 0 , CO_max = 0 , PR_max = 0 , EQ_max = 0 ;
		double[][]			selection ;
		boolean				start , chessmate = false ;

		hermes.Wait_Long( pere ) ;
		
		hermes.Afficher("1:[Travail preparatoire]") ;
		hermes.Modifier_Prefixage(true) ;
		hermes.Afficher("Definition du camp fils et du degre fils ...") ;
		if( pere.camp == 0 )
		{
			cf = 1 ;
			df = pere.degree ;
		}
		else
		{
			cf = 0 ;
			df = pere.degree + 1 ;
		}
		lvlf = df*2 + cf ;
		hermes.Valider() ;
		hermes.Afficher("Definition de l'ID minimum ...") ;
		for( id_min = 0 ; stats[df][cf][id_min].defini ; id_min++ );
		hermes.Valider() ;
		hermes.Afficher("Definition de l'ID maximum ...") ;
		for( id_max = 0 ; pere.liste_coups[id_max].defini ; id_max++ )
		{
			stats[df][cf][id_max+id_min] = new Pack_Stat( df , cf , (id_max+id_min) ) ;
		}
		stats[df][cf][id_max+id_min] = new Pack_Stat( df , cf , (id_max+id_min) ) ;
		id_max += id_min ;
		hermes.Valider() ;
		hermes.Modifier_Prefixage(false) ;
		
		hermes.Afficher("2:[Etudes des grilles filles]") ;
		hermes.Modifier_Prefixage(true) ;
		for( i = 0 ; pere.liste_coups[i].defini ; i++ )
		{
			hermes.Afficher("Traitement de la grille fille [ABS-ID:" + i + "][ID:" + ( id_min + i ) + "]" ) ;
			hermes.Modifier_Prefixage(true) ;
			
			hermes.Afficher("Definition de la grille en cours ...") ;
			fils = new Situation_P( configuration , pere ) ;
			hermes.Valider() ;
			
			hermes.Afficher("Identification de la grille en cours ...") ;
			fils.degree	= df ;
			fils.camp	= cf ;
			fils.id		= id_min + i ;
			fils.camp_maitre = hermes.Inverser_Boolean( pere.camp_maitre ) ;
			hermes.Valider() ;
			
			hermes.Afficher("Sterilisation de la grille en cours ...") ;
			fils.generer_liste_coups = false ;
			hermes.Valider() ;
			
			hermes.Afficher("Prise en compte du coup ...") ;
			fils.base_brute.couppossible_et_valide( pere.liste_coups[i].colonne_d , pere.liste_coups[i].ligne_d, pere.liste_coups[i].colonne_a, pere.liste_coups[i].ligne_a ) ;
			hermes.Valider() ;

			hermes.Afficher("Prise en compte des promotions ...") ;
			for( c = 0 ; c < 8 ; c++ )
			{
				if( fils.base_brute.gettype_piece(c,0) == 1 )
				{
					fils.base_brute.tableaupiece[c][0].typepiece = 6 ; ;
				}
				if( fils.base_brute.gettype_piece(c,7) == 1 )
				{
					fils.base_brute.tableaupiece[c][7].typepiece = 6 ;  ;
				}
			}
			hermes.Valider() ;
			
			hermes.Afficher("Etude de la grille en cours ...") ;
			hermes.Modifier_Prefixage(false) ;
			hermes.Modifier_Prefixage(false) ;
			fils = Cycle_Etude( fils ) ;
			hermes.Modifier_Prefixage(true) ;
			hermes.Modifier_Prefixage(true) ;
			
			hermes.Afficher("Collecte des statistiques ...") ;
			stats[fils.degree][fils.camp][fils.id].Stocker( fils , i ) ;
			hermes.Valider() ;
			
			hermes.Afficher("Gestion de la genealogie ...") ;
			stats[fils.degree][fils.camp][fils.id].genealogie = pere.id ;
			hermes.Valider() ;
			
			hermes.Afficher("Nettoyage de la grille en cours ...") ;
			fils = null ;
			hermes.Valider() ;
			
			hermes.Modifier_Prefixage(false) ;
		}
		hermes.Modifier_Prefixage(false) ;
		
		hermes.Afficher("3:[Ajustement des statistiques]") ;
		hermes.Modifier_Prefixage(true) ;
		hermes.Afficher("Collecte des maximas ...") ;
		for( i = id_min ; i < id_max ; i++ )
		{
			if( stats[df][cf][i].AT > AT_max )			AT_max = stats[df][cf][i].AT ;
			if( stats[df][cf][i].DE > DE_max )			DE_max = stats[df][cf][i].DE ;
			if( stats[df][cf][i].RI > RI_max )			RI_max = stats[df][cf][i].RI ;
			if( stats[df][cf][i].DI > DI_max )			DI_max = stats[df][cf][i].DI ;
			if( stats[df][cf][i].LI > LI_max )			LI_max = stats[df][cf][i].LI ;
			if( stats[df][cf][i].OP > OP_max )			OP_max = stats[df][cf][i].OP ;
			if( stats[df][cf][i].CO > CO_max )			CO_max = stats[df][cf][i].CO ;
			if( stats[df][cf][i].PR > PR_max )			PR_max = stats[df][cf][i].PR ;
			if( stats[df][cf][i].EQ > EQ_max )			EQ_max = stats[df][cf][i].EQ ;
		}
		hermes.Valider() ;
		hermes.Afficher("Ajustement des statistiques de serie ...") ;
		for( i = id_min ; i < id_max ; i++ )
		{
			mem	=	stats[df][cf][i].AT / AT_max ;
					stats[df][cf][i].AT = Math.round( 100 * mem ) ;
			mem	=	stats[df][cf][i].DE / DE_max ;
					stats[df][cf][i].DE = Math.round( 100 * mem ) ;
			mem	=	stats[df][cf][i].RI / RI_max ;
					stats[df][cf][i].RI = Math.round( 100 * mem ) ;
			mem	=	stats[df][cf][i].DI / DI_max ;
					stats[df][cf][i].DI = Math.round( 100 * mem ) ;	
			mem	=	stats[df][cf][i].LI / LI_max ;
					stats[df][cf][i].LI = Math.round( 100 * mem ) ;
			mem	=	stats[df][cf][i].OP / OP_max ;
					stats[df][cf][i].OP = Math.round( 100 * mem ) ;	
			mem	=	stats[df][cf][i].CO / CO_max ;
					stats[df][cf][i].CO = Math.round( 100 * mem ) ;		
			mem	=	stats[df][cf][i].PR / PR_max ;
					stats[df][cf][i].PR = Math.round( 100 * mem ) ;		
			mem	=	stats[df][cf][i].EQ / EQ_max ;
					stats[df][cf][i].EQ = Math.round( 100 * mem ) ;
		}
		hermes.Valider() ;
		hermes.Afficher("Calcul des caracteristiques derivees et coefficients d'interet ...") ;
		for( i = id_min ; i < id_max ; i++ )
		{
			stats[df][cf][i].Definir_Finaux( configuration ) ;
		}
		hermes.Valider() ;
		hermes.Modifier_Prefixage(false) ;
		
		hermes.Afficher("4:[Optimisation]") ;
		hermes.Modifier_Prefixage(true) ;
		hermes.Afficher("Initialisation du tableau de selection ...") ;
		selection = new double[configuration.Get_Var(11+lvlf)][2] ;
		for( i = 0 ; i < configuration.Get_Var(11+lvlf) ; i++ )
		{
			selection[i][0]	= -1 ;
			selection[i][1]	= 0 ;
		}
		hermes.Valider() ;
		hermes.Afficher("Remplissage du tableau de selection") ;
		for( i = id_min ; i < id_max ; i++ )
		{
			hermes.Afficher("Prise en compte de l'echec ...") ;
			// if( stats[df][cf][i].sterile )				stats[df][cf][i].coefficient_interet = stats[df][cf][i].coefficient_interet / 2 ;
			hermes.Valider() ;
			
			hermes.Afficher("Traitement de l'element statistique [ID:" + i + "]" ) ;
			
			hermes.Modifier_Prefixage(true) ;
			hermes.Afficher("Parcours du tableau existant ...") ;
			for( j = 0 , mem = 100000 , k = -1 ; j < configuration.Get_Var(11+lvlf); j++ )
			{
				if( selection[j][1] < stats[df][cf][i].coefficient_interet && selection[j][1] < mem  )
				{
					k 		= j ;
					mem 	= selection[j][1] ; 
				}
			}
			hermes.Valider() ;
			if( k != -1 )
			{
				hermes.Afficher("Mise en memoire [Valeur:" + stats[df][cf][i].coefficient_interet + "][ID:" + i + "] ...") ;
				selection[(int)k][0] = i ;
				selection[(int)k][1] = stats[df][cf][i].coefficient_interet ;
				hermes.Valider() ;
			}
			hermes.Modifier_Prefixage(false) ;
		}

		hermes.Afficher("Affichage des grilles filles retenues") ;
		hermes.Modifier_Prefixage(true) ;
		for( i = 0 ; i < configuration.Get_Var(11+lvlf) ; i++ )
		{
			if( selection[i][0] != -1 )			hermes.Afficher("Element [ABS-ID:" + i + "][ID:" + selection[i][0] + "][CI:" + selection[i][1] + "]" ) ;
		}
		hermes.Modifier_Prefixage(false) ;
		
		hermes.Afficher("Declaration des grilles parentes ...") ;
		for( i = 0 ; i < configuration.Get_Var(11+lvlf) ; i++ )
		{
			for( i = 0 ; i < configuration.Get_Var(11+lvlf) ; i++ )
			{
				if( selection[i][0] != -1 )			
				{
					stats[df][cf][(int)selection[i][0]].fertile = true ;
				}
			}
		}
		hermes.Valider() ;
		hermes.Modifier_Prefixage(false) ;
		
		hermes.Afficher("5:[Appel de gestion]") ;
		hermes.Modifier_Prefixage(true) ;
		for( i = id_min ; i < id_max ; i++ )
		{
			if( stats[df][cf][i].fertile )
			{
				hermes.Afficher("Definition de la grille suivante ...") ;
				suivante = new Situation_P( configuration , pere ) ;
				start = true ;
				hermes.Valider() ;
				
				hermes.Afficher("Identification de la grille suivante ...") ;

				suivante.degree			= df ;
				suivante.camp			= cf ;
				suivante.id				= i ;
				suivante.camp_maitre	= hermes.Inverser_Boolean( pere.camp_maitre ) ;
				hermes.Valider() ;

				hermes.Afficher("Prise en compte du coup ...") ;
				suivante.base_brute.couppossible_et_valide( pere.liste_coups[stats[df][cf][i].coup_pere].colonne_d , pere.liste_coups[stats[df][cf][i].coup_pere].ligne_d , pere.liste_coups[stats[df][cf][i].coup_pere].colonne_a, pere.liste_coups[stats[df][cf][i].coup_pere].ligne_a ) ;
				hermes.Valider() ;

				hermes.Afficher("Validation de la fin de partie ...") ;
				k = 0 ;
				for( c = 0 ; c < 8 ; c++ )
				{
					for( l = 0 ; l < 8 ; l++ )
					{
						if( suivante.base_brute.gettype_piece(c,l) == 5 )			k++ ;
					}
				}
				if( k != 2 )
				{
					hermes.Ajout( "!" ) ;
					start = false ;
				}
				hermes.Valider() ;
				
				hermes.Afficher("Validation du NME ...") ;
				if( suivante.degree * 2 + suivante.camp > configuration.Get_Var(28) )
				{
					hermes.Ajout( "!" ) ;
					start = false ;
				}
				hermes.Valider() ;
				
				if( !chessmate )
				{
					hermes.Afficher("Prise en compte des promotions ...") ;
					for( c = 0 ; c < 8 ; c++ )
					{
						if( suivante.base_brute.gettype_piece(c,0) == 1 )
						{
							suivante.base_brute.tableaupiece[c][0].typepiece = 6 ; ;
						}
						if( suivante.base_brute.gettype_piece(c,7) == 1 )
						{
							suivante.base_brute.tableaupiece[c][7].typepiece = 6 ;  ;
						}
					}
					hermes.Valider() ;
					
					hermes.Afficher("Inscription de la liste coups ...") ;
					for( colonne = 0 ; colonne < 8 ; colonne++ )
					{
						for( ligne = 0 ; ligne < 8 ; ligne++ )
						{
							suivante.base_brute.couppossible(colonne, ligne) ;
							for( c = 0 ; c < 8 ; c++ )
							{
								for( l = 0 ; l < 8 ; l++ )
								{	
									if( suivante.base_brute.getpossibilite(c,l) && suivante.base_brute.getcouleur_piece(colonne, ligne) == suivante.camp_maitre )
									{
										suivante.Definir_Coup_P(colonne,ligne,c,l) ;
									}	
								}	
							}	
						}	
					}
				}
				hermes.Valider() ;
				
				if( start )
				{
					hermes.Afficher("Appel !") ;
					hermes.Modifier_Prefixage(false) ;
					Gerer_Etude( suivante ) ;
					hermes.Modifier_Prefixage(true) ;
				}
				
				hermes.Afficher("Nettoyage de la grille suivante ...") ;
				suivante = null ;
				start = false ;
				hermes.Valider() ;
			}
		}
		hermes.Modifier_Prefixage(false) ;
		
		hermes.Afficher("Retour !...") ;
	}
	public Coup_P Synthese( Situation_P repere)
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Situation_P	repere			: situation initiale
		 *	[Retours]	> Coup_P		coup_critique	: coup critique d�termin�
		 *	[Notes]		> La situation initiale est pass�e en argument pour rappel des diff�rents coups critiques.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction effectue la synth�se des r�sultats et g�n�re le coup critique � partir de ses derniers.
		 *	----------------------------------------------------------------------	*/
		
		int 				x , y , z ;
		int[]				z_maxs = new int[10] ;
		int				 	mem = -1 ;
		double				sum = 0 , count = 0 , temp ;
		double				tampon ;
		int					dp , cp , p , q ;
		boolean				i ;
		Coup_P coup_critique = new Coup_P() ;
		
		hermes.Afficher("Recherche des maximas ...") ;
		for( x = 0 ; x < configuration.Get_Var(2) ; x++ )
		{
			for( y = 0 ; y < 2 ; y++ )
			{
				for( z = 0 ; z < configuration.Get_Var(3) ; z++ )
				{
					if( !stats[x][y][z].defini )
					{
						z_maxs[(x*2)+y] = z + 1  ;
						break ;
					}
				}
			}
		}
		hermes.Valider() ;
		
		hermes.Afficher("Affichage des resultats :") ;
		hermes.Modifier_Prefixage(true) ;
		
		hermes.Afficher("DEG\tCAMP\tID") ;
		for( x = 0 ; x < configuration.Get_Var(2) ; x++ )
		{
			for( y = 0 ; y < 2 ; y++ )
			{
				for( z = 0 ; z < z_maxs[(x*2)+y ] ; z++ )
				{
					if( stats[x][y][z].defini )
					{
						hermes.Afficher( x + "\t" + y + "\t" + z + "\t" + stats[x][y][z].coefficient_interet ) ;
					}
				}
			}
		}
		hermes.Saut_Ligne() ;
		
		hermes.Afficher("Definition de la memoire initiale ...") ;
		for( x = configuration.Get_Var(2)-1 ; x > 0 ; x-- )
		{
			for( y = 1 ; y >= 0 ; y-- )
			{
				for( z = z_maxs[(x*2)+y]-1 ; z >= 0 ; z-- )
				{
					if( stats[x][y][z].defini )
					{
						mem = stats[x][y][z].genealogie ;
						break ;
					}
				}
				break ;
			}
			break ;
		}
		hermes.Valider() ;
		
		hermes.Afficher("Lissage des resultats ...") ;
		for( x = configuration.Get_Var(2)-1 ; x >= 0 ; x-- )
		{
			for( y = 1 ; y >= 0 ; y-- )
			{
				if( y == 1 )
				{
					dp = x ;
					cp = 0 ;
				}
				else
				{
					dp = x - 1 ;
					cp = 1 ;
				}
				i = true ;

				for( z = 0 ; z < z_maxs[(x*2)+y] ; z++ )
				{
					if( x == 0 && y == 0 )			break ;
					
					if( i )
					{
						mem   = stats[x][y][z].genealogie ;
						sum   = 0 ;
						count = 0 ;
						i = false ;
					}
					
					if( mem == stats[x][y][z].genealogie )
					{
						sum   += stats[x][y][z].coefficient_interet ;
						count ++ ;
					}
					else
					{
						tampon = configuration.Get_Var(29) ;
						stats[dp][cp][mem].coefficient_interet -=  Math.round( ( 100 / tampon ) * ( sum / count ) ) ;
						stats[dp][cp][mem].fertile = true ;
						sum   = stats[x][y][z].coefficient_interet ;
						count = 1 ;
					}
					mem   = stats[x][y][z].genealogie ;
				}
			}
		}
		hermes.Valider() ;
		
		hermes.Afficher("Affichage des coefficients affines") ;
		for( z = 0 ; z < z_maxs[1] ; z++ )
		{
			if( stats[0][1][z].defini )
			{
				hermes.Afficher( "\t" + stats[0][1][z].coefficient_interet ) ;
			}
		}
		
		hermes.Afficher("Selection du maximum ...") ;
		temp 	= 0 ;
		q		= -1 ;
		for( p = 0 ; stats[0][1][p].defini ; p++ )
		{
			if( stats[0][1][p].fertile && stats[0][1][p].coefficient_interet > temp )
			{
				temp = stats[0][1][p].coefficient_interet ;
				q = p ;
			}
		}
		
		hermes.Valider() ;
		
		hermes.Afficher("Definition du coup critique ...") ;
		coup_critique = repere.liste_coups[q] ;
		hermes.Valider() ;
		
		return coup_critique ;
	}
}

class ACHILLE
{
	MORPHEE					configuration ;
	HERMES					hermes = new HERMES(3) ;
	HERCULE					hercule ;
	int						c , l ;
	
	public ACHILLE( MORPHEE configuration_transmise )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> MORPHEE	configuration_transmise	: configuration globale.
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de l'entit� Achille.
		 *	----------------------------------------------------------------------	*/	
		
		hermes.Afficher("Definition de la configuration pour ACHILLE ...") ;
		configuration = configuration_transmise ;
		hermes.Valider() ;
		hercule = new HERCULE( configuration ) ;
	}
	public Situation_P Etudier( Situation_P base )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Situation_P	base : grille � �tudier
		 *	[Retours]	> Situation_P	base : grille �tudi�e
		 *	[Notes]		> [!] Entit� de calcul arbitraire
		 *				> Peut �tre librement �dit�e. Caract�ristiques �tudi�es : AT | DE | RI | DI
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction m�ne l'�tude primaire d'une situation potentielle.
		 *	----------------------------------------------------------------------	*/	
		
		hermes.Afficher("Debut de l'etude des chaines") ;
		for( c = 0 ; c < 8 ; c++ )
		{
			for( l = 0 ; l < 8 ; l++)
			{
				base = hercule.Scanner( base , c , l ) ;
			}
		}
		hermes.Afficher("Fin de l'etude des chaines") ;
		hermes.Afficher("Affichage du detail des pieces") ;
		hermes.Detail_Pieces(base) ;
		hermes.Afficher("Generation des facteurs derives ...") ;
		for( c = 0 ; c < 8 ; c++ )
		{
			for( l = 0 ; l < 8 ; l++)
			{
				if( base.base_brute.gettype_piece(c,l) != 0 )			base.echiquier[c][l].Generer_Derivees() ;
			}
		}
		hermes.Valider() ;
		hermes.Afficher("Generation des caracteristiques primaires") ;
		hermes.Modifier_Prefixage(true) ;
		for( c = 0 ; c < 8 ; c++ )
		{
			for( l = 0 ; l < 8 ; l++)
			{
				if( base.base_brute.getcouleur_piece(c,l) == base.camp_maitre )
				{
					hermes.Afficher("Piece alliee ...") ;
					if( base.echiquier[c][l].FP_d - base.echiquier[c][l].FM_d > 0 )
					{
						base.AT +=   base.echiquier[c][l].FP_d - base.echiquier[c][l].FM_d ;
					}
					base.DE += ( base.echiquier[c][l].FS_d + base.echiquier[c][l].FC_d ) / 2 ;
				}
				else
				{
					hermes.Afficher("Piece adverse ...") ;
					if( base.echiquier[c][l].FP_d - base.echiquier[c][l].FM_d > 0 )
					{
						base.RI +=   base.echiquier[c][l].FP_d - base.echiquier[c][l].FM_d ;
					}
					base.DI += ( base.echiquier[c][l].FS_d + base.echiquier[c][l].FC_d ) / 2 ;
				}
			}
		}
		hermes.Modifier_Prefixage(false) ;
		
		return base ;
	}
}

class THESEE
{
	MORPHEE					configuration ;
	HERMES					hermes = new HERMES(4) ;
	
	public THESEE( MORPHEE configuration_transmise )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> MORPHEE	configuration_transmise	: configuration globale.
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de l'entit� Th�s�e.
		 *	----------------------------------------------------------------------	*/	
		
		hermes.Afficher("Definition de la configuration pour ACHILLE ...") ;
		configuration = configuration_transmise ;
		hermes.Valider() ;
	}
	public Situation_P Etudier( Situation_P base )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Situation_P	base : grille � �tudier
		 *	[Retours]	> Situation_P	base : grille �tudi�e
		 *	[Notes]		> [!] Entit� de calcul arbitraire
		 *				> Peut �tre librement �dit�e. Caract�ristiques �tudi�es : LI | CO | OP | PR | EQ
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction m�ne l'�tude secondaire d'une situation potentielle.
		 *	----------------------------------------------------------------------	*/	
		
		int					c , l , x=0 , y=0 ;
		
		hermes.Afficher("Calcul de la caracteristique de liberte [LI]:") ;
		hermes.Modifier_Prefixage(true) ;
		hermes.Afficher("Scan des possibilites du camp maitre ...") ;
		hermes.Infos(base,"Possibilites du camp maitre") ;
		base.base_brute.couppossibles_camp( base.camp_maitre ) ;
		hermes.Valider() ;
		hermes.Afficher("Stockage des possibilites ...") ;
		for( c = 0 ; c < 8 ; c++ )
		{
			for( l = 0 ; l < 8 ; l++ )
			{
				base.LI ++ ;
			}
		}
		hermes.Valider() ;
	   	hermes.Modifier_Prefixage(false) ;
	   	
	   	hermes.Afficher("Calcul de la caracteristique de controle [CO]:") ;
		hermes.Modifier_Prefixage(true) ;
		hermes.Afficher("Scan des possibilites du camp servant ...") ;
		base.base_brute.couppossibles_camp(  hermes.Inverser_Boolean( base.camp_maitre ) ) ;
		hermes.Valider() ;
		hermes.Afficher("Stockage des possibilites ...") ;
		for( c = 0 ; c < 8 ; c++ )
		{
			for( l = 0 ; l < 8 ; l++ )
			{
				base.CO ++ ;
			}
		}
		hermes.Valider() ;
	   	hermes.Modifier_Prefixage(false) ;
	   	
	   	hermes.Afficher("Calcul de la caracteristique d'opportunite [OP]:") ;
	   	hermes.Modifier_Prefixage(true) ;
	   	hermes.Afficher("Recherche du roi ...") ;
	   	for( c = 0 ; c < 8 ; c++ )
    	{
    		for( l = 0 ; l < 8 ; l++ )
    		{
    			if( base.base_brute.gettype_piece(c,l) == 5 && base.base_brute.getcouleur_piece(c,l) == hermes.Inverser_Boolean(base.camp_maitre) )
    			{
    				x = c ;
    				y = l ;
    			}
    		}
    	}
	   	hermes.Afficher("Definition des possibilites de mouvement du roi ...") ;
	   	base.base_brute.couppossible(x,y) ;
	   	hermes.Valider() ;
	   	hermes.Afficher("Calcul de la liberte du roi ...") ;
	   	for( c = 0 ; c < 8 ; c++ )
    	{
    		for( l = 0 ; l < 8 ; l++ )
    		{
    			if( base.base_brute.getpossibilite(c,l) )
    			{
    				base.OP ++ ;
    			}
    		}
    	}
	   	hermes.Valider() ;
	   	hermes.Afficher("Prise en compte d'un echec ...") ;
	   	if( base.base_brute.echec_roi( hermes.Inverser_Boolean( base.camp_maitre ) ))
	   	{
	   		base.OP = base.OP * configuration.Get_Var(10) ;
	   	}
	   	hermes.Valider() ;
	   	hermes.Modifier_Prefixage(false) ;
	   	
	   	hermes.Afficher("Calcul de la caracteristique de pression [PR]:") ;
	   	hermes.Modifier_Prefixage(true) ;
	   	hermes.Afficher("Recherche du roi ...") ;
	   	for( c = 0 ; c < 8 ; c++ )
    	{
    		for( l = 0 ; l < 8 ; l++ )
    		{
    			if( base.base_brute.gettype_piece(c,l) == 5 && base.base_brute.getcouleur_piece(c,l) == base.camp_maitre )
    			{
    				x = c ;
    				y = l ;
    			}
    		}
    	}
	   	hermes.Afficher("Definition des possibilites de mouvement du roi ...") ;
	   	base.base_brute.couppossible(x,y) ;
	   	hermes.Valider() ;
	   	hermes.Afficher("Calcul de la liberte du roi ...") ;
	   	for( c = 0 ; c < 8 ; c++ )
    	{
    		for( l = 0 ; l < 8 ; l++ )
    		{
    			if( base.base_brute.getpossibilite(c,l) )
    			{
    				base.PR ++ ;
    			}
    		}
    	}
	   	hermes.Valider() ;
	   	hermes.Afficher("Prise en compte d'un echec ...") ;
	   	if( base.base_brute.echec_roi( base.camp_maitre ))
	   	{
	   		base.PR = base.PR * configuration.Get_Var(10) ;
	   	}
	   	hermes.Valider() ;
	   	hermes.Modifier_Prefixage(false) ;
	   	
	   	hermes.Afficher("Calcul de la caracteristique d'equilibre [EQ] ...") ;
	   	x = 0 ;
	   	for( c = 0 ; c < 8 ; c++ )
    	{
    		for( l = 0 ; l < 8 ; l++ )
    		{
    			if( base.base_brute.getcouleur_piece(c,l) == base.camp_maitre && base.base_brute.gettype_piece(c,l) != 0 )
    			{
    				base.EQ += base.echiquier[c][l].Donner_Valeur() ;
    			}
    			else if( base.base_brute.gettype_piece(c,l) != 0 )
    			{
    				base.EQ -= base.echiquier[c][l].Donner_Valeur() ;
    			}
    		}
    	}
	   	if( base.EQ < 0 )				base.EQ = 0 ;
	   	hermes.Valider() ;
	   	
		return base ;
	}
}

class HERCULE
{
	HERMES					hermes = new HERMES(5) ;
	MORPHEE					configuration ;
	int						c , l ;

	public HERCULE( MORPHEE configuration_transmise )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> MORPHEE	configuration_transmise	: configuration globale.
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de l'entit� Hercule.
		 *	----------------------------------------------------------------------	*/	
		
		hermes.Afficher("Definition de la configuration pour HERCULE ...") ;
		configuration = configuration_transmise ;
		hermes.Valider() ;
	}	
	public Situation_P Scanner( Situation_P base, int colonne, int ligne )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Situation_P	base 	: grille contenant la pi�ce a �tudier
		 *				> int			colonne	: colonne de la pi�ce � �tudier
		 *				> int			ligne	: ligne de la pi�ce a �tudier
		 *	[Retours]	> Situation_P	base 	: grille contenant la pi�ce �tudi�e
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction d�termine le statut d'une pi�ce donn�e par rapport � son environnement (d�termination des facteurs)
		 *	----------------------------------------------------------------------	*/	
		
		if( base.base_brute.gettype_piece(colonne, ligne) == 0 )		return base ;
		
		hermes.Modifier_Prefixage(true) ;
		hermes.Saut_Ligne() ;
		hermes.Afficher( "Etude de la piece [C:" + colonne + "][L:" + ligne + "] : [Type:" + hermes.Renvoyer_Type( base.base_brute.gettype_piece(colonne,ligne) ) + "][Camp:" + hermes.Renvoyer_CM( base.base_brute.getcouleur_piece(colonne,ligne)) + "]") ;
		hermes.Afficher("Nettoyage des passages precedents ..." ) ;
		base.base_brute.free_attaquabilite() ;
		hermes.Valider() ;
		hermes.Afficher("Definition des possibilites de couverture ..." ) ;
		base.base_brute.couverture_potentielle( colonne , ligne ) ;
		hermes.Valider() ;
		hermes.Afficher("Parcours des possibilites ...") ;
		for( c = 0 ; c < 8 ; c++ )
		{
			for( l = 0 ; l < 8 ; l++ )
			{
				if( base.base_brute.gettype_piece(c,l) != 0 && base.base_brute.getattaquabilite(c,l) )
				{
					base.Editer_Facteurs(colonne,ligne,c,l) ;
				}
			}
		}
		hermes.Valider() ;
		if( base.generer_liste_coups )
		{
			hermes.Afficher("Indexation des coups jouables ...") ;
			base.base_brute.couppossible(colonne, ligne) ;
			for( c = 0 ; c < 8 ; c++ )
			{
				for( l = 0 ; l < 8 ; l++ )
				{	
					if( base.base_brute.getpossibilite(c,l) && base.base_brute.getcouleur_piece(colonne, ligne) == base.camp_maitre )
					{
						base.Definir_Coup_P(colonne,ligne,c,l) ;
					}
				}
			}
			hermes.Valider() ;
		}
		hermes.Afficher("Confirmation de l'etude piece ...") ;
		base.echiquier[colonne][ligne].etudiee = true ;
		hermes.Valider() ;
		hermes.Modifier_Prefixage(false) ;
		
		return base ;
	}
}

//									===== Autres non-entites =====

class Situation_P
{
	HERMES					hermes = new HERMES(10) ;
	Piece_P[][]				echiquier = new Piece_P[8][8] ;
	Coup_P[]				liste_coups ;
	double					AT = 0 , DE = 0 , RI = 0 , DI = 0 ;
	double					LI = 0 , OP = 0 , CO = 0 , PR = 0 , EQ = 0 ;
	double					PA = 0 , RS = 0 , PT = 0 ;
	boolean					camp_maitre ;
	boolean					defini = false ;
	boolean					generer_liste_coups = true ;
	Echiquier				base_brute ;
	int						degree, id, camp , index_coups ;
	
	
	public Situation_P( MORPHEE configuration )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> MORPHEE	configuration	: configuration globale.
		 *	[Retours]	> N/A
		 *	[Notes]		> Constructeur principal.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de la classe situation potentielle.
		 *	----------------------------------------------------------------------	*/	
		
		int c , l , i ;
		
		for( c = 0 ; c < 8 ; c++ )
		{
			for( l = 0 ; l < 8 ; l++ )
			{
				echiquier[c][l] = new Piece_P() ;
			}
		}
		
		liste_coups = new Coup_P[configuration.Get_Var(1)] ;
		for( i = 0 ; i < configuration.Get_Var(1) ; i++ )
		{
			liste_coups[i] = new Coup_P() ;
		}
		index_coups = 0 ;
		
		base_brute = new Echiquier() ;
	}
	public Situation_P( MORPHEE configuration , Situation_P modele )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> MORPHEE		configuration	: configuration globale
		 *				> Situation_P	modele			: situation potentielle a recopier
		 *	[Retours]	> N/A
		 *	[Notes]		> Constructeur secondaire.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de la classe situation potentielle, prenant pour mod�le une situation existante.
		 *	----------------------------------------------------------------------	*/	
		
		int c , l , i ;
		
		for( c = 0 ; c < 8 ; c++ )
		{
			for( l = 0 ; l < 8 ; l++ )
			{
				echiquier[c][l] = new Piece_P( modele.echiquier[c][l] ) ;
			}
		}
		
		liste_coups = new Coup_P[configuration.Get_Var(1)] ;
		for( i = 0 ; i < configuration.Get_Var(1) ; i++ )
		{
			liste_coups[i] = new Coup_P() ;
		}
		index_coups = 0 ;
		
		base_brute = new Echiquier( modele.base_brute ) ;
	}
	public void Remplir_Echiquier( Echiquier modele )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Echiquier	modele : �chiquier servant de mod�le
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction remplit la grille potentielle � partir d'un �chiquier simple.
		 *	----------------------------------------------------------------------	*/	
		
		int c , l ;
		
		for( c = 0 ;  c < 8 ; c++ )
		{
			for( l = 0 ; l < 8 ; l++ )
			{
				echiquier[c][l].Definir_Piece( modele.getpiece(c,l) ) ;
			}
		}
		base_brute = modele ;
		defini = true ;
	}
	public void Definir_CampMaitre( boolean modele )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> boolean	modele : camp � choisir
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction d�finit le camp maitre de la grille.
		 *	----------------------------------------------------------------------	*/	
		
		camp_maitre = modele ;
	}
	public boolean Est_Defini()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> boolean	return : statut de la d�finition
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction indique si la grille a d�j� �t� d�finie.
		 *	----------------------------------------------------------------------	*/	
		
		return defini ;
	}
	public int Get_Type( int c , int l )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> boolean	return : camp maitre
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction renvoie le camp maitre de la grille.
		 *	----------------------------------------------------------------------	*/	
		
		return base_brute.gettype_piece(c,l) ;
	}
	public boolean Get_Camp()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> boolean	return : camp maitre
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction renvoie le camp maitre de la grille.
		 *	----------------------------------------------------------------------	*/	
		
		return camp_maitre ;
	}
	public void Identifier( int get_deg , int get_camp , int get_id )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> int	get_deg 	: degr� � attribuer
		 *				> int	get_camp	: camp (brut) � attribuer
		 *				> int	get_id		: ID � attribuer
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet l'identification d'une grille potentielle.
		 *	----------------------------------------------------------------------	*/	
		
		degree	= get_deg ;
		id		= get_id ;
		camp	= get_camp ;
	}
    public boolean Editer_Facteurs( int c_base , int l_base , int c_second , int l_second )
    {
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> int		c_base		: colonne de la pi�ce � �diter
		 *				> int		l_base		: ligne de la pi�ce � �diter
		 *				> int		c_second	: colonne de la pi�ce rep�re
		 *				> int		l_second	: ligne de la pi�ce rep�re
		 *	[Retours]	> boolean	return : rapport entre les pi�ces
		 *	[Notes]		> Renvoie TRUE si pi�ce alli�es, FALSE si pi�ce adverses
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction �dite les facteurs d'une pi�ce donn�e en fonction de ses rapports avec une autre pi�ce du damier.
		 *	----------------------------------------------------------------------	*/	
    	
    	if( echiquier[c_base][l_base].base.getcouleur() == echiquier[c_second][l_second].base.getcouleur() )
    	{
    		echiquier[c_base][l_base].FC 		+= echiquier[c_second][l_second].Donner_Valeur() ;
    		echiquier[c_base][l_base].FC_c 		++ ;
    		echiquier[c_second][l_second].FS	+= echiquier[c_base][l_base].Donner_Valeur() ;
    		echiquier[c_second][l_second].FS_c	++ ;
    		
    		return true ;
    	}
    	
    	else
    	{
    		echiquier[c_base][l_base].FP 		+= echiquier[c_second][l_second].Donner_Valeur() ;
    		echiquier[c_base][l_base].FP_c 		++ ;
    		echiquier[c_second][l_second].FM	+= echiquier[c_base][l_base].Donner_Valeur() ;
    		echiquier[c_second][l_second].FM_c	++ ;
    		
    		return false ;
    	}
    }
    public void Definir_Coup_P( int c_d , int l_d , int c_a , int l_a )
    {	
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> int	c_d : colonne de d�part
		 *				> int	l_d	: ligne de d�part
		 *				> int	c_a : colonne d'arriv�e
		 *				> int	l_a : ligne d'arriv�e
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction d�finit un coup potentiel sur la grille.
		 *	----------------------------------------------------------------------	*/	
    	
    	liste_coups[index_coups].colonne_d	= c_d ;
    	liste_coups[index_coups].ligne_d 	= l_d ;
    	liste_coups[index_coups].colonne_a	= c_a ;
    	liste_coups[index_coups].ligne_a	= l_a ;
    	liste_coups[index_coups].jouee		= echiquier[c_d][l_d] ;
    	liste_coups[index_coups].prise		= echiquier[c_a][l_a] ;
    	liste_coups[index_coups].defini		= true ;
    	index_coups++ ;
    }
    public void Definir_Derivees()
    {
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction calcule les caract�ristiques d�riv�es de la grille en cours.
		 *	----------------------------------------------------------------------	*/	
    	
    	PA = AT - DI ;
    	RS = DE - RI ;
    	PT = LI - OP ;
    }
    public void Nettoyer_Stats()
    {
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction nettoie les caract�ristiques locales.
		 *	----------------------------------------------------------------------	*/	
    	
    	AT = 0 ;
    	DE = 0 ;
    	RI = 0 ;
    	DI = 0 ;
    	LI = 0 ;
    	OP = 0 ;
    	CO = 0 ;
    	PR = 0 ;
    	EQ = 0 ;
    	PA = 0 ;
    	RS = 0 ;
    	PT = 0 ;
    }
    public void	Nettoyer_Coups_P()
    {
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction nettoie les coups potentiels.
		 *	----------------------------------------------------------------------	*/	
    	
    	int i ;
    	
    	for( i = 0 ; i <= index_coups ; i++)
    	{
    		liste_coups[i] = new Coup_P() ;
    	}
    	
    	index_coups = 0 ;
    }
}

class Coup_P
{
	int						ligne_d = 9 , colonne_d = 9 ;
	int						ligne_a = 9 , colonne_a = 9 ;
	boolean					defini = false ;
	Piece_P					jouee = new Piece_P() ;
	Piece_P					prise = new Piece_P() ;
	
	public Coup_P()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> Les variables de la classe sont modifi�es par acc�s direct.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de la classe coup potentiel.
		 *	----------------------------------------------------------------------	*/	
		
		jouee = null ;
		prise = null ;
	}
}


class Piece_P
{
	HERMES					hermes = new HERMES(11) ;
	MORPHEE					configuration = new MORPHEE() ;
	Piece					base = new Piece() ;
	int						FP = 0 , FC = 0 , FM = 0 , FS = 0 ;
	double					FP_d = 0 , FC_d = 0 , FM_d = 0 , FS_d = 0 ;
	int						FP_c = 0 , FC_c = 0 , FM_c = 0 , FS_c = 0 ;
	boolean					etudiee = false ;
	
	
	public Piece_P()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de la classe pi�ce potentielle.
		 *	----------------------------------------------------------------------	*/	
		
		base = null ;
	}
	public Piece_P( Piece_P modele )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Piece_P	modele	: pi�ce potentielle � recopier
		 *	[Retours]	> N/A
		 *	[Notes]		> Constructeur secondaire.
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de la classe pi�ce potentielle, prenant pour mod�le une pi�ce potentielle existante.
		 *	----------------------------------------------------------------------	*/	
		
		base = new Piece( modele.base ) ;
	}
	public void Definir_Piece( Piece modele )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Piece	modele	: pi�ce � recopier
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction permet d'enregistrer les informations du pi�ce simple dans la classe pi�ce potentielle.
		 *	----------------------------------------------------------------------	*/	
		
		base = modele ;
	}
	public void Confirmer_Etude()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction prend en compte l'�tude de la pi�ce potentielle.
		 *	----------------------------------------------------------------------	*/	
		
		etudiee = true ;
	}
	public boolean Est_Etudiee()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> boolean	return : valeur d'�tude de la pi�ce potentielle
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction retourne l'�tat de l'�tude de la pi�ce potentielle.
		 *	----------------------------------------------------------------------	*/	
		
		return etudiee ;
	}
	public int Donner_Valeur()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> int	return : valeur de la pi�ce en points
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction retourne la valeur brute de la pi�ce.
		 *	----------------------------------------------------------------------	*/	
		
		if( base.gettype() == 1 )				return configuration.Get_Var(4) ;
		if( base.gettype() == 2 )				return configuration.Get_Var(5) ;
		if( base.gettype() == 3 )				return configuration.Get_Var(6) ;
		if( base.gettype() == 4 )				return configuration.Get_Var(7) ;
		if( base.gettype() == 5 )				return configuration.Get_Var(8) ;
		if( base.gettype() == 6 )				return configuration.Get_Var(9) ;
												return 0 ;
	}
	public void Generer_Derivees()
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> N/A
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction g�n�re les caract�ristiques d�riv�es.
		 *	----------------------------------------------------------------------	*/	
		
		if( FP_c != 0 )					FP_d = FP / FP_c ;
		else							FP_d = -1 ;
		
		if( FC_c != 0 )					FC_d = FC / FC_c ;
		else							FC_d = -1 ;
		
		if( FM_c != 0 )					FM_d = FM / FM_c ;
		else							FM_d = -1 ;
		
		if( FS_c != 0 )					FS_d = FS / FS_c ;
		else							FS_d = -1 ;
	}
}

class Pack_Stat
{
	HERMES					hermes = new HERMES(12) ;
	MORPHEE					configuration = new MORPHEE() ;
	
	double					AT = 0 , DE = 0 , RI = 0 , DI = 0 ;
	double					LI = 0 , OP = 0 , CO = 0 , PR = 0 , EQ = 0 ;
	double					PA = 0 , RS = 0 , PT = 0 ;
	int						degree_origine , camp_origine , id_origine ;
	boolean					defini = false ;
	double					coefficient_interet ;
	boolean					fertile = false ;
	boolean					sterile = false ;
	int						coup_pere ;
	int						genealogie ;
	
	
	public Pack_Stat( int d_o , int c_o , int i_o )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> int	d_o	: degr� de la grille ayant �mis le pack
		 *				> int	c_o : camp (absolu) de la grille ayant �mis le pack
		 *				> int	i_o : ID de la grille ayant �mis le pack
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Constructeur de la classe pack statistique.
		 *	----------------------------------------------------------------------	*/	
		
		degree_origine 	= d_o ;
		camp_origine	= c_o ;
		id_origine		= i_o ;
	}
	public void Stocker( Situation_P base , int id_p )
	{
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> Situation_P	base	: rep�re pr�-�tudier
		 *				> int			id_p	: ID de la grille m�re
		 *	[Retours]	> N/A
		 *	[Notes]		> N/A
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction recopie les caract�ristiques pr�-calcul�es dans le pack de statistiques.
		 *	----------------------------------------------------------------------	*/	
		
		if( base.base_brute.echec_roi( base.camp_maitre ) )					sterile = true ;
		
		AT = base.AT ;
		DE = base.DE ;
		RI = base.RI ;
		DI = base.DI ;
		LI = base.LI ;
		OP = base.OP ;
		CO = base.CO ;
		PR = base.PR ;
		EQ = base.EQ ;
		PA = base.PA ;
		RS = base.RS ;
		PT = base.PT ;
		
		coup_pere = id_p ;
		
		defini = true ;
	}
    public void Definir_Finaux( MORPHEE configuration )
    {
		/*	----------------------------------------------------------------------
		 *	[Arguments]	> MORPHEE	configuration	: configuration globale
		 *	[Retours]	> N/A
		 *	[Notes]		> [!] Entit� de calcul arbitraire
		 *				> Peut �tre librement �dit�e. Caract�ristiques �tudi�es : PA | RS | PT | Coefficient d'int�r�t
		 *	----------------------------------------------------------------------
		 *	[Descriptif]
		 *	Cette fonction synth�tise les informations contenues dans le pack pour g�n�rer le coefficient d'int�r�t.
		 *	----------------------------------------------------------------------	*/	
    	
    	PA = AT + DE ;
    	RS = DI + RI ;
    	if( LI - CO > 0 )
    	{
    		PT = LI - CO ;
    	}
    	else PT = 0 ;
    	
    	coefficient_interet = ( ( configuration.Get_Var(22) * PA ) + ( configuration.Get_Var(23) * RS ) + ( configuration.Get_Var(24) * PT ) ) + ( ( configuration.Get_Var(25) * OP ) - ( configuration.Get_Var(26) * PR ) ) + ( configuration.Get_Var(27) * EQ ) ;
    }
}

//======================================================================================
//									===== Divers =====
//======================================================================================

class Echiquier
{ 
    int rocknd=0,rockng=0,rockbg=0,rockbd=0;
    int colonne,ligne;
    int i,j;
    Piece[][] tableaupiece=null;//tableau de type Piece d?lar? et initialis?

    public Echiquier()//constructeur initialis? pour 64 cases
    { 
	tableaupiece = new Piece[8][8];
	for(i=0;i<8;i++)
	    {
		for(j=0;j<8;j++)
		    {
			tableaupiece[i][j]=new Piece();
		    }
	    }
	
	//initialisation des pions du haut
	
	for(j=0;j<8;j++){
	    tableaupiece[j][1].setcouleurandtype(false,1);//en fait cest la deuxieme ligne(1) donc on dit qu'ils sont noirs=false
	}
	//initialisation des pions du bas
	
	for(j=0;j<8;j++){
	    tableaupiece[j][6].setcouleurandtype(true,1);//en fait cest l'avant derniere ligne(7) donc on dit qu'ils sont blancs=true
	}
	//initialisation des persos du haut
	//a chaque numero correspont un type de piece : ex:pion=1, 2=tour, 3=fou, 4=cavalier et 5=roi, 6=reine
	tableaupiece[0][0].setcouleurandtype(false,2);
	tableaupiece[1][0].setcouleurandtype(false,4);
	tableaupiece[2][0].setcouleurandtype(false,3);
	tableaupiece[3][0].setcouleurandtype(false,6);
	tableaupiece[4][0].setcouleurandtype(false,5);
	tableaupiece[5][0].setcouleurandtype(false,3);
	tableaupiece[6][0].setcouleurandtype(false,4);
	tableaupiece[7][0].setcouleurandtype(false,2);
	
	//initialisation des persos du bas
	//la meme mais pour les blancs
	tableaupiece[0][7].setcouleurandtype(true,2);
	tableaupiece[1][7].setcouleurandtype(true,4);
	tableaupiece[2][7].setcouleurandtype(true,3);
	tableaupiece[3][7].setcouleurandtype(true,6);
	tableaupiece[4][7].setcouleurandtype(true,5);
	tableaupiece[5][7].setcouleurandtype(true,3);
	tableaupiece[6][7].setcouleurandtype(true,4);
	tableaupiece[7][7].setcouleurandtype(true,2);
    }
    public int rock(boolean couleur)
    {
	boolean noir_gauche=false,noir_droite=false,blanc_gauche=false,blanc_droite=false;
	JOptionPane d = new JOptionPane();
	String lesTextesRock[]={ "oui", "non"};
	String lesTextesRock2[]={"gauche","droite"};
	int rock_choice=1;
	int choix=1;
	int rock_possibilite=0;
	
	if(couleur==false)
	    {
		if(tableaupiece[5][0].gettype()==0 && tableaupiece[6][0].gettype()==0  && rocknd==0)
		    {
			noir_gauche=true;
			rock_possibilite=1;
		    }
		
		if(tableaupiece[1][0].gettype()==0 && tableaupiece[2][0].gettype()==0 && tableaupiece[3][0].gettype()==0 && rockng==0)
		    {
			noir_droite=true;
			rock_possibilite=1;
		    }
	    }
	else if(couleur==true)
	    {
		if(tableaupiece[5][7].gettype()==0 && tableaupiece[6][7].gettype()==0  && rockbd==0) 
		    {
			blanc_gauche=true;
			rock_possibilite=1;
		    }
		
		if(tableaupiece[1][7].gettype()==0 && tableaupiece[2][7].gettype()==0 && tableaupiece[3][7].gettype()==0 && rockbg==0) 
		    {
			blanc_droite=true;
			rock_possibilite=1;
		    }
	    }

	if(rock_possibilite==1)
	    {
		choix = JOptionPane.showOptionDialog(d, "Voulez faire un rock: ", "Question ?", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, lesTextesRock, lesTextesRock[0]);
		
		if(choix==1){rock_choice=1;}
		
		
		else if(choix==0 && blanc_droite==true && blanc_gauche==true)
		    {
			rock_choice=0;
			int choix2 = JOptionPane.showOptionDialog(d, "Voulez faire un rock: ", "Question ?", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, lesTextesRock2, lesTextesRock2[0]);
			if(choix2==0)
			    {
				tableaupiece[4][7].setcouleurandtype(false, 0);
				tableaupiece[2][7].setcouleurandtype(true, 5);
				tableaupiece[0][7].setcouleurandtype(false, 0);
				tableaupiece[3][7].setcouleurandtype(true, 2);
			    }
			
			else if(choix2==1)
			    {
				tableaupiece[4][7].setcouleurandtype(false, 0);
				tableaupiece[6][7].setcouleurandtype(true, 5);
				tableaupiece[7][7].setcouleurandtype(false, 0);
				tableaupiece[5][7].setcouleurandtype(true, 2);
			    }
		    }
		
		else if(choix==0 && blanc_droite==true && blanc_gauche==false)
		    {
			rock_choice=0;
			tableaupiece[4][7].setcouleurandtype(false, 0);
			tableaupiece[6][7].setcouleurandtype(true, 5);
			tableaupiece[7][7].setcouleurandtype(false, 0);
			tableaupiece[5][7].setcouleurandtype(true, 2);
		    }
		
		else if(choix==0 && blanc_droite==false && blanc_gauche==true)
		    {
			rock_choice=0;
			tableaupiece[4][7].setcouleurandtype(false, 0);
			tableaupiece[2][7].setcouleurandtype(true, 5);
			tableaupiece[0][7].setcouleurandtype(false, 0);
			tableaupiece[3][7].setcouleurandtype(true, 2);
		    }
		
		else if(choix==0 && noir_droite==true && noir_gauche==true)
		    {
			rock_choice=0;
			int choix2 = JOptionPane.showOptionDialog(d, "Voulez faire un rock: ", "Question ?", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, lesTextesRock2, lesTextesRock2[0]);
			if(choix2==0)
			    {
				tableaupiece[4][0].setcouleurandtype(false, 0);
				tableaupiece[2][0].setcouleurandtype(false, 5);
				tableaupiece[0][0].setcouleurandtype(false, 0);
				tableaupiece[3][0].setcouleurandtype(false, 2);
			    }
			
			else if(choix2==1)
			    {
				tableaupiece[4][0].setcouleurandtype(false, 0);
				tableaupiece[6][0].setcouleurandtype(false, 5);
				tableaupiece[7][0].setcouleurandtype(false, 0);
				tableaupiece[5][0].setcouleurandtype(false, 2);
			    }
		    }
		
		else if(choix==0 && noir_droite==true && noir_gauche==false)
		    {
			rock_choice=0;
			tableaupiece[4][0].setcouleurandtype(false, 0);
			tableaupiece[6][0].setcouleurandtype(false, 5);
			tableaupiece[7][0].setcouleurandtype(false, 0);
			tableaupiece[5][0].setcouleurandtype(false, 2);
		    }
		
		else if(choix==0 && blanc_droite==false && blanc_gauche==true)
		    {
			rock_choice=0;
			tableaupiece[4][0].setcouleurandtype(false, 0);
			tableaupiece[2][0].setcouleurandtype(false, 5);
			tableaupiece[0][0].setcouleurandtype(false, 0);
			tableaupiece[3][0].setcouleurandtype(false, 2);
		    }
	    }
	return rock_choice;
    }
    public boolean echec_roi(boolean camp)
    {
    	// Donner en argument le camp concerne.
    	// Renvoie true si le roi est en echec, false sinon.
    	
    	boolean camp_attaque;
    	int c,l,i=0;
	boolean echec=false;    	

    	if(camp)
	    camp_attaque = false;
    	else
	    camp_attaque = true;
    	
    	coup_sur_roi(camp_attaque);

		for(c=0;c<8;c++)
		    {
			for(l=0;l<8;l++)
			    {
				if(gettype_piece(l,c)==5 && getcouleur_piece(l,c)==camp)
				    {
					if(tableaupiece[l][c].attaquabilite==true)
					    {echec=true;}
					else
					    echec=false;
				    }
			    }
		    }
	
    	return echec;
    }
    public boolean echec_et_mat(Echiquier echiquier_base,boolean camp)
    {
    	// Donner en argument l'echiquier en cours et le camp concerne. 
    	// Renvoie true si celui-ci est en echec et mat, false sinon.
    	
    	int c,l,c2,l2;
    	Echiquier simulation ;
    	
    	for(c=0;c<8;c++)
	    {
    		for(l=0;l<8;l++)
		    {
    			if(echiquier_base.getcouleur_piece(c,l)==camp)
			    {
    				couppossible(c,l);
				
    				for(c2=0;c2<8;c2++)
				    {
    					for(l2=0;l2<8;l2++)
					    {	
    						if(tableaupiece[c2][l2].getpossibilite())
						    {
    							simulation = new Echiquier( echiquier_base ) ;
    							simulation.tableaupiece[c2][l2].setcouleurandtype(echiquier_base.getcouleur_piece(c,l),echiquier_base.gettype_piece(c,l));
    							simulation.tableaupiece[c][l].setcouleurandtype(false,0);
							
    							if(!simulation.echec_roi(camp))
							    return false;
						    }
					    }
				    }
			    }
		    }
	    }
    	
    	return true;
    }
    public void coup_sur_roi(boolean couleur)
    {
	/*********************************************/
	/*mettre attaquabilite a 0 avant de commencer*/
	/*********************************************/
	int i,j;

	free_attaquabilite();
	for(i=0;i<8;i++)
	    {
		for(j=0;j<8;j++)
		    {
			if(tableaupiece[j][i].gettype()!=0)
			    {
				if(tableaupiece[j][i].getcouleur()==couleur || tableaupiece[j][i].gettype()==5)
				    {
					if(tableaupiece[j][i].gettype()==1)//pion noir et blanc
					    {
						if(tableaupiece[j][i].getcouleur()==false)
						    {
							if(i+1<8 && j+1<8)
							    {
								tableaupiece[j+1][i+1].attaquabilite=true;
							    }
							if(j-1>=0 && i+1<8)
							    {
								tableaupiece[j-1][i+1].attaquabilite=true;
							    }
						    }
						if(tableaupiece[j][i].getcouleur()==true || tableaupiece[j][i].gettype()==5)
						    {
							if(j+1<8 && i-1>=0)
							    {
								tableaupiece[j+1][i-1].attaquabilite=true;
							    }
							if(j-1>=0 && i-1>=0)
							    {
								tableaupiece[j-1][i-1].attaquabilite=true;
							    }
						    }
					    }
						
					if(tableaupiece[j][i].gettype()==2)//tour
					    {
						int deplac_gauche=0,deplac_droite=0,deplac_haut=0,deplac_bas=0;
		
						for(int x=1;x<=8;x++)
						    {
							if(deplac_gauche==0 || deplac_droite==0 || deplac_haut==0 || deplac_bas==0)
							    {
								//1
								if(j+x<8)
								    if(tableaupiece[j+x][i].gettype()==0 && deplac_droite==0)
									{  
									    tableaupiece[j+x][i].attaquabilite=true;
									}
								    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j+x][i].getcouleur() || tableaupiece[j+x][i].gettype()==5) && deplac_droite==0)
									{
									    tableaupiece[j+x][i].attaquabilite=true;
									    deplac_droite++;
									}
								    else deplac_droite++;
								//2
								if(j-x>=0)
								    if(tableaupiece[j-x][i].gettype()==0 && deplac_gauche==0)
									{  
									    tableaupiece[j-x][i].attaquabilite=true;
									}
								    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j-x][i].getcouleur() || tableaupiece[j-x][i].gettype()==5) && deplac_gauche==0)
									{
									    tableaupiece[j-x][i].attaquabilite=true;
									    deplac_gauche++;
									}
								    else deplac_gauche++;
								
								//3
								if(i+x<8)
								    if(tableaupiece[j][i+x].gettype()==0 && deplac_bas==0)
									{  
									    tableaupiece[j][i+x].attaquabilite=true;
									}
								    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j][i+x].getcouleur() || tableaupiece[j][i+x].gettype()==5) && deplac_bas==0)
									{
									    tableaupiece[j][i+x].attaquabilite=true;
									    deplac_bas++;
									}
								    else deplac_bas++;
								
								//4
								if(i-x>=0)
								    if(tableaupiece[j][i-x].gettype()==0 && deplac_haut==0)
									{  
									    tableaupiece[j][i-x].attaquabilite=true;
									}
								    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j][i-x].getcouleur() || tableaupiece[j][i-x].gettype()==5) && deplac_haut==0)
									{
									    tableaupiece[j][i-x].attaquabilite=true;
									    deplac_haut++;
									}
								    else deplac_haut++;
							    }
						    }
						
					    }
					
					if(tableaupiece[j][i].gettype()==4)//cavalier
					    {
						if(j+1<8 && i+2<8)
						    if(tableaupiece[j+1][i+2].gettype()==0)
							tableaupiece[j+1][i+2].attaquabilite=true;
						    else if(tableaupiece[j][i].getcouleur()==tableaupiece[j][i].getcouleur())
							tableaupiece[j+1][i+2].attaquabilite=true;
							
						if(j+2<8 && i+1<8)
						    if(tableaupiece[j+2][i+1].gettype()==0)
							tableaupiece[j+2][i+1].attaquabilite=true;
						    else if(tableaupiece[j][i].getcouleur()==tableaupiece[j][i].getcouleur())
							tableaupiece[j+2][i+1].attaquabilite=true;
					
						if(j-1>=0 && i-2>=0)
						    if(tableaupiece[j-1][i-2].gettype()==0)
							tableaupiece[j-1][i-2].attaquabilite=true;
						    else if(tableaupiece[j][i].getcouleur()==tableaupiece[j][i].getcouleur())
							tableaupiece[j-1][i-2].attaquabilite=true;
					
						if(j-2>=0 && i-1>=0)
						    if(tableaupiece[j-2][i-1].gettype()==0)
							tableaupiece[j-2][i-1].attaquabilite=true;
						    else if(tableaupiece[j][i].getcouleur()==tableaupiece[j][i].getcouleur())
							tableaupiece[j-2][i-1].attaquabilite=true;
						
						if(j-2>=0 && i+1<8)
						    if(tableaupiece[j-2][i+1].gettype()==0)
							tableaupiece[j-2][i+1].attaquabilite=true;
						    else if(tableaupiece[j][i].getcouleur()==tableaupiece[j][i].getcouleur())
							tableaupiece[j-2][i+1].attaquabilite=true;

						if(j+1<8 && i-2>=0)
						    if(tableaupiece[j+1][i-2].gettype()==0)
							tableaupiece[j+1][i-2].attaquabilite=true;
						    else if(tableaupiece[j][i].getcouleur()==tableaupiece[j][i].getcouleur())
							tableaupiece[j+1][i-2].attaquabilite=true;
						if(j-1>=0 && i+2<8)
						    if(tableaupiece[j-1][i+2].gettype()==0)
							tableaupiece[j-1][i+2].attaquabilite=true;
						    else if(tableaupiece[j][i].getcouleur()==tableaupiece[j][i].getcouleur())
							tableaupiece[j-1][i+2].attaquabilite=true;
						if(j+2<8 && i-1>=0)
						    if(tableaupiece[j+2][i-1].gettype()==0)
							tableaupiece[j+2][i-1].attaquabilite=true;
						    else if(tableaupiece[j][i].getcouleur()==tableaupiece[j][i].getcouleur())
							tableaupiece[j+2][i-1].attaquabilite=true;
					    }
					
					if(tableaupiece[j][i].gettype()==3)//fou
					    {
						int deplac_hautgauche=0,deplac_hautdroite=0,deplac_basgauche=0,deplac_basdroite=0;
						
						for(int x=1;x<=8;x++)
						    {
							//1
							if(j+x<8 && i+x<8)
							    if(tableaupiece[j+x][i+x].gettype()==0 && deplac_basdroite==0)
								tableaupiece[j+x][i+x].attaquabilite=true;
							    else
								if((tableaupiece[j+x][i+x].getcouleur()==tableaupiece[j][i].getcouleur() || tableaupiece[j+x][i+x].gettype()==5) && deplac_basdroite==0)
								    {
									tableaupiece[j+x][i+x].attaquabilite=true;
									deplac_basdroite++;
								    }
								else deplac_basdroite++;
							//2
							if(j-x>=0 && i-x>=0)
							    if(tableaupiece[j-x][i-x].gettype()==0 && deplac_hautgauche==0)
								tableaupiece[j-x][i-x].attaquabilite=true;
							    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j-x][i-x].getcouleur() || tableaupiece[j-x][i-x].gettype()==5) && deplac_hautgauche==0)
								{
								    tableaupiece[j-x][i-x].attaquabilite=true;
								    deplac_hautgauche++;
								}
							    else deplac_hautgauche++;
							//3
							if(j+x<8 && i-x>=0)
							    if(tableaupiece[j+x][i-x].gettype()==0 && deplac_hautdroite==0)
								tableaupiece[j+x][i-x].attaquabilite=true;
							    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j+x][i-x].getcouleur() || tableaupiece[j+x][i-x].gettype()==5) && deplac_hautdroite==0)
								{
								    tableaupiece[j+x][i-x].attaquabilite=true;
								    deplac_hautdroite++;
								}
							    else deplac_hautdroite++;
							//4
							if(j-x>=0 && i+x<8)
							    if(tableaupiece[j-x][i+x].gettype()==0 && deplac_basgauche==0)
								tableaupiece[j-x][i+x].attaquabilite=true;
							    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j-x][i+x].getcouleur() || tableaupiece[j-x][i+x].gettype()==5) && deplac_basgauche==0)
								{
								    tableaupiece[j-x][i+x].attaquabilite=true;
								    deplac_basgauche++;
								}
							    else deplac_basgauche++;
						    }
					    }
					if(tableaupiece[j][i].gettype()==5)//roi
					    {
						if(tableaupiece[j][i].getcouleur()==couleur){
						    //mouvements de type tour
						    //1
						    if(j+1<8)
						    if(tableaupiece[j+1][i].gettype()==0)
							{  
							    tableaupiece[j+1][i].attaquabilite=true;
							}
						    else if( tableaupiece[j][i].getcouleur()==tableaupiece[j+1][i].getcouleur())
							tableaupiece[j+1][i].attaquabilite=true;
						    
						    //2
						    if(j-1>=0)
							if(tableaupiece[j-1][i].gettype()==0)
							    {  
								tableaupiece[j-1][i].attaquabilite=true;
							    }
							else if(tableaupiece[j][i].getcouleur()==tableaupiece[j-1][i].getcouleur())
							    tableaupiece[j-1][i].attaquabilite=true;
						    
						    
						    
						    //3
						    if(i+1<8)
							if(tableaupiece[j][i+1].gettype()==0)
							    {  
							    tableaupiece[j][i+1].attaquabilite=true;
							    }
							else if(tableaupiece[j][i].getcouleur()==tableaupiece[j][i+1].getcouleur())
							    tableaupiece[j][i+1].attaquabilite=true;
						    
						    //4
						    if(i-1>=0)
							if(tableaupiece[j][i-1].gettype()==0)
							    {  
								tableaupiece[j][i-1].attaquabilite=true;
							}
							else if( tableaupiece[j][i].getcouleur()==tableaupiece[j][i-1].getcouleur())
							    tableaupiece[j][i-1].attaquabilite=true;
						    
						    
						    //mouvements de type fou
						    //1
						    if(j+1<8 && i+1<8)
							if(tableaupiece[j+1][i+1].gettype()==0)
							    tableaupiece[j+1][i+1].attaquabilite=true;
							else
							    if(tableaupiece[j+1][i+1].getcouleur()==tableaupiece[j][i].getcouleur())
								tableaupiece[j+1][i+1].attaquabilite=true;
						    
						    //2
						    if(j-1>=0 && i-1>=0)
							if(tableaupiece[j-1][i-1].gettype()==0)
							    tableaupiece[j-1][i-1].attaquabilite=true;
							else if(tableaupiece[j][i].getcouleur()==tableaupiece[j-1][i-1].getcouleur())
							    tableaupiece[j-1][i-1].attaquabilite=true;
						    
						    //3
						    if(j+1<8 && i-1>=0)
							if(tableaupiece[j+1][i-1].gettype()==0)
							    tableaupiece[j+1][i-1].attaquabilite=true;
							else if(tableaupiece[j][i].getcouleur()==tableaupiece[j+1][i-1].getcouleur())
							tableaupiece[j+1][i-1].attaquabilite=true;
						    
						    //4
						    if(j-1>=0 && i+1<8)
							if(tableaupiece[j-1][i+1].gettype()==0)
							    tableaupiece[j-1][i+1].attaquabilite=true;
							else if(tableaupiece[j][i].getcouleur()==tableaupiece[j-1][i+1].getcouleur())							
							tableaupiece[j-1][i+1].attaquabilite=true;
						}	
					    }	
					
					if(tableaupiece[j][i].gettype()==6)//reine
					    {
						int deplac_gauche=0,deplac_droite=0,deplac_haut=0,deplac_bas=0;
						
						for(int x=1;x<=8;x++)
						    {
							if(deplac_gauche==0 || deplac_droite==0 || deplac_haut==0 || deplac_bas==0)
							    {
								//1
								if(j+x<8)
								    if(tableaupiece[j+x][i].gettype()==0 && deplac_droite==0)
									{  
									    tableaupiece[j+x][i].attaquabilite=true;
									}
								    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j+x][i].getcouleur() || tableaupiece[j+x][i].gettype()==5) && deplac_droite==0)
									{
									    tableaupiece[j+x][i].attaquabilite=true;
									    deplac_droite++;
									}
								    else deplac_droite++;
								//2
								if(j-x>=0)
								    if(tableaupiece[j-x][i].gettype()==0 && deplac_gauche==0)
									{  
									    tableaupiece[j-x][i].attaquabilite=true;
									}
								    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j-x][i].getcouleur() || tableaupiece[j-x][i].gettype()==5) && deplac_gauche==0)
									{
									    tableaupiece[j-x][i].attaquabilite=true;
									    deplac_gauche++;
									}
								    else deplac_gauche++;
								
								//3
								if(i+x<8)
								    if(tableaupiece[j][i+x].gettype()==0 && deplac_bas==0)
									{  
									    tableaupiece[j][i+x].attaquabilite=true;
									}
								    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j][i+x].getcouleur() || tableaupiece[j][i+x].gettype()==5) && deplac_bas==0)
									{
									    tableaupiece[j][i+x].attaquabilite=true;
									    deplac_bas++;
									}
								    else deplac_bas++;
								
								//4
								if(i-x>=0)
								    if(tableaupiece[j][i-x].gettype()==0 && deplac_haut==0)
									{  
									    tableaupiece[j][i-x].attaquabilite=true;
									}
								    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j][i-x].getcouleur() || tableaupiece[j][i-x].gettype()==5) && deplac_haut==0)
									{
									    tableaupiece[j][i-x].attaquabilite=true;
									    deplac_haut++;
									}
								    else deplac_haut++;
							    }
						    }
						
						int deplac_hautgauche=0,deplac_hautdroite=0,deplac_basgauche=0,deplac_basdroite=0;
						
						for(int x=1;x<=8;x++)
						    {
							//1
							if(j+x<8 && i+x<8)
							    if(tableaupiece[j+x][i+x].gettype()==0 && deplac_basdroite==0)
								tableaupiece[j+x][i+x].attaquabilite=true;
							    else
								if((tableaupiece[j+x][i+x].getcouleur()==tableaupiece[j][i].getcouleur() || tableaupiece[j+x][i+x].gettype()==5) && deplac_basdroite==0)
								    {
									tableaupiece[j+x][i+x].attaquabilite=true;
									deplac_basdroite++;
								    }
								else deplac_basdroite++;
							//2
							if(j-x>=0 && i-x>=0)
							    if(tableaupiece[j-x][i-x].gettype()==0 && deplac_hautgauche==0)
								tableaupiece[j-x][i-x].attaquabilite=true;
							    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j-x][i-x].getcouleur() || tableaupiece[j-x][i-x].gettype()==5) && deplac_hautgauche==0)
								{
								    tableaupiece[j-x][i-x].attaquabilite=true;
								    deplac_hautgauche++;
								}
							    else deplac_hautgauche++;
							//3
							if(j+x<8 && i-x>=0)
							    if(tableaupiece[j+x][i-x].gettype()==0 && deplac_hautdroite==0)
								tableaupiece[j+x][i-x].attaquabilite=true;
							    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j+x][i-x].getcouleur() || tableaupiece[j+x][i-x].gettype()==5) && deplac_hautdroite==0)
								{
								    tableaupiece[j+x][i-x].attaquabilite=true;
								    deplac_hautdroite++;
								}
							    else deplac_hautdroite++;
							//4
							if(j-x>=0 && i+x<8)
							    if(tableaupiece[j-x][i+x].gettype()==0 && deplac_basgauche==0)
								tableaupiece[j-x][i+x].attaquabilite=true;
							    else if((tableaupiece[j][i].getcouleur()==tableaupiece[j-x][i+x].getcouleur() || tableaupiece[j-x][i+x].gettype()==5) && deplac_basgauche==0)
								{
								    tableaupiece[j-x][i+x].attaquabilite=true;
								    deplac_basgauche++;
								}
							    else deplac_basgauche++;
						    }
						
					    }
				    }
			    }
		    }
	    }
    } 
    public void couppossible(int colonne, int ligne)
    {
	int typepiece;
	typepiece=tableaupiece[colonne][ligne].gettype();
	
	for(int x=0;x<8;x++)
	    {
		for(int y=0;y<8;y++)
		    {
			tableaupiece[x][y].possibilite=false;
		    }
	    }
	
	if(typepiece == 1)//pion
	    {
		//debut cas pion noir
		if(tableaupiece[colonne][ligne].getcouleur()==false)
		    {//si pion est noir
			if(tableaupiece[colonne][ligne+1].gettype()==0)
			    {//et case vide 
				if(ligne==1 && tableaupiece[colonne][ligne+2].gettype()==0)
				    tableaupiece[colonne][ligne+2].possibilite=true;
				tableaupiece[colonne][ligne+1].possibilite=true;
			    }
			
			//deplacement offensif, le pion attaque une piece
			if( colonne!=7)
			    if(tableaupiece[colonne+1][ligne+1].gettype()!=0 && tableaupiece[colonne+1][ligne+1].getcouleur()!=false )
				{
				    tableaupiece[colonne+1][ligne+1].possibilite=true;
				}
			if( colonne!=0)
			    if(tableaupiece[colonne-1][ligne+1].gettype()!=0 && tableaupiece[colonne-1][ligne+1].getcouleur()!=false  )
				{
				    tableaupiece[colonne-1][ligne+1].possibilite=true;
				}
			//fin du scenario de l'attaque
		    }
		//fin premier cas pion noir
		
		//debut cas pion blanc
		else if(tableaupiece[colonne][ligne].getcouleur()==true)
		    {//blanc
			if(tableaupiece[colonne][ligne-1].gettype()==0)
			    {//case vide
				if(ligne==6 && tableaupiece[colonne][ligne-2].gettype()==0)
				    tableaupiece[colonne][ligne-2].possibilite=true;
				tableaupiece[colonne][ligne-1].possibilite=true;
			    }
			
		    	//deplacement offensif, le pion attaque une piece
			if(colonne!=7)
			if(tableaupiece[colonne+1][ligne-1].gettype()!=0 && tableaupiece[colonne+1][ligne+1].getcouleur()!=true )
			    {
				tableaupiece[colonne+1][ligne-1].possibilite=true;
			    }
			if(colonne!=0)
			if(tableaupiece[colonne-1][ligne-1].gettype()!=0 && tableaupiece[colonne-1][ligne+1].getcouleur()!=true )
			    {
				tableaupiece[colonne-1][ligne-1].possibilite=true;
			    }
			//fin du scenario de l'attaque
			
		    	//fin cas pion blanc
		    }
	    }	
	
	//tour
	if(typepiece == 2)
	    {	
		int deplac_gauche=0,deplac_droite=0,deplac_haut=0,deplac_bas=0;
		
		for(int x=1;x<=8;x++)
		    {
			if(deplac_gauche==0 || deplac_droite==0 || deplac_haut==0 || deplac_bas==0)
			    {
				//1
				if(colonne+x<8)
				    if(tableaupiece[colonne+x][ligne].gettype()==0  && deplac_droite==0)
					{  
					    tableaupiece[colonne+x][ligne].possibilite=true;
					}
				    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne+x][ligne].getcouleur() && deplac_droite==0)
					{
					    tableaupiece[colonne+x][ligne].possibilite=true;
					    deplac_droite++;
					}
				else deplac_droite++;
				//2
				if(colonne-x>=0)
				    if(tableaupiece[colonne-x][ligne].gettype()==0 && deplac_gauche==0)
					{  
					    tableaupiece[colonne-x][ligne].possibilite=true;
					}
				    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne-x][ligne].getcouleur() && deplac_gauche==0)
					{
					    tableaupiece[colonne-x][ligne].possibilite=true;
					    deplac_gauche++;
					}
				    else deplac_gauche++;
				
				//3
				if(ligne+x<8)
				    if(tableaupiece[colonne][ligne+x].gettype()==0  && deplac_bas==0)
					{  
					    tableaupiece[colonne][ligne+x].possibilite=true;
					}
				    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne][ligne+x].getcouleur() && deplac_bas==0)
					{
					    tableaupiece[colonne][ligne+x].possibilite=true;
					    deplac_bas++;
					}
				    else deplac_bas++;
				
				//4
				if(ligne-x>=0)
				    if(tableaupiece[colonne][ligne-x].gettype()==0 && deplac_haut==0)
					{  
					    tableaupiece[colonne][ligne-x].possibilite=true;
					}
				    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne][ligne-x].getcouleur() && deplac_haut==0)
					{
					    tableaupiece[colonne][ligne-x].possibilite=true;
					    deplac_haut++;
					}
				    else deplac_haut++;
			    }
		    }
	    }
	

	//fou
	if(typepiece == 3)
	    {
		int deplac_hautgauche=0,deplac_hautdroite=0,deplac_basgauche=0,deplac_basdroite=0;
		
		for(int x=1;x<=8;x++)
		    {
			//1
			if(colonne+x<8 && ligne+x<8)
			    if(deplac_basdroite==0)
				if(tableaupiece[colonne+x][ligne+x].gettype()==0 )
				    tableaupiece[colonne+x][ligne+x].possibilite=true;
				else if(tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne+x][ligne+x].getcouleur())
				    {
					tableaupiece[colonne+x][ligne+x].possibilite=true;
					deplac_basdroite++;
				    }
				else deplac_basdroite++;
			    
			//2
			if(colonne-x>=0 && ligne-x>=0)
			    if(deplac_hautgauche==0)
				if(tableaupiece[colonne-x][ligne-x].gettype()==0)
				    tableaupiece[colonne-x][ligne-x].possibilite=true;
				else if(tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne-x][ligne-x].getcouleur())
				    {
					tableaupiece[colonne-x][ligne-x].possibilite=true;
					deplac_hautgauche++;
				    }
				else deplac_hautgauche++;
			
			//3
			if(colonne+x<8 && ligne-x>=0)
			    if(deplac_hautdroite==0)
				if(tableaupiece[colonne+x][ligne-x].gettype()==0 )
				    tableaupiece[colonne+x][ligne-x].possibilite=true;
				else if(tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne+x][ligne-x].getcouleur())
				    {
					tableaupiece[colonne+x][ligne-x].possibilite=true;
					deplac_hautdroite++;
				    }
				else deplac_hautdroite++;
			
			//4
			if(colonne-x>=0 && ligne+x<8)
			    {
				if(deplac_basgauche==0)
				    if(tableaupiece[colonne-x][ligne+x].gettype()==0 )
					tableaupiece[colonne-x][ligne+x].possibilite=true;
				    else if(tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne-x][ligne+x].getcouleur())
					{
					    tableaupiece[colonne-x][ligne+x].possibilite=true;
					    deplac_basgauche++;
					}
				    else deplac_basgauche++;
			    }
		    }

	    }
	
	//cavalier en passif et en attaque ger? mais a verifier avec l'idee de couleur
	if(typepiece == 4)//cavalier

	    {	
		if( colonne+1<8 && ligne+2<8)
		    if(tableaupiece[colonne+1][ligne+2].getcouleur()!=tableaupiece[colonne][ligne].getcouleur()||tableaupiece[colonne+1][ligne+2].gettype()==0)
			tableaupiece[colonne+1][ligne+2].possibilite=true;

		if( colonne+2<8 && ligne+1<8)
		    if(tableaupiece[colonne+2][ligne+1].getcouleur()!=tableaupiece[colonne][ligne].getcouleur()||tableaupiece[colonne+2][ligne+1].gettype()==0 )
			tableaupiece[colonne+2][ligne+1].possibilite=true;

		if( colonne-1>=0 && ligne-2>=0)
		    {
			if(tableaupiece[colonne-1][ligne-2].getcouleur()!=tableaupiece[colonne][ligne].getcouleur() ||tableaupiece[colonne-1][ligne-2].gettype()==0)
			    tableaupiece[colonne-1][ligne-2].possibilite=true;
		    }

		if( colonne-2>=0 && ligne-1>=0)
		    {
			if(tableaupiece[colonne-2][ligne-1].getcouleur()!=tableaupiece[colonne][ligne].getcouleur()||tableaupiece[colonne-2][ligne-1].gettype()==0 )
			    tableaupiece[colonne-2][ligne-1].possibilite=true;
		    }

		if( colonne-2>=0 && ligne+1<8)
		    if(tableaupiece[colonne-2][ligne+1].getcouleur()!=tableaupiece[colonne][ligne].getcouleur()||tableaupiece[colonne-2][ligne+1].gettype()==0)
			tableaupiece[colonne-2][ligne+1].possibilite=true;

		if( colonne+1<8 && ligne-2>=0)
		    if(tableaupiece[colonne+1][ligne-2].getcouleur()!=tableaupiece[colonne][ligne].getcouleur()||tableaupiece[colonne+1][ligne-2].gettype()==0 )
			tableaupiece[colonne+1][ligne-2].possibilite=true;

		if( colonne-1>=0 && ligne+2<8)
		    if(tableaupiece[colonne-1][ligne+2].getcouleur()!=tableaupiece[colonne][ligne].getcouleur()||tableaupiece[colonne-1][ligne+2].gettype()==0 )
			tableaupiece[colonne-1][ligne+2].possibilite=true;
		
		if( colonne+2<8 && ligne-1>=0)
		    if(tableaupiece[colonne+2][ligne-1].getcouleur()!=tableaupiece[colonne][ligne].getcouleur()||tableaupiece[colonne+2][ligne-1].gettype()==0)
		    	tableaupiece[colonne+2][ligne-1].possibilite=true;
	    }
	
	//roi
	if(typepiece == 5)//roi
	    {
		boolean couleur_roi;
		
		couleur_roi=tableaupiece[colonne][ligne].getcouleur();
	
		if(couleur_roi==false)
		    coup_sur_roi(true);
		else 
		    coup_sur_roi(false);
		
		//1
		if(colonne+1<8)
		    if(tableaupiece[colonne+1][ligne].gettype()==0)
			{
			    if(tableaupiece[colonne+1][ligne].attaquabilite==false)
				tableaupiece[colonne+1][ligne].possibilite=true;
			}
		    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne+1][ligne].getcouleur())
			{
			    if(tableaupiece[colonne+1][ligne].attaquabilite==false)
				tableaupiece[colonne+1][ligne].possibilite=true;
			}
		//2
		if(ligne+1<8)
		    if(tableaupiece[colonne][ligne+1].gettype()==0)
			{
			    if(tableaupiece[colonne][ligne+1].attaquabilite==false)
				tableaupiece[colonne][ligne+1].possibilite=true;
			}
		    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne][ligne+1].getcouleur())
			{
			    if(tableaupiece[colonne][ligne+1].attaquabilite==false)
				tableaupiece[colonne][ligne+1].possibilite=true;
			}
		//3
		if(ligne-1>=0)
		    if(tableaupiece[colonne][ligne-1].gettype()==0)
			{
			    if(tableaupiece[colonne][ligne-1].attaquabilite==false)
				tableaupiece[colonne][ligne-1].possibilite=true;
			}
		    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne][ligne-1].getcouleur())
			{
			    if(tableaupiece[colonne][ligne-1].attaquabilite==false)
				tableaupiece[colonne][ligne-1].possibilite=true;
			}
		//4
		if(colonne-1>=0)
		    if(tableaupiece[colonne-1][ligne].gettype()==0)
			{
			    if(tableaupiece[colonne-1][ligne].attaquabilite==false)
				tableaupiece[colonne-1][ligne].possibilite=true;
			}
		    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne-1][ligne].getcouleur())
			{
			    if(tableaupiece[colonne-1][ligne].attaquabilite==false)
				tableaupiece[colonne-1][ligne].possibilite=true;
			}
		//5
		if(colonne+1<8 && ligne+1<8)
		    if(tableaupiece[colonne+1][ligne+1].gettype()==0)
			{
			    if(tableaupiece[colonne+1][ligne+1].attaquabilite==false)
				tableaupiece[colonne+1][ligne+1].possibilite=true;
			}
		    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne+1][ligne+1].getcouleur())
			{
			    if(tableaupiece[colonne+1][ligne+1].attaquabilite==false)
				tableaupiece[colonne+1][ligne+1].possibilite=true;
			}
		//6
		if(colonne-1>=0 && ligne-1>=0)
		    if(tableaupiece[colonne-1][ligne-1].gettype()==0)
			{
			    if(tableaupiece[colonne-1][ligne-1].attaquabilite==false)
				tableaupiece[colonne-1][ligne-1].possibilite=true;
			}
		    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne-1][ligne-1].getcouleur())
			{
			    if(tableaupiece[colonne-1][ligne-1].attaquabilite==false)
				tableaupiece[colonne-1][ligne-1].possibilite=true;
			}

		//7
		if(colonne+1<8 && ligne-1>=0)
		    if(tableaupiece[colonne+1][ligne-1].gettype()==0)
			{
			    if(tableaupiece[colonne+1][ligne-1].attaquabilite==false)
				tableaupiece[colonne+1][ligne-1].possibilite=true;
			}
		    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne+1][ligne-1].getcouleur())
			{
			    if(tableaupiece[colonne+1][ligne-1].attaquabilite==false)
				tableaupiece[colonne+1][ligne-1].possibilite=true;
			}
		//8
		if(colonne-1>=0 && ligne+1<8)
		    if(tableaupiece[colonne-1][ligne+1].gettype()==0)
			{
			    if(tableaupiece[colonne-1][ligne+1].attaquabilite==false)
				tableaupiece[colonne-1][ligne+1].possibilite=true;
			}
		    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne-1][ligne+1].getcouleur())
			{
			    if(tableaupiece[colonne-1][ligne+1].attaquabilite==false)
				tableaupiece[colonne-1][ligne+1].possibilite=true;
			}
	    }
	
	
	if(typepiece == 6)//reine
	    {
		int deplac_hautgauche=0,deplac_hautdroite=0,deplac_basgauche=0,deplac_basdroite=0;
		int deplac_haut=0,deplac_bas=0,deplac_droite=0,deplac_gauche=0;
		
		for(int x=1;x<=7;x++)
		    {
			//1
			if(colonne+x<8 && ligne+x<8)
			    if(tableaupiece[colonne+x][ligne+x].gettype()==0 && deplac_basdroite==0)
				tableaupiece[colonne+x][ligne+x].possibilite=true;
			    else if(tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne+x][ligne+x].getcouleur() && deplac_basdroite==0)
				{
				    tableaupiece[colonne+x][ligne+x].possibilite=true;
				    deplac_basdroite++;
				}
			    else deplac_basdroite++;
			//2
			if(colonne-x>=0 && ligne-x>=0)
			    if(tableaupiece[colonne-x][ligne-x].gettype()==0 && deplac_hautgauche==0)
				tableaupiece[colonne-x][ligne-x].possibilite=true;
			    else if(tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne-x][ligne-x].getcouleur() && deplac_hautgauche==0)
				{
				    tableaupiece[colonne-x][ligne-x].possibilite=true;
				    deplac_hautgauche++;
				}
			    else deplac_hautgauche++;
			//3
			if(colonne+x<8 && ligne-x>=0)
			    if(tableaupiece[colonne+x][ligne-x].gettype()==0 && deplac_hautdroite==0)
				tableaupiece[colonne+x][ligne-x].possibilite=true;
			    else if(tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne+x][ligne-x].getcouleur() && deplac_hautdroite==0)
				{
				    tableaupiece[colonne+x][ligne-x].possibilite=true;
				    deplac_hautdroite++;
				}
			    else deplac_hautdroite++;
			//4
			if(colonne-x>=0 && ligne+x<8)
			    if(tableaupiece[colonne-x][ligne+x].gettype()==0 && deplac_basgauche==0)
				tableaupiece[colonne-x][ligne+x].possibilite=true;
			    else if(tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne-x][ligne+x].getcouleur() && deplac_basgauche==0)
				{
				    tableaupiece[colonne-x][ligne+x].possibilite=true;
				    deplac_basgauche++;
				}
			    else deplac_basgauche++;
		    }
		for(int x=1;x<=8;x++)
		    {
			if(deplac_gauche==0 || deplac_droite==0 || deplac_haut==0 || deplac_bas==0)
			    {
				//1
				if(colonne+x<8)
				    if(tableaupiece[colonne+x][ligne].gettype()==0  && deplac_droite==0)
					{  
					    tableaupiece[colonne+x][ligne].possibilite=true;
					}
				    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne+x][ligne].getcouleur() && deplac_droite==0)
					{
					    tableaupiece[colonne+x][ligne].possibilite=true;
					    deplac_droite++;
					}
				    else deplac_droite++;
				//2
				if(colonne-x>=0)
				    if(tableaupiece[colonne-x][ligne].gettype()==0 && deplac_gauche==0)
					{  
					    tableaupiece[colonne-x][ligne].possibilite=true;
					}
				    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne-x][ligne].getcouleur() && deplac_gauche==0)
					{
					    tableaupiece[colonne-x][ligne].possibilite=true;
					    deplac_gauche++;
					}
				    else deplac_gauche++;
				
				//3
				if(ligne+x<8)
				    if(tableaupiece[colonne][ligne+x].gettype()==0  && deplac_bas==0)
					{  
					    tableaupiece[colonne][ligne+x].possibilite=true;
					}
				    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne][ligne+x].getcouleur() && deplac_bas==0)
					{
					    tableaupiece[colonne][ligne+x].possibilite=true;
					    deplac_bas++;
					}
				    else deplac_bas++;
				
				//4
				if(ligne-x>=0)
				    if(tableaupiece[colonne][ligne-x].gettype()==0 && deplac_haut==0)
					{  
					    tableaupiece[colonne][ligne-x].possibilite=true;
					}
				    else if( tableaupiece[colonne][ligne].getcouleur()!=tableaupiece[colonne][ligne-x].getcouleur() && deplac_haut==0)
					{
					    tableaupiece[colonne][ligne-x].possibilite=true;
					    deplac_haut++;
					}
				    else deplac_haut++;
			    }
		    }	
	
	    }
    }
    public void couppossible_et_valide(int colonne_d, int ligne_d, int colonne_a, int ligne_a)
    {
	int a;
	boolean b;

	a=tableaupiece[colonne_d][ligne_d].gettype(); //type de la piece qui est bougee
	b=tableaupiece[colonne_d][ligne_d].getcouleur();//couleur de la piece qui est bougee
	tableaupiece[colonne_a][ligne_a].setcouleurandtype(b, a);//case ou est deplacee la piece mise a jour
	tableaupiece[colonne_d][ligne_d].setcouleurandtype(false, 0);//case d'ou part la piece mise a zero (sans piece)

	if((colonne_d==0 && ligne_d==0)||(colonne_a==0 && ligne_a==0))
	    rockng=1;
	
	if((colonne_d==0 && ligne_d==7)||(colonne_a==0 && ligne_a==7))
	    rocknd=1;
	
	if((colonne_d==7 && ligne_d==0)||(colonne_a==7 && ligne_a==0))
	    rockbg=1;
	
	if((colonne_d==7 && ligne_d==7)||(colonne_a==7 && ligne_a==7))
	    rockbd=1;
	
	if(colonne_d==7 && ligne_d==4)
	    {
		rocknd=1;
		rockng=1;
	    }
	
	if(colonne_d==7 && ligne_d==4)
	    {
		rockbd=1;
		rockbg=1;
	    }
    }
    public boolean getcouleur_piece(int colonne, int ligne)
    {
	return tableaupiece[colonne][ligne].getcouleur();
    }
    public int gettype_piece(int colonne, int ligne)
    {
	return tableaupiece[colonne][ligne].gettype();
    }	
    public void setpiece(int col, int lig,int type, boolean couleur)
    {
	tableaupiece[col][lig].setcouleurandtype(couleur,type);
    }
    public void setchoix_piece(int colonne, int ligne, int choix)
    {
	tableaupiece[colonne][ligne].setchoix(choix);
    }
    public void raz_possibilite()
    {
	int x,y;

	for(x=0;x<8;x++)
	    {
		for(y=0;y<8;y++)
		    {
			tableaupiece[x][y].setpossibilite();
		    }
	    }
    }
    public int getchoix_piece(int colonne, int ligne)
    {
	return tableaupiece[colonne][ligne].getchoix();
    }
    public void raz_choix()
    {
	int x,y;
	for(x=0;x<8;x++)
	    {
		for(y=0;y<8;y++)
		    {
			tableaupiece[y][x].setchoix(0);
		    }
	    }
    }
	public void remplace_pion_blanc()
	{
	int test=0;
	int x,y;
	JOptionPane d = new JOptionPane();
	String lesTextes[]={ "reine", "fou","tour", "cavalier"};
	
		while(test==0)
		{
		for(x=0;x<8;x++)
			{
				if(tableaupiece[x][0].gettype()==1 && tableaupiece[x][0].getcouleur()==true)
				{
				int choix = JOptionPane.showOptionDialog(d, "Par quelle piece voulez vous changer ce pion : ", "Question ?", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, lesTextes, lesTextes[2]);
				if(choix==0) tableaupiece[x][0].setcouleurandtype(true, 6);
				if(choix==1) tableaupiece[x][0].setcouleurandtype(true, 3);
				if(choix==2) tableaupiece[x][0].setcouleurandtype(true, 2);
				if(choix==3) tableaupiece[x][0].setcouleurandtype(true, 4);
				}
				else if (tableaupiece[x][0].gettype()!=1 || tableaupiece[x][0].getcouleur()==false) test=1;
			}
		}
	}
    public void remplace_pion_noir()
    {
	int test=0;
	int x,y;
	JOptionPane d = new JOptionPane();
	String lesTextes[]={ "reine", "fou","tour", "cavalier"};
	
	while(test==0)
	    {
		for(x=0;x<8;x++)
		    {
			if(tableaupiece[x][7].gettype()==1 && tableaupiece[x][7].getcouleur()==false)
			    {
				int choix = JOptionPane.showOptionDialog(d, "Par quelle piece voulez vous changer ce pion : ", "Question ?", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, lesTextes, lesTextes[2]);
				if(choix==0) tableaupiece[x][7].setcouleurandtype(false, 6);
				if(choix==1) tableaupiece[x][7].setcouleurandtype(false, 3);
				if(choix==2) tableaupiece[x][7].setcouleurandtype(false, 2);
				if(choix==3) tableaupiece[x][7].setcouleurandtype(false, 4);
			    }
			else if (tableaupiece[x][7].gettype()!=1 || tableaupiece[x][7].getcouleur()==true) test=1;
		    }
	    }
    }
    public void reset_echiquier()
    {
	int x,y;

	for(x=0;x<8;x++)
	    {
		for(y=0;y<8;y++)
		    {
			tableaupiece[y][x].setcouleurandtype(false,0);
		    }
	    }
		System.out.println("RAZ echiquier !!");
    }

    // Ajouts sp?cial I.A.
    
    public boolean getpossibilite( int x , int y )
    {
    	return tableaupiece[x][y].getpossibilite() ;
    }
    public Piece getpiece( int x , int y )
    {
    	return tableaupiece[x][y] ;
    }
    public void couverture_potentielle(int j,int i)
    {
       
	if(tableaupiece[j][i].gettype()!=0)
	    {
			if(tableaupiece[j][i].gettype()==1)//pion noir et blanc
			    {
				if(tableaupiece[j][i].getcouleur()==false)
				    {
					if(i+1<8 && j+1<8)
					    {
						tableaupiece[j+1][i+1].attaquabilite=true;
					    }
					if(j-1>=0 && i+1<8)
					    {
						tableaupiece[j-1][i+1].attaquabilite=true;
					    }
				    }
				if(tableaupiece[j][i].getcouleur()==true || tableaupiece[j][i].gettype()==5)
				    {
					if(j+1<8 && i-1>=0)
					    {
						tableaupiece[j+1][i-1].attaquabilite=true;
					    }
					if(j-1>=0 && i-1>=0)
					    {
						tableaupiece[j-1][i-1].attaquabilite=true;
					    }
				    }
			    }
			
			if(tableaupiece[j][i].gettype()==2)//tour
			    {
				int deplac_gauche=0,deplac_droite=0,deplac_haut=0,deplac_bas=0;
				
				for(int x=1;x<=8;x++)
				    {
					if(deplac_gauche==0 || deplac_droite==0 || deplac_haut==0 || deplac_bas==0)
					    {
						//1
						if(j+x<8)
						    if(tableaupiece[j+x][i].gettype()==0 && deplac_droite==0)
							{  
							    tableaupiece[j+x][i].attaquabilite=true;
							}
						    else if(deplac_droite==0)
							{
							    tableaupiece[j+x][i].attaquabilite=true;
							    deplac_droite++;
							}
						    else deplac_droite++;
						//2
						if(j-x>=0)
						    if(tableaupiece[j-x][i].gettype()==0 && deplac_gauche==0)
							{  
							    tableaupiece[j-x][i].attaquabilite=true;
							}
						    else if(deplac_gauche==0)
							{
							    tableaupiece[j-x][i].attaquabilite=true;
							    deplac_gauche++;
							}
						    else deplac_gauche++;
						
						//3
						if(i+x<8)
						    if(tableaupiece[j][i+x].gettype()==0 && deplac_bas==0)
							{  
							    tableaupiece[j][i+x].attaquabilite=true;
							}
						    else if(deplac_bas==0)
							{
							    tableaupiece[j][i+x].attaquabilite=true;
							    deplac_bas++;
							}
						    else deplac_bas++;
								
						//4
						if(i-x>=0)
						    if(tableaupiece[j][i-x].gettype()==0 && deplac_haut==0)
							{  
							    tableaupiece[j][i-x].attaquabilite=true;
							}
						    else if(deplac_haut==0)
							{
							    tableaupiece[j][i-x].attaquabilite=true;
							    deplac_haut++;
							}
								    else deplac_haut++;
					    }
				    }
				
			    }
			
			if(tableaupiece[j][i].gettype()==4)//cavalier
					    {
						if(j+1<8 && i+2<8)
						    tableaupiece[j+1][i+2].attaquabilite=true;
						
						if(j+2<8 && i+1<8)
						    tableaupiece[j+2][i+1].attaquabilite=true;
						
						if(j-1>=0 && i-2>=0)
						    tableaupiece[j-1][i-2].attaquabilite=true;
						
						if(j-2>=0 && i-1>=0)
						    tableaupiece[j-2][i-1].attaquabilite=true;
						
						if(j-2>=0 && i+1<8)
						    tableaupiece[j-2][i+1].attaquabilite=true;
					
						if(j+1<8 && i-2>=0)
						    tableaupiece[j+1][i-2].attaquabilite=true;
						
						if(j-1>=0 && i+2<8)
						    tableaupiece[j-1][i+2].attaquabilite=true;
						
						if(j+2<8 && i-1>=0)
						    tableaupiece[j+2][i-1].attaquabilite=true;
					    }
					
					if(tableaupiece[j][i].gettype()==3)//fou
					    {
						int deplac_hautgauche=0,deplac_hautdroite=0,deplac_basgauche=0,deplac_basdroite=0;
						
						for(int x=1;x<=8;x++)
						    {
							//1
							if(j+x<8 && i+x<8)
							    if(tableaupiece[j+x][i+x].gettype()==0 && deplac_basdroite==0)
								tableaupiece[j+x][i+x].attaquabilite=true;
							    else
								if(deplac_basdroite==0)
								    {
									tableaupiece[j+x][i+x].attaquabilite=true;
									deplac_basdroite++;
								    }
								else deplac_basdroite++;
							//2
							if(j-x>=0 && i-x>=0)
							    if(tableaupiece[j-x][i-x].gettype()==0 && deplac_hautgauche==0)
								tableaupiece[j-x][i-x].attaquabilite=true;
							    else if(deplac_hautgauche==0)
								{
								    tableaupiece[j-x][i-x].attaquabilite=true;
								    deplac_hautgauche++;
								}
							    else deplac_hautgauche++;
							//3
							if(j+x<8 && i-x>=0)
							    if(tableaupiece[j+x][i-x].gettype()==0 && deplac_hautdroite==0)
								tableaupiece[j+x][i-x].attaquabilite=true;
							    else if(deplac_hautdroite==0)
								{
								    tableaupiece[j+x][i-x].attaquabilite=true;
								    deplac_hautdroite++;
								}
							    else deplac_hautdroite++;
							//4
							if(j-x>=0 && i+x<8)
							    if(tableaupiece[j-x][i+x].gettype()==0 && deplac_basgauche==0)
								tableaupiece[j-x][i+x].attaquabilite=true;
							    else if(deplac_basgauche==0)
								{
								    tableaupiece[j-x][i+x].attaquabilite=true;
								    deplac_basgauche++;
								}
							    else deplac_basgauche++;
						    }
					    }
					if(tableaupiece[j][i].gettype()==5)//roi
					    {
						
						    //mouvements de type tour
						    //1
						    if(j+1<8)
							tableaupiece[j+1][i].attaquabilite=true;
				
				    
						    //2
						    if(j-1>=0)
							tableaupiece[j-1][i].attaquabilite=true;
						    
						    
						    //3
						    if(i+1<8)
							tableaupiece[j][i+1].attaquabilite=true;
						    
						    //4
						    if(i-1>=0)
							tableaupiece[j][i-1].attaquabilite=true;
						    
						    
						    //mouvements de type fou
						    //1
						    if(j+1<8 && i+1<8)
							tableaupiece[j+1][i+1].attaquabilite=true;
						    
						    //2
						    if(j-1>=0 && i-1>=0)
							tableaupiece[j-1][i-1].attaquabilite=true;
						    
						    //3
						    if(j+1<8 && i-1>=0)
							tableaupiece[j+1][i-1].attaquabilite=true;
						    
						    //4
						    if(j-1>=0 && i+1<8)
							tableaupiece[j-1][i+1].attaquabilite=true;
						}	
					    }	
					
					if(tableaupiece[j][i].gettype()==6)//reine
					    {
						////////////////////////////////////////////////////////////////////////
						////////////////////////////////////////////////////////////////////////
						int deplac_gauche=0,deplac_droite=0,deplac_haut=0,deplac_bas=0;
						
						for(int x=1;x<=8;x++)
						    {
							if(deplac_gauche==0 || deplac_droite==0 || deplac_haut==0 || deplac_bas==0)
							    {
								//1
								if(j+x<8)
								    if(tableaupiece[j+x][i].gettype()==0 && deplac_droite==0)
									{  
									    tableaupiece[j+x][i].attaquabilite=true;
									}
								    else if(deplac_droite==0)
									{
									    tableaupiece[j+x][i].attaquabilite=true;
									    deplac_droite++;
									}
								    else deplac_droite++;
								//2
								if(j-x>=0)
								    if(tableaupiece[j-x][i].gettype()==0 && deplac_gauche==0)
									{  
									    tableaupiece[j-x][i].attaquabilite=true;
									}
								    else if(deplac_gauche==0)
									{
									    tableaupiece[j-x][i].attaquabilite=true;
									    deplac_gauche++;
									}
								    else deplac_gauche++;
								
								//3
								if(i+x<8)
								    if(tableaupiece[j][i+x].gettype()==0 && deplac_bas==0)
									{  
									    tableaupiece[j][i+x].attaquabilite=true;
									}
								    else if(deplac_bas==0)
									{
									    tableaupiece[j][i+x].attaquabilite=true;
									    deplac_bas++;
									}
								    else deplac_bas++;
								
								//4
								if(i-x>=0)
								    if(tableaupiece[j][i-x].gettype()==0 && deplac_haut==0)
									{  
									    tableaupiece[j][i-x].attaquabilite=true;
									}
								    else if(deplac_haut==0)
									{
									    tableaupiece[j][i-x].attaquabilite=true;
									    deplac_haut++;
									}
								    else deplac_haut++;
							    }
						    }
						
						
						//mouvement type fou
						int deplac_hautgauche=0,deplac_hautdroite=0,deplac_basgauche=0,deplac_basdroite=0;
						
						for(int x=1;x<=8;x++)
						    {
							//1
							if(j+x<8 && i+x<8)
							    if(tableaupiece[j+x][i+x].gettype()==0 && deplac_basdroite==0)
								tableaupiece[j+x][i+x].attaquabilite=true;
							    else
								if(deplac_basdroite==0)
								    {
									tableaupiece[j+x][i+x].attaquabilite=true;
									deplac_basdroite++;
								    }
								else deplac_basdroite++;
							//2
							if(j-x>=0 && i-x>=0)
							    if(tableaupiece[j-x][i-x].gettype()==0 && deplac_hautgauche==0)
								tableaupiece[j-x][i-x].attaquabilite=true;
							    else if(deplac_hautgauche==0)
								{
								    tableaupiece[j-x][i-x].attaquabilite=true;
								    deplac_hautgauche++;
								}
							    else deplac_hautgauche++;
							//3
							if(j+x<8 && i-x>=0)
							    if(tableaupiece[j+x][i-x].gettype()==0 && deplac_hautdroite==0)
								tableaupiece[j+x][i-x].attaquabilite=true;
							    else if(deplac_hautdroite==0)
								{
								    tableaupiece[j+x][i-x].attaquabilite=true;
								    deplac_hautdroite++;
								}
							    else deplac_hautdroite++;
							//4
							if(j-x>=0 && i+x<8)
							    if(tableaupiece[j-x][i+x].gettype()==0 && deplac_basgauche==0)
								tableaupiece[j-x][i+x].attaquabilite=true;
							    else if(deplac_basgauche==0)
								{
								    tableaupiece[j-x][i+x].attaquabilite=true;
								    deplac_basgauche++;
								}
							    else deplac_basgauche++;
						    }
					    }
    }
    public boolean getattaquabilite(int x , int y)
    {
    	return tableaupiece[x][y].attaquabilite ;
    }
    public void free_attaquabilite()
    {
    	int x,y ;
    	
    	for( x = 0 ; x < 8 ; x++ )
    	{
    		for( y = 0 ; y < 8 ; y++ )
    		{
    			tableaupiece[x][y].attaquabilite = false ;
    		}
    	}
    }
    public void couppossibles_camp( boolean camp )
    {
    	int c , l , x , y ;
    	boolean[][] temp = new boolean[8][8] ;
    	
    	for( c = 0 ; c < 8 ; c++ )
    	{
    		for( l = 0 ; l < 8 ; l++ )
    		{
    			temp[c][l] = false ;
    		}
    	}
    	
    	for( c = 0 ; c < 8 ; c++ )
    	{
    		for( l = 0 ; l < 8 ; l++ )
    		{
    			if( getcouleur_piece(c,l) == camp )
    			{
    				couppossible(c,l) ;
    				
    				for( x = 0 ; x < 8 ; x++ )
    				{
    					for( y = 0 ; y < 8 ; y++ )
    					{
    						if( getpossibilite(x,y) )
    						{
    							temp[x][y] = true ;
    						}
    					}
    				}
    			}
    		}
    	}
    	
       	for( c = 0 ; c < 8 ; c++ )
    	{
    		for( l = 0 ; l < 8 ; l++ )
    		{
    			tableaupiece[c][l].possibilite = temp[c][l] ;
    		}
    	}
    }
    public Echiquier( Echiquier modele )
    {
    	int c , l ;
    	
    	tableaupiece = new Piece[8][8] ;
    	for( c = 0 ; c < 8 ; c++ )
    	{
    		for( l = 0 ; l < 8 ; l++ )
    		{
    			tableaupiece[c][l] = new Piece( modele.tableaupiece[c][l] ) ;
    		}
    	}
    }
}
//classe qui determine tout les elements qui constituent la piece
	
class Piece
{
    boolean couleurpiece,possibilite,attaquabilite;
    int typepiece,choix;
    
    public Piece()
    {
	couleurpiece=false;
	typepiece=0;
	choix=0;
	possibilite=false;//sert pour indiquer si une piece pour bouger ou pas
	attaquabilite=false;
    }
    public void setcouleurandtype(boolean y,int x)
    {
	couleurpiece=y;
	typepiece=x;
    }
    public void setchoix(int x)
    {
	choix=x;
    }    
    public void setpossibilite()
    {
	possibilite=false;
    }
    public int getchoix()
    {
	return choix;
    }
    public boolean getcouleur()
    {
	return couleurpiece;
    }
    public int gettype()
    {
	return typepiece;
    }
    public boolean getpossibilite()
    {
	return possibilite;
    }

    // Ajouts sp?cial I.A.
    
    public Piece( Piece modele )
    {
    	typepiece = modele.typepiece ;
    	choix = modele.choix ;
    	couleurpiece = modele.couleurpiece ;
    	possibilite = modele.possibilite ;
    	attaquabilite = modele.attaquabilite ;
    }
}
